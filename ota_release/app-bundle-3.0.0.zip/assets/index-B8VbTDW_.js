const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-D6lRJW5D.js","assets/synapse-DJbL7Np4.js","assets/vendor-react-BR5y8XGT.js","assets/vendor-socket-TjCxX7sJ.js","assets/synapse-HV_l4fLf.css"])))=>i.map(i=>d[i]);
import{A as w,j as e,k as W,_ as Z,m as ee}from"./synapse-DJbL7Np4.js";import{r as n,R as P}from"./vendor-react-BR5y8XGT.js";import{c as H,a0 as Y,bm as ae,af as J,bn as te,aV as se,bi as ne,bh as oe,aO as re,bo as ie,bp as ce,aN as le,aa as q,bq as Q,x as de,F as me,br as pe,s as he,k as ue,P as xe,bs as ge,bt as fe,a5 as be,ao as we,J as je,m as ve,bu as ye,bv as Ne,a as ke}from"./vendor-ui-C2GrFI-5.js";const Ce=({reel:s,index:i,currentIndex:d,handleDoubleTap:x,videoRef:o,muted:j,likeAnimation:f,showProductTags:u,children:m})=>{const b=P.useRef(null);return P.useEffect(()=>{b.current&&b.current.style.setProperty("--reel-offset",`${(i-d)*100}%`)},[i,d]),e.jsxs("div",{ref:b,className:`reel-item ${i===d?"active":""} reel-item-dynamic`,onClick:x,children:[e.jsx("video",{ref:o,src:s.videoUrl,poster:s.thumbnailUrl,loop:!0,muted:j,playsInline:!0,className:"reel-video"}),f&&i===d&&e.jsx("div",{className:"like-animation",children:e.jsx(J,{className:"w-24 h-24 text-white fill-red-500"})}),u&&s.productTags.map((g,N)=>e.jsx(Se,{tag:g},N)),m]})},Se=({tag:s})=>{const i=P.useRef(null);return P.useEffect(()=>{i.current&&(i.current.style.setProperty("--tag-x",`${s.xPercent}%`),i.current.style.setProperty("--tag-y",`${s.yPercent}%`))},[s]),e.jsxs("button",{ref:i,className:"product-tag product-tag-dynamic",children:[e.jsx(me,{className:"w-4 h-4"}),e.jsx("span",{children:s.productName}),e.jsxs("span",{className:"price",children:["₹",s.price]})]})},Re=({user:s,isCreator:i})=>{const[d,x]=n.useState([]),[o,j]=n.useState(0),[f,u]=n.useState(!0),[m,b]=n.useState(!1),[g,N]=n.useState(!1),[O,S]=n.useState(!1),[D,I]=n.useState([]),[v,M]=n.useState(""),[V,B]=n.useState(!0),[$,z]=n.useState(!1),G=n.useRef(null),F=n.useRef([]),T=n.useRef(0);n.useEffect(()=>{_()},[]),n.useEffect(()=>{F.current.forEach((a,r)=>{a&&(r===o&&!g?a.play().catch(console.error):(a.pause(),a.currentTime=0))})},[o,g]);const _=async()=>{try{const r=await(await fetch(`${w}/api/reels/feed?userId=${s.id}&limit=20`)).json();r.success&&x(r.reels)}catch{x([{id:"REEL-1",creatorId:"user-1",creatorName:"Sharma Dhaba",creatorType:"MESS",videoUrl:"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",caption:"Fresh hot parathas ready! 🥟 #DesiFood #FreshFood",hashtags:["DesiFood","FreshFood"],musicTitle:"Original Audio",locationTag:{name:"Jhansi"},productTags:[{productId:"p1",productName:"Paratha Thali",price:60,xPercent:50,yPercent:60}],viewCount:1234,likeCount:245,commentCount:32,shareCount:12,isLiked:!1,isSaved:!1},{id:"REEL-2",creatorId:"user-2",creatorName:"Kisan Ramesh",creatorType:"FARMER",videoUrl:"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",caption:"Fresh tomatoes from my farm! 🍅 Organic and natural",hashtags:["OrganicFarm","FreshProduce"],musicTitle:"Folk Music",musicArtist:"Desi Beats",locationTag:{name:"Babina"},productTags:[{productId:"p2",productName:"Tomatoes 1kg",price:40,xPercent:30,yPercent:70}],viewCount:856,likeCount:156,commentCount:18,shareCount:8,isLiked:!1,isSaved:!1}])}finally{u(!1)}},k=a=>{a==="up"&&o>0?j(o-1):a==="down"&&o<d.length-1&&j(o+1)},C=n.useRef(0),E=a=>{const r=C.current-a.changedTouches[0].clientY;r>50?k("down"):r<-50&&k("up")},L=()=>{const a=Date.now();a-T.current<300&&(R(),z(!0),setTimeout(()=>z(!1),1e3)),T.current=a},R=async()=>{const a=d[o];if(a)try{const r=localStorage.getItem("villagelink_token"),h=await(await fetch(`${w}/api/reels/${a.id}/like`,{method:"POST",headers:{Authorization:`Bearer ${r}`}})).json();h.success&&x(d.map((y,U)=>U===o?{...y,isLiked:h.liked,likeCount:y.likeCount+(h.liked?1:-1)}:y))}catch{}},A=async()=>{const a=d[o];if(a&&navigator.share)try{await navigator.share({title:a.caption,url:`https://villagelink.app/reel/${a.id}`})}catch{}},t=async()=>{const a=d[o];if(a)try{const l=await(await fetch(`${w}/api/reels/${a.id}/comments`)).json();l.success&&I(l.comments)}catch{}},c=async()=>{if(!v.trim())return;const a=d[o];if(a)try{const r=localStorage.getItem("villagelink_token"),h=await(await fetch(`${w}/api/reels/${a.id}/comment`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${r}`},body:JSON.stringify({comment:v})})).json();h.success&&(I([h.comment,...D]),M(""),x(d.map((y,U)=>U===o?{...y,commentCount:y.commentCount+1}:y)))}catch{}},p=d[o];return f?e.jsxs("div",{className:"reels-loading",children:[e.jsx(H,{className:"w-8 h-8 animate-spin text-gray-400"}),e.jsx("p",{children:"Loading reels..."})]}):e.jsxs("div",{className:"reels-section",ref:G,onTouchStart:a=>{C.current=a.touches[0].clientY},onTouchEnd:E,children:[e.jsx("div",{className:"reels-container",children:d.map((a,r)=>e.jsxs(Ce,{reel:a,index:r,currentIndex:o,handleDoubleTap:L,videoRef:l=>F.current[r]=l,muted:m,likeAnimation:$,showProductTags:V,children:[e.jsxs("div",{className:"reel-overlay",children:[e.jsxs("div",{className:"creator-info",children:[e.jsx("div",{className:"creator-avatar",children:a.creatorName.charAt(0)}),e.jsxs("div",{className:"creator-details",children:[e.jsx("span",{className:"creator-name",children:a.creatorName}),a.locationTag&&e.jsxs("span",{className:"location",children:[e.jsx(Y,{className:"w-3 h-3"}),a.locationTag.name]})]}),e.jsx("button",{className:"follow-btn",children:"Follow"})]}),e.jsx("p",{className:"caption",children:a.caption}),e.jsx("div",{className:"hashtags",children:a.hashtags.map((l,h)=>e.jsxs("span",{className:"hashtag",children:["#",l]},h))}),a.musicTitle&&e.jsxs("div",{className:"music-info",children:[e.jsx(ae,{className:"w-4 h-4"}),e.jsxs("span",{className:"marquee",children:[a.musicTitle," ",a.musicArtist&&`• ${a.musicArtist}`]})]})]}),e.jsxs("div",{className:"reel-actions",children:[e.jsxs("button",{className:`action-btn ${a.isLiked?"liked":""}`,"aria-label":"Like this reel",onClick:l=>{l.stopPropagation(),R()},children:[e.jsx(J,{className:`w-7 h-7 ${a.isLiked?"fill-red-500 text-red-500":""}`}),e.jsx("span",{children:X(a.likeCount)})]}),e.jsxs("button",{className:"action-btn","aria-label":"View comments",onClick:l=>{l.stopPropagation(),S(!0),t()},children:[e.jsx(te,{className:"w-7 h-7"}),e.jsx("span",{children:X(a.commentCount)})]}),e.jsxs("button",{className:"action-btn","aria-label":"Share reel",onClick:l=>{l.stopPropagation(),A()},children:[e.jsx(se,{className:"w-7 h-7"}),e.jsx("span",{children:X(a.shareCount)})]})]})]},a.id))}),e.jsxs("div",{className:"reel-controls",children:[e.jsx("button",{className:"control-btn","aria-label":m?"Unmute":"Mute",onClick:()=>b(!m),children:m?e.jsx(ne,{className:"w-5 h-5"}):e.jsx(oe,{className:"w-5 h-5"})}),e.jsx("button",{className:"control-btn","aria-label":g?"Play":"Pause",onClick:()=>N(!g),children:g?e.jsx(re,{className:"w-5 h-5"}):e.jsx(ie,{className:"w-5 h-5"})})]}),e.jsxs("div",{className:"nav-arrows",children:[e.jsx("button",{className:`nav-arrow ${o===0?"disabled":""}`,"aria-label":"Previous reel",onClick:()=>k("up"),children:e.jsx(ce,{className:"w-6 h-6"})}),e.jsx("button",{className:`nav-arrow ${o===d.length-1?"disabled":""}`,"aria-label":"Next reel",onClick:()=>k("down"),children:e.jsx(le,{className:"w-6 h-6"})})]}),O&&e.jsxs("div",{className:"comments-sheet",children:[e.jsxs("div",{className:"comments-header",children:[e.jsxs("h3",{children:["Comments (",p?.commentCount||0,")"]}),e.jsx("button",{"aria-label":"Close comments",onClick:()=>S(!1),children:e.jsx(q,{className:"w-6 h-6"})})]}),e.jsx("div",{className:"comments-list",children:D.map(a=>e.jsxs("div",{className:"comment-item",children:[e.jsx("div",{className:"comment-avatar",children:a.userName.charAt(0)}),e.jsxs("div",{className:"comment-content",children:[e.jsx("span",{className:"comment-user",children:a.userName}),e.jsx("p",{className:"comment-text",children:a.text})]})]},a.id))}),e.jsxs("div",{className:"comment-input",children:[e.jsx("input",{type:"text",placeholder:"Add a comment...",value:v,onChange:a=>M(a.target.value),onKeyPress:a=>a.key==="Enter"&&c()}),e.jsx("button",{"aria-label":"Post comment",onClick:c,children:e.jsx(Q,{className:"w-5 h-5"})})]})]}),i&&e.jsx("button",{className:"create-reel-btn","aria-label":"Create new reel",children:e.jsx(de,{className:"w-6 h-6"})}),e.jsx("style",{children:`
        .reels-section {
          position: relative;
          height: calc(100vh - 140px);
          background: var(--bg-void);
          overflow: hidden;
        }

        .reels-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100%;
          color: var(--text-muted);
          gap: 12px;
        }

        .reels-container {
          position: relative;
          height: 100%;
        }

        .reel-item {
          position: absolute;
          inset: 0;
          transition: transform 0.4s ease;
        }

        .reel-video {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .like-animation {
          position: absolute;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          animation: like-pop 0.5s ease;
        }

        @keyframes like-pop {
          0% { transform: scale(0); opacity: 1; }
          50% { transform: scale(1.2); opacity: 1; }
          100% { transform: scale(1); opacity: 0; }
        }

        .product-tag {
          position: absolute;
          transform: translate(-50%, -50%);
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 12px;
          background: rgba(0, 0, 0, 0.6);
          -webkit-backdrop-filter: blur(12px);
          backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 20px;
          color: white;
          font-size: 0.875rem;
          cursor: pointer;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        }

        .product-tag .price {
          color: #FFCE1B;
          font-weight: 900;
        }

        .reel-overlay {
          position: absolute;
          bottom: 0;
          left: 0;
          right: 60px;
          padding: 20px;
          background: linear-gradient(transparent, rgba(0,0,0,0.8));
        }

        .creator-info {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 12px;
        }

        .creator-avatar {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: linear-gradient(135deg, #BE5103, #FFCE1B);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-weight: 600;
          box-shadow: 0 0 15px rgba(190, 81, 3, 0.4);
        }

        .creator-details {
          flex: 1;
        }

        .creator-name {
          display: block;
          color: white;
          font-weight: 600;
        }

        .location {
          display: flex;
          align-items: center;
          gap: 4px;
          color: #d1d5db;
          font-size: 0.75rem;
        }

        .follow-btn {
          padding: 6px 16px;
          background: #BE5103;
          border: none;
          border-radius: 6px;
          color: white;
          font-weight: 700;
          text-transform: uppercase;
          font-size: 10px;
          letter-spacing: 0.05em;
          cursor: pointer;
          transition: all 0.2s;
        }
        .follow-btn:hover {
          background: #b7410E;
          transform: scale(1.05);
        }

        .caption {
          color: white;
          font-size: 0.9rem;
          line-height: 1.5;
          margin-bottom: 8px;
        }

        .hashtags {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-bottom: 8px;
        }

        .hashtag {
          color: #FFCE1B;
          font-size: 0.875rem;
          font-weight: 600;
        }

        .music-info {
          display: flex;
          align-items: center;
          gap: 8px;
          color: white;
          font-size: 0.875rem;
        }

        .marquee {
          overflow: hidden;
          white-space: nowrap;
        }

        .reel-actions {
          position: absolute;
          right: 8px;
          bottom: 100px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .action-btn {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          background: none;
          border: none;
          color: white;
          cursor: pointer;
        }

        .action-btn span {
          font-size: 0.75rem;
        }

        .action-btn.liked svg {
          animation: like-bounce 0.3s ease;
        }

        @keyframes like-bounce {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.3); }
        }

        .reel-controls {
          position: absolute;
          top: 16px;
          right: 16px;
          display: flex;
          gap: 12px;
        }

        .control-btn {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: rgba(0,0,0,0.5);
          border: none;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }

        .nav-arrows {
          position: absolute;
          right: 16px;
          top: 50%;
          transform: translateY(-50%);
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .nav-arrow {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: rgba(255,255,255,0.2);
          border: none;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }

        .nav-arrow.disabled {
          opacity: 0.3;
          cursor: not-allowed;
        }

        .comments-sheet {
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          height: 60%;
          background: white;
          border-radius: 20px 20px 0 0;
          display: flex;
          flex-direction: column;
          z-index: 100;
        }

        .comments-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px;
          border-bottom: 1px solid #e5e7eb;
        }

        .comments-header h3 {
          font-weight: 600;
        }

        .comments-header button {
          background: none;
          border: none;
          cursor: pointer;
        }

        .comments-list {
          flex: 1;
          overflow-y: auto;
          padding: 16px;
        }

        .comment-item {
          display: flex;
          gap: 12px;
          margin-bottom: 16px;
        }

        .comment-avatar {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: #e5e7eb;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
          color: #374151;
          flex-shrink: 0;
        }

        .comment-user {
          font-weight: 600;
          font-size: 0.875rem;
        }

        .comment-text {
          font-size: 0.875rem;
          color: #374151;
        }

        .comment-input {
          display: flex;
          gap: 12px;
          padding: 12px 16px;
          border-top: 1px solid #e5e7eb;
        }

        .comment-input input {
          flex: 1;
          padding: 10px 16px;
          border: 1px solid #e5e7eb;
          border-radius: 20px;
          outline: none;
        }

        .comment-input button {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: #3b82f6;
          border: none;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }

        .create-reel-btn {
          position: absolute;
          bottom: 20px;
          left: 50%;
          transform: translateX(-50%);
          width: 56px;
          height: 56px;
          border-radius: 50%;
          background: linear-gradient(135deg, #ec4899, #8b5cf6);
          border: none;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          box-shadow: 0 4px 20px rgba(139, 92, 246, 0.4);
        }
      `})]})},X=s=>s>=1e6?`${(s/1e6).toFixed(1)}M`:s>=1e3?`${(s/1e3).toFixed(1)}K`:s.toString(),Pe=({user:s,isAIAssistant:i=!1})=>{const[d,x]=n.useState([]),[o,j]=n.useState(null),[f,u]=n.useState([]),[m,b]=n.useState(""),[g,N]=n.useState(!0),[O,S]=n.useState(!1),[D,I]=n.useState(""),[v,M]=n.useState(!1),[V,B]=n.useState(!1),$=n.useRef(null),z=n.useRef(null);n.useEffect(()=>{i?(u([{id:"AI-INIT",senderId:"AI",senderName:"Gram Sahayak",type:"TEXT",content:`Namaste ${s.name}! I am your Gram Sahayak. How can I help you today?`,status:"READ",timestamp:new Date,reactions:[]}]),N(!1)):G()},[i]),n.useEffect(()=>{_()},[f]);const G=async()=>{try{const t=localStorage.getItem("villagelink_token"),p=await(await fetch(`${w}/api/chat/conversations`,{headers:{Authorization:`Bearer ${t}`}})).json();p.success&&x(p.conversations)}catch{x([{id:"CONV-1",participants:[{userId:s.id,name:s.name},{userId:"seller-1",name:"Sharma Dhaba"}],type:"DIRECT",lastMessage:{text:"Your order is ready for pickup!",senderId:"seller-1",timestamp:new Date(Date.now()-3e5),type:"TEXT"},myUnreadCount:2},{id:"CONV-2",participants:[{userId:s.id,name:s.name},{userId:"farmer-1",name:"Kisan Ramesh"}],type:"ORDER_CHAT",orderId:"SO-12345",lastMessage:{text:"Fresh tomatoes available now",senderId:"farmer-1",timestamp:new Date(Date.now()-36e5),type:"TEXT"},myUnreadCount:0}])}finally{N(!1)}},F=async t=>{S(!0);try{const c=localStorage.getItem("villagelink_token"),a=await(await fetch(`${w}/api/chat/conversation/${t}/messages`,{headers:{Authorization:`Bearer ${c}`}})).json();a.success&&u(a.messages)}catch{u([{id:"MSG-1",senderId:"seller-1",senderName:"Sharma Dhaba",type:"TEXT",content:"Hello! Welcome to Sharma Dhaba",status:"READ",timestamp:new Date(Date.now()-72e5),reactions:[]},{id:"MSG-2",senderId:s.id,senderName:s.name,type:"TEXT",content:"Hi! I want to order lunch",status:"READ",timestamp:new Date(Date.now()-7e6),reactions:[]},{id:"MSG-3",senderId:"seller-1",senderName:"Sharma Dhaba",type:"TEXT",content:"Sure! Here is our menu for today",status:"READ",timestamp:new Date(Date.now()-68e5),reactions:[]},{id:"MSG-4",senderId:"seller-1",senderName:"Sharma Dhaba",type:"PRODUCT",content:"Shared a product",productData:{productId:"prod-1",name:"Thali Special",price:80,image:"https://via.placeholder.com/100"},status:"READ",timestamp:new Date(Date.now()-66e5),reactions:[]},{id:"MSG-5",senderId:"seller-1",senderName:"Sharma Dhaba",type:"TEXT",content:"Your order is ready for pickup!",status:"DELIVERED",timestamp:new Date(Date.now()-3e5),reactions:[]}])}finally{S(!1)}},T=async()=>{if(!m.trim()||!o)return;const t={id:`MSG-${Date.now()}`,senderId:s.id,senderName:s.name,type:"TEXT",content:m,status:"SENT",timestamp:new Date,reactions:[]};u([...f,t]),b("");try{const c=localStorage.getItem("villagelink_token"),p=i?`${w}/api/ai/chat`:`${w}/api/chat/conversation/${o?.id}/message`,r=await(await fetch(p,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${c}`},body:JSON.stringify(i?{prompt:m}:{type:"TEXT",content:m})})).json();if(r.success)if(i){const l={id:`AI-${Date.now()}`,senderId:"AI",senderName:"Gram Sahayak",type:"TEXT",content:r.response,status:"READ",timestamp:new Date,reactions:[]};u(h=>[...h,l])}else u(l=>l.map(h=>h.id===t.id?{...r.message,status:"SENT"}:h))}catch{}},_=()=>{$.current?.scrollIntoView({behavior:"smooth"})},k=t=>{j(t),F(t.id)},C=t=>t.participants.find(c=>c.userId!==s.id),E=t=>new Date(t).toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"}),L=t=>{const c=new Date(t),p=new Date;if(c.toDateString()===p.toDateString())return"Today";const a=new Date(p);return a.setDate(a.getDate()-1),c.toDateString()===a.toDateString()?"Yesterday":c.toLocaleDateString("en-IN",{day:"numeric",month:"short"})},R=d.filter(t=>C(t)?.name.toLowerCase().includes(D.toLowerCase()));if(!o&&!i)return e.jsxs("div",{className:"chat-section",children:[e.jsxs("div",{className:"chat-header",children:[e.jsx("h1",{children:"Messages"}),e.jsx("button",{className:"icon-btn","aria-label":"More options",children:e.jsx(pe,{className:"w-5 h-5"})})]}),e.jsxs("div",{className:"search-bar",children:[e.jsx(he,{className:"w-5 h-5 text-gray-400"}),e.jsx("input",{type:"text",placeholder:"Search conversations...",value:D,onChange:t=>I(t.target.value)})]}),e.jsx("div",{className:"conversation-list",children:g?e.jsxs("div",{className:"loading-state",children:[e.jsx(H,{className:"w-6 h-6 animate-spin"}),e.jsx("p",{children:"Loading conversations..."})]}):R.length===0?e.jsx("div",{className:"empty-state",children:e.jsx("p",{children:"No conversations yet"})}):R.map(t=>{const c=C(t);return e.jsxs("button",{className:"conversation-item",onClick:()=>k(t),children:[e.jsx("div",{className:"avatar",children:c?.name.charAt(0)}),e.jsxs("div",{className:"conv-info",children:[e.jsxs("div",{className:"conv-header",children:[e.jsx("span",{className:"conv-name",children:c?.name}),e.jsx("span",{className:"conv-time",children:L(new Date(t.lastMessage.timestamp))})]}),e.jsxs("div",{className:"conv-preview",children:[e.jsx("span",{className:"last-msg",children:t.lastMessage.text}),t.myUnreadCount>0&&e.jsx("span",{className:"unread-badge",children:t.myUnreadCount})]})]})]},t.id)})}),e.jsx("style",{children:K})]});const A=i?{name:"Gram Sahayak"}:C(o);return e.jsxs("div",{className:`chat-section ${i?"ai-mode":""}`,children:[e.jsxs("div",{className:`chat-header active-chat ${i?"ai-header":""}`,children:[!i&&e.jsx("button",{className:"back-btn","aria-label":"Go back",onClick:()=>j(null),children:e.jsx(ue,{className:"w-5 h-5"})}),e.jsx("div",{className:"avatar",children:A?.name.charAt(0)}),e.jsxs("div",{className:"chat-user-info",children:[e.jsx("span",{className:"user-name",children:A?.name}),e.jsx("span",{className:"user-status",children:"online"})]}),e.jsxs("div",{className:"chat-actions",children:[e.jsx("button",{className:"icon-btn","aria-label":"Voice call",children:e.jsx(xe,{className:"w-5 h-5"})}),e.jsx("button",{className:"icon-btn","aria-label":"Video call",children:e.jsx(ge,{className:"w-5 h-5"})})]})]}),e.jsx("div",{className:"messages-container",children:O?e.jsx("div",{className:"loading-state",children:e.jsx(H,{className:"w-6 h-6 animate-spin"})}):e.jsxs(e.Fragment,{children:[f.map((t,c)=>{const p=t.senderId===s.id,a=c===0||new Date(t.timestamp).toDateString()!==new Date(f[c-1].timestamp).toDateString();return e.jsxs(P.Fragment,{children:[a&&e.jsx("div",{className:"date-divider",children:e.jsx("span",{children:L(new Date(t.timestamp))})}),e.jsxs("div",{className:`message ${p?"sent":"received"}`,children:[t.type==="TEXT"&&e.jsxs("div",{className:"message-bubble",children:[e.jsx("p",{children:t.content}),e.jsxs("span",{className:"message-meta",children:[E(new Date(t.timestamp)),p&&(t.status==="READ"?e.jsx(fe,{className:"w-4 h-4 text-blue-500"}):e.jsx(be,{className:"w-4 h-4"}))]})]}),t.type==="PRODUCT"&&t.productData&&e.jsxs("div",{className:"message-bubble product-bubble",children:[e.jsxs("div",{className:"product-card",children:[e.jsx("img",{src:t.productData.image,alt:t.productData.name}),e.jsxs("div",{className:"product-info",children:[e.jsx("span",{className:"product-name",children:t.productData.name}),e.jsxs("span",{className:"product-price",children:["₹",t.productData.price]})]})]}),e.jsx("button",{className:"view-btn",children:"View Product"}),e.jsx("span",{className:"message-meta",children:E(new Date(t.timestamp))})]}),t.type==="LOCATION"&&t.locationData&&e.jsxs("div",{className:"message-bubble location-bubble",children:[e.jsxs("div",{className:"location-preview",children:[e.jsx(Y,{className:"w-6 h-6"}),e.jsxs("span",{children:["📍 ",t.locationData.address]})]}),e.jsx("button",{className:"view-btn",children:"Open in Maps"}),e.jsx("span",{className:"message-meta",children:E(new Date(t.timestamp))})]})]})]},t.id)}),e.jsx("div",{ref:$})]})}),v&&e.jsxs("div",{className:"attachment-menu",children:[e.jsxs("button",{className:"attach-option",children:[e.jsx("div",{className:"attach-icon bg-attach-gallery",children:e.jsx(we,{className:"w-5 h-5"})}),e.jsx("span",{children:"Gallery"})]}),e.jsxs("button",{className:"attach-option",children:[e.jsx("div",{className:"attach-icon bg-attach-camera",children:e.jsx(je,{className:"w-5 h-5"})}),e.jsx("span",{children:"Camera"})]}),e.jsxs("button",{className:"attach-option",children:[e.jsx("div",{className:"attach-icon bg-attach-location",children:e.jsx(Y,{className:"w-5 h-5"})}),e.jsx("span",{children:"Location"})]}),e.jsxs("button",{className:"attach-option",children:[e.jsx("div",{className:"attach-icon bg-attach-product",children:e.jsx(ve,{className:"w-5 h-5"})}),e.jsx("span",{children:"Product"})]})]}),e.jsxs("div",{className:"input-area",children:[e.jsx("button",{className:"icon-btn","aria-label":"Toggle attachments",onClick:()=>M(!v),children:v?e.jsx(q,{className:"w-5 h-5"}):e.jsx(ye,{className:"w-5 h-5"})}),e.jsxs("div",{className:"text-input-wrapper",children:[e.jsx("input",{ref:z,type:"text",placeholder:"Type a message...",value:m,onChange:t=>b(t.target.value),onKeyPress:t=>t.key==="Enter"&&T()}),e.jsx("button",{className:"emoji-btn","aria-label":"Insert emoji",children:e.jsx(Ne,{className:"w-5 h-5"})})]}),m.trim()?e.jsx("button",{className:"send-btn","aria-label":"Send message",onClick:T,children:e.jsx(Q,{className:"w-5 h-5"})}):e.jsx("button",{className:`mic-btn ${V?"recording":""}`,"aria-label":"Record voice message",onMouseDown:()=>B(!0),onMouseUp:()=>B(!1),children:e.jsx(ke,{className:"w-5 h-5"})})]}),e.jsx("style",{children:K})]})},K=`
  .chat-section {
    display: flex;
    flex-direction: column;
    height: calc(100vh - 140px);
    background: #f5f5f5;
  }

  .chat-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: white;
    border-bottom: 1px solid #e5e7eb;
  }

  .chat-header h1 {
    flex: 1;
    font-size: 1.25rem;
    font-weight: 600;
    color: #111827;
  }

  .chat-header.active-chat {
    background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
    color: white;
  }

  .back-btn {
    background: none;
    border: none;
    color: white;
    cursor: pointer;
    padding: 4px;
  }

  .avatar {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
    font-size: 1.1rem;
    flex-shrink: 0;
  }

  .chat-user-info {
    flex: 1;
  }

  .user-name {
    display: block;
    font-weight: 600;
  }

  .user-status {
    font-size: 0.75rem;
    opacity: 0.8;
  }

  .chat-actions {
    display: flex;
    gap: 8px;
  }

  .icon-btn {
    background: rgba(255,255,255,0.2);
    border: none;
    border-radius: 50%;
    padding: 8px;
    color: inherit;
    cursor: pointer;
  }

  .search-bar {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: white;
    border-bottom: 1px solid #e5e7eb;
  }

  .search-bar input {
    flex: 1;
    border: none;
    outline: none;
    font-size: 1rem;
  }

  .conversation-list {
    flex: 1;
    overflow-y: auto;
    background: white;
  }

  .conversation-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: white;
    border: none;
    border-bottom: 1px solid #f3f4f6;
    cursor: pointer;
    width: 100%;
    text-align: left;
    transition: background 0.2s;
  }

  .conversation-item:hover {
    background: #f9fafb;
  }

  .conv-info {
    flex: 1;
    min-width: 0;
  }

  .conv-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 4px;
  }

  .conv-name {
    font-weight: 600;
    color: #111827;
  }

  .conv-time {
    font-size: 0.75rem;
    color: #9ca3af;
  }

  .conv-preview {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .last-msg {
    font-size: 0.875rem;
    color: #6b7280;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    flex: 1;
  }

  .unread-badge {
    background: #22c55e;
    color: white;
    font-size: 0.7rem;
    padding: 2px 8px;
    border-radius: 10px;
    font-weight: 600;
  }

  .loading-state, .empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 200px;
    color: #9ca3af;
    gap: 8px;
  }

  .messages-container {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
    background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d1d5db' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
  }

  .date-divider {
    text-align: center;
    margin: 16px 0;
  }

  .date-divider span {
    background: rgba(0,0,0,0.1);
    color: #6b7280;
    font-size: 0.75rem;
    padding: 4px 12px;
    border-radius: 10px;
  }

  .message {
    display: flex;
    margin-bottom: 8px;
  }

  .message.sent {
    justify-content: flex-end;
  }

  .message.received {
    justify-content: flex-start;
  }

  .message-bubble {
    max-width: 75%;
    padding: 10px 14px;
    border-radius: 16px;
    position: relative;
  }

  .sent .message-bubble {
    background: #dcfce7;
    border-bottom-right-radius: 4px;
  }

  .received .message-bubble {
    background: white;
    border-bottom-left-radius: 4px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  }

  .message-bubble p {
    margin: 0;
    color: #111827;
    font-size: 0.9375rem;
  }

  .message-meta {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 4px;
    margin-top: 4px;
    font-size: 0.7rem;
    color: #9ca3af;
  }

  .product-bubble {
    padding: 8px;
  }

  .product-card {
    display: flex;
    gap: 12px;
    margin-bottom: 8px;
  }

  .product-card img {
    width: 60px;
    height: 60px;
    border-radius: 8px;
    object-fit: cover;
  }

  .product-info {
    display: flex;
    flex-direction: column;
    justify-content: center;
  }

  .product-name {
    font-weight: 600;
    color: #111827;
  }

  .product-price {
    color: #22c55e;
    font-weight: 600;
  }

  .view-btn {
    display: block;
    width: 100%;
    padding: 8px;
    background: #f3f4f6;
    border: none;
    border-radius: 8px;
    color: #3b82f6;
    font-weight: 500;
    cursor: pointer;
    margin-bottom: 8px;
  }

  .location-preview {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px;
    background: #f3f4f6;
    border-radius: 8px;
    margin-bottom: 8px;
  }

  .attachment-menu {
    display: flex;
    justify-content: space-around;
    padding: 16px;
    background: white;
    border-top: 1px solid #e5e7eb;
  }

  .attach-option {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    background: none;
    border: none;
    cursor: pointer;
    color: #374151;
    font-size: 0.75rem;
  }

  .attach-icon {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
  }

  .input-area {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: white;
    border-top: 1px solid #e5e7eb;
  }

  .text-input-wrapper {
    flex: 1;
    display: flex;
    align-items: center;
    background: #f3f4f6;
    border-radius: 24px;
    padding: 8px 16px;
  }

  .text-input-wrapper input {
    flex: 1;
    border: none;
    outline: none;
    background: transparent;
    font-size: 1rem;
  }

  .emoji-btn {
    background: none;
    border: none;
    color: #9ca3af;
    cursor: pointer;
  }

  .send-btn, .mic-btn {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
  }

  .send-btn {
    background: #22c55e;
    color: white;
  }

  .mic-btn {
    background: #f3f4f6;
    color: #374151;
  }

  .mic-btn.recording {
    background: #ef4444;
    color: white;
    animation: pulse 1s infinite;
  }

  @keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
  }
`,Ie=W("Geolocation",{web:()=>Z(()=>import("./web-D6lRJW5D.js"),__vite__mapDeps([0,1,2,3,4])).then(s=>new s.GeolocationWeb)});ee();export{Pe as C,Ie as G,Re as R};
