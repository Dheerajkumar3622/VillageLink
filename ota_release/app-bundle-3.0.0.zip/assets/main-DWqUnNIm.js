const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["views/PassengerView-C5y6awzv.js","assets/synapse-DJbL7Np4.js","assets/vendor-react-BR5y8XGT.js","assets/vendor-socket-TjCxX7sJ.js","assets/synapse-HV_l4fLf.css","assets/constants-CSAIR7Rh.js","assets/mlService-Bs6DwhV3.js","assets/blockchainService-B4N5Ogdy.js","assets/LocationSelector-Jcc1jE6F.js","assets/vendor-ui-C2GrFI-5.js","assets/Modal-DXxO_P8Y.js","assets/advancedFeatures-CV2JTQEo.js","views/UserProfile-DiQsBBn2.js","assets/marketingService-B16yCu59.js","views/FoodLinkHome-BCtb-CJK.js","assets/PassengerView-E5z7JNaV.css","views/DriverView-B4DpsSpR.js","assets/adminService-DYIzXK5E.js","views/AdminView-BUzbuDKI.js","views/ShopkeeperView-CjinT01B.js","views/MessManagerView-C3Oj5qR_.js","views/VendorView-DuESuoFU.js","views/VyaparSaathiView-D7MFrKB4.js","views/LuxeOSView-BtEZK-gB.js","views/VillageManagerView-BRuH_m4v.js","views/KisanApp-CuIkvKOe.js","views/DriverApp-DHAnxidA.js","views/VyapariApp-CZknXxE2.js","views/MessApp-Dg9iHf2o.js","views/StorageApp-DZY6hRlx.js","views/LogisticsApp-Z8h-lm7r.js","views/UserPanel-Cjo2rth4.js","views/CargoShipmentView-DzfFpbTW.js","views/UserApp-CDxcL-ad.js","views/GramMandiHome-Bugv-ecD.js","assets/index-B8VbTDW_.js","views/ProviderApp-R70YWdCg.js","assets/web-btCmyIj0.js","assets/web-oUPHiLW5.js"])))=>i.map(i=>d[i]);
import{j as o,B as Ze,l as Lr,r as Bs,a as Hs,b as $s,c as zs,d as Ws,e as Gs,g as Sn,A as dr,f as vr,_ as k,i as Et,V as F,P as Ks,h as qs,k as Rn,m as Js,n as Xs}from"./synapse-DJbL7Np4.js";import{r as m,R as Ys}from"./vendor-react-BR5y8XGT.js";import{T as Dr,i as Mr}from"./constants-CSAIR7Rh.js";import{L as kn,S as xn,M as Cn,a as Zs,U as Qs,b as $t,c as It,A as ei,d as ti,e as ri,f as ni,g as si,P as ii,h as ai,B as oi,C as ci,T as li,i as di,K as zt,j as ui}from"./vendor-ui-C2GrFI-5.js";import{g as Ur}from"./adminService-DYIzXK5E.js";import"./vendor-socket-TjCxX7sJ.js";const hi=()=>{};var jr={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const An=function(t){const e=[];let r=0;for(let n=0;n<t.length;n++){let s=t.charCodeAt(n);s<128?e[r++]=s:s<2048?(e[r++]=s>>6|192,e[r++]=s&63|128):(s&64512)===55296&&n+1<t.length&&(t.charCodeAt(n+1)&64512)===56320?(s=65536+((s&1023)<<10)+(t.charCodeAt(++n)&1023),e[r++]=s>>18|240,e[r++]=s>>12&63|128,e[r++]=s>>6&63|128,e[r++]=s&63|128):(e[r++]=s>>12|224,e[r++]=s>>6&63|128,e[r++]=s&63|128)}return e},fi=function(t){const e=[];let r=0,n=0;for(;r<t.length;){const s=t[r++];if(s<128)e[n++]=String.fromCharCode(s);else if(s>191&&s<224){const i=t[r++];e[n++]=String.fromCharCode((s&31)<<6|i&63)}else if(s>239&&s<365){const i=t[r++],a=t[r++],c=t[r++],l=((s&7)<<18|(i&63)<<12|(a&63)<<6|c&63)-65536;e[n++]=String.fromCharCode(55296+(l>>10)),e[n++]=String.fromCharCode(56320+(l&1023))}else{const i=t[r++],a=t[r++];e[n++]=String.fromCharCode((s&15)<<12|(i&63)<<6|a&63)}}return e.join("")},Nn={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(t,e){if(!Array.isArray(t))throw Error("encodeByteArray takes an array as a parameter");this.init_();const r=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,n=[];for(let s=0;s<t.length;s+=3){const i=t[s],a=s+1<t.length,c=a?t[s+1]:0,l=s+2<t.length,d=l?t[s+2]:0,f=i>>2,u=(i&3)<<4|c>>4;let h=(c&15)<<2|d>>6,_=d&63;l||(_=64,a||(h=64)),n.push(r[f],r[u],r[h],r[_])}return n.join("")},encodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(t):this.encodeByteArray(An(t),e)},decodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(t):fi(this.decodeStringToByteArray(t,e))},decodeStringToByteArray(t,e){this.init_();const r=e?this.charToByteMapWebSafe_:this.charToByteMap_,n=[];for(let s=0;s<t.length;){const i=r[t.charAt(s++)],c=s<t.length?r[t.charAt(s)]:0;++s;const d=s<t.length?r[t.charAt(s)]:64;++s;const u=s<t.length?r[t.charAt(s)]:64;if(++s,i==null||c==null||d==null||u==null)throw new pi;const h=i<<2|c>>4;if(n.push(h),d!==64){const _=c<<4&240|d>>2;if(n.push(_),u!==64){const I=d<<6&192|u;n.push(I)}}}return n},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let t=0;t<this.ENCODED_VALS.length;t++)this.byteToCharMap_[t]=this.ENCODED_VALS.charAt(t),this.charToByteMap_[this.byteToCharMap_[t]]=t,this.byteToCharMapWebSafe_[t]=this.ENCODED_VALS_WEBSAFE.charAt(t),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]]=t,t>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)]=t,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)]=t)}}};class pi extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const mi=function(t){const e=An(t);return Nn.encodeByteArray(e,!0)},Pn=function(t){return mi(t).replace(/\./g,"")},On=function(t){try{return Nn.decodeString(t,!0)}catch{}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gi(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wi=()=>gi().__FIREBASE_DEFAULTS__,_i=()=>{if(typeof process>"u"||typeof jr>"u")return;const t=jr.__FIREBASE_DEFAULTS__;if(t)return JSON.parse(t)},bi=()=>{if(typeof document>"u")return;let t;try{t=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=t&&On(t[1]);return e&&JSON.parse(e)},Er=()=>{try{return hi()||wi()||_i()||bi()}catch{return}},yi=t=>Er()?.emulatorHosts?.[t],Ln=()=>Er()?.config,Dn=t=>Er()?.[`_${t}`];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vi{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,r)=>{this.resolve=e,this.reject=r})}wrapCallback(e){return(r,n)=>{r?this.reject(r):this.resolve(n),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(r):e(r,n))}}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Mt(t){try{return(t.startsWith("http://")||t.startsWith("https://")?new URL(t).hostname:t).endsWith(".cloudworkstations.dev")}catch{return!1}}async function Ei(t){return(await fetch(t,{credentials:"include"})).ok}const tt={};function Ii(){const t={prod:[],emulator:[]};for(const e of Object.keys(tt))tt[e]?t.emulator.push(e):t.prod.push(e);return t}function Ti(t){let e=document.getElementById(t),r=!1;return e||(e=document.createElement("div"),e.setAttribute("id",t),r=!0),{created:r,element:e}}let Vr=!1;function Si(t,e){if(typeof window>"u"||typeof document>"u"||!Mt(window.location.host)||tt[t]===e||tt[t]||Vr)return;tt[t]=e;function r(h){return`__firebase__banner__${h}`}const n="__firebase__banner",i=Ii().prod.length>0;function a(){const h=document.getElementById(n);h&&h.remove()}function c(h){h.style.display="flex",h.style.background="#7faaf0",h.style.position="fixed",h.style.bottom="5px",h.style.left="5px",h.style.padding=".5em",h.style.borderRadius="5px",h.style.alignItems="center"}function l(h,_){h.setAttribute("width","24"),h.setAttribute("id",_),h.setAttribute("height","24"),h.setAttribute("viewBox","0 0 24 24"),h.setAttribute("fill","none"),h.style.marginLeft="-6px"}function d(){const h=document.createElement("span");return h.style.cursor="pointer",h.style.marginLeft="16px",h.style.fontSize="24px",h.innerHTML=" &times;",h.onclick=()=>{Vr=!0,a()},h}function f(h,_){h.setAttribute("id",_),h.innerText="Learn more",h.href="https://firebase.google.com/docs/studio/preview-apps#preview-backend",h.setAttribute("target","__blank"),h.style.paddingLeft="5px",h.style.textDecoration="underline"}function u(){const h=Ti(n),_=r("text"),I=document.getElementById(_)||document.createElement("span"),b=r("learnmore"),v=document.getElementById(b)||document.createElement("a"),C=r("preprendIcon"),S=document.getElementById(C)||document.createElementNS("http://www.w3.org/2000/svg","svg");if(h.created){const R=h.element;c(R),f(v,b);const Y=d();l(S,C),R.append(S,I,v,Y),document.body.appendChild(R)}i?(I.innerText="Preview backend disconnected.",S.innerHTML=`<g clip-path="url(#clip0_6013_33858)">
<path d="M4.8 17.6L12 5.6L19.2 17.6H4.8ZM6.91667 16.4H17.0833L12 7.93333L6.91667 16.4ZM12 15.6C12.1667 15.6 12.3056 15.5444 12.4167 15.4333C12.5389 15.3111 12.6 15.1667 12.6 15C12.6 14.8333 12.5389 14.6944 12.4167 14.5833C12.3056 14.4611 12.1667 14.4 12 14.4C11.8333 14.4 11.6889 14.4611 11.5667 14.5833C11.4556 14.6944 11.4 14.8333 11.4 15C11.4 15.1667 11.4556 15.3111 11.5667 15.4333C11.6889 15.5444 11.8333 15.6 12 15.6ZM11.4 13.6H12.6V10.4H11.4V13.6Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6013_33858">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`):(S.innerHTML=`<g clip-path="url(#clip0_6083_34804)">
<path d="M11.4 15.2H12.6V11.2H11.4V15.2ZM12 10C12.1667 10 12.3056 9.94444 12.4167 9.83333C12.5389 9.71111 12.6 9.56667 12.6 9.4C12.6 9.23333 12.5389 9.09444 12.4167 8.98333C12.3056 8.86111 12.1667 8.8 12 8.8C11.8333 8.8 11.6889 8.86111 11.5667 8.98333C11.4556 9.09444 11.4 9.23333 11.4 9.4C11.4 9.56667 11.4556 9.71111 11.5667 9.83333C11.6889 9.94444 11.8333 10 12 10ZM12 18.4C11.1222 18.4 10.2944 18.2333 9.51667 17.9C8.73889 17.5667 8.05556 17.1111 7.46667 16.5333C6.88889 15.9444 6.43333 15.2611 6.1 14.4833C5.76667 13.7056 5.6 12.8778 5.6 12C5.6 11.1111 5.76667 10.2833 6.1 9.51667C6.43333 8.73889 6.88889 8.06111 7.46667 7.48333C8.05556 6.89444 8.73889 6.43333 9.51667 6.1C10.2944 5.76667 11.1222 5.6 12 5.6C12.8889 5.6 13.7167 5.76667 14.4833 6.1C15.2611 6.43333 15.9389 6.89444 16.5167 7.48333C17.1056 8.06111 17.5667 8.73889 17.9 9.51667C18.2333 10.2833 18.4 11.1111 18.4 12C18.4 12.8778 18.2333 13.7056 17.9 14.4833C17.5667 15.2611 17.1056 15.9444 16.5167 16.5333C15.9389 17.1111 15.2611 17.5667 14.4833 17.9C13.7167 18.2333 12.8889 18.4 12 18.4ZM12 17.2C13.4444 17.2 14.6722 16.6944 15.6833 15.6833C16.6944 14.6722 17.2 13.4444 17.2 12C17.2 10.5556 16.6944 9.32778 15.6833 8.31667C14.6722 7.30555 13.4444 6.8 12 6.8C10.5556 6.8 9.32778 7.30555 8.31667 8.31667C7.30556 9.32778 6.8 10.5556 6.8 12C6.8 13.4444 7.30556 14.6722 8.31667 15.6833C9.32778 16.6944 10.5556 17.2 12 17.2Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6083_34804">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`,I.innerText="Preview backend running in this workspace."),I.setAttribute("id",_)}document.readyState==="loading"?window.addEventListener("DOMContentLoaded",u):u()}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function D(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Ri(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(D())}function ki(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function xi(){const t=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof t=="object"&&t.id!==void 0}function Ci(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function Ai(){const t=D();return t.indexOf("MSIE ")>=0||t.indexOf("Trident/")>=0}function Ni(){try{return typeof indexedDB=="object"}catch{return!1}}function Pi(){return new Promise((t,e)=>{try{let r=!0;const n="validate-browser-context-for-indexeddb-analytics-module",s=self.indexedDB.open(n);s.onsuccess=()=>{s.result.close(),r||self.indexedDB.deleteDatabase(n),t(!0)},s.onupgradeneeded=()=>{r=!1},s.onerror=()=>{e(s.error?.message||"")}}catch(r){e(r)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Oi="FirebaseError";class me extends Error{constructor(e,r,n){super(r),this.code=e,this.customData=n,this.name=Oi,Object.setPrototypeOf(this,me.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,dt.prototype.create)}}class dt{constructor(e,r,n){this.service=e,this.serviceName=r,this.errors=n}create(e,...r){const n=r[0]||{},s=`${this.service}/${e}`,i=this.errors[e],a=i?Li(i,n):"Error",c=`${this.serviceName}: ${a} (${s}).`;return new me(s,c,n)}}function Li(t,e){return t.replace(Di,(r,n)=>{const s=e[n];return s!=null?String(s):`<${n}?>`})}const Di=/\{\$([^}]+)}/g;function Mi(t){for(const e in t)if(Object.prototype.hasOwnProperty.call(t,e))return!1;return!0}function $e(t,e){if(t===e)return!0;const r=Object.keys(t),n=Object.keys(e);for(const s of r){if(!n.includes(s))return!1;const i=t[s],a=e[s];if(Fr(i)&&Fr(a)){if(!$e(i,a))return!1}else if(i!==a)return!1}for(const s of n)if(!r.includes(s))return!1;return!0}function Fr(t){return t!==null&&typeof t=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ge(t){const e=[];for(const[r,n]of Object.entries(t))Array.isArray(n)?n.forEach(s=>{e.push(encodeURIComponent(r)+"="+encodeURIComponent(s))}):e.push(encodeURIComponent(r)+"="+encodeURIComponent(n));return e.length?"&"+e.join("&"):""}function Ui(t,e){const r=new ji(t,e);return r.subscribe.bind(r)}class ji{constructor(e,r){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=r,this.task.then(()=>{e(this)}).catch(n=>{this.error(n)})}next(e){this.forEachObserver(r=>{r.next(e)})}error(e){this.forEachObserver(r=>{r.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,r,n){let s;if(e===void 0&&r===void 0&&n===void 0)throw new Error("Missing Observer.");Vi(e,["next","error","complete"])?s=e:s={next:e,error:r,complete:n},s.next===void 0&&(s.next=Wt),s.error===void 0&&(s.error=Wt),s.complete===void 0&&(s.complete=Wt);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?s.error(this.finalError):s.complete()}catch{}}),this.observers.push(s),i}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let r=0;r<this.observers.length;r++)this.sendOne(r,e)}sendOne(e,r){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{r(this.observers[e])}catch{}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function Vi(t,e){if(typeof t!="object"||t===null)return!1;for(const r of e)if(r in t&&typeof t[r]=="function")return!0;return!1}function Wt(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xe(t){return t&&t._delegate?t._delegate:t}class ze{constructor(e,r,n){this.name=e,this.instanceFactory=r,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Te="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fi{constructor(e,r){this.name=e,this.container=r,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const r=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(r)){const n=new vi;if(this.instancesDeferred.set(r,n),this.isInitialized(r)||this.shouldAutoInitialize())try{const s=this.getOrInitializeService({instanceIdentifier:r});s&&n.resolve(s)}catch{}}return this.instancesDeferred.get(r).promise}getImmediate(e){const r=this.normalizeInstanceIdentifier(e?.identifier),n=e?.optional??!1;if(this.isInitialized(r)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:r})}catch(s){if(n)return null;throw s}else{if(n)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(Hi(e))try{this.getOrInitializeService({instanceIdentifier:Te})}catch{}for(const[r,n]of this.instancesDeferred.entries()){const s=this.normalizeInstanceIdentifier(r);try{const i=this.getOrInitializeService({instanceIdentifier:s});n.resolve(i)}catch{}}}}clearInstance(e=Te){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(r=>"INTERNAL"in r).map(r=>r.INTERNAL.delete()),...e.filter(r=>"_delete"in r).map(r=>r._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Te){return this.instances.has(e)}getOptions(e=Te){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:r={}}=e,n=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(n))throw Error(`${this.name}(${n}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const s=this.getOrInitializeService({instanceIdentifier:n,options:r});for(const[i,a]of this.instancesDeferred.entries()){const c=this.normalizeInstanceIdentifier(i);n===c&&a.resolve(s)}return s}onInit(e,r){const n=this.normalizeInstanceIdentifier(r),s=this.onInitCallbacks.get(n)??new Set;s.add(e),this.onInitCallbacks.set(n,s);const i=this.instances.get(n);return i&&e(i,n),()=>{s.delete(e)}}invokeOnInitCallbacks(e,r){const n=this.onInitCallbacks.get(r);if(n)for(const s of n)try{s(e,r)}catch{}}getOrInitializeService({instanceIdentifier:e,options:r={}}){let n=this.instances.get(e);if(!n&&this.component&&(n=this.component.instanceFactory(this.container,{instanceIdentifier:Bi(e),options:r}),this.instances.set(e,n),this.instancesOptions.set(e,r),this.invokeOnInitCallbacks(n,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,n)}catch{}return n||null}normalizeInstanceIdentifier(e=Te){return this.component?this.component.multipleInstances?e:Te:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Bi(t){return t===Te?void 0:t}function Hi(t){return t.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $i{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const r=this.getProvider(e.name);if(r.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);r.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const r=new Fi(e,this);return this.providers.set(e,r),r}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var E;(function(t){t[t.DEBUG=0]="DEBUG",t[t.VERBOSE=1]="VERBOSE",t[t.INFO=2]="INFO",t[t.WARN=3]="WARN",t[t.ERROR=4]="ERROR",t[t.SILENT=5]="SILENT"})(E||(E={}));const zi={debug:E.DEBUG,verbose:E.VERBOSE,info:E.INFO,warn:E.WARN,error:E.ERROR,silent:E.SILENT},Wi=E.INFO,Gi={[E.DEBUG]:"log",[E.VERBOSE]:"log",[E.INFO]:"info",[E.WARN]:"warn",[E.ERROR]:"error"},Ki=(t,e,...r)=>{if(e<t.logLevel)return;const n=new Date().toISOString(),s=Gi[e];if(!s)throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Mn{constructor(e){this.name=e,this._logLevel=Wi,this._logHandler=Ki,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in E))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?zi[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,E.DEBUG,...e),this._logHandler(this,E.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,E.VERBOSE,...e),this._logHandler(this,E.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,E.INFO,...e),this._logHandler(this,E.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,E.WARN,...e),this._logHandler(this,E.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,E.ERROR,...e),this._logHandler(this,E.ERROR,...e)}}const qi=(t,e)=>e.some(r=>t instanceof r);let Br,Hr;function Ji(){return Br||(Br=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Xi(){return Hr||(Hr=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Un=new WeakMap,ur=new WeakMap,jn=new WeakMap,Gt=new WeakMap,Ir=new WeakMap;function Yi(t){const e=new Promise((r,n)=>{const s=()=>{t.removeEventListener("success",i),t.removeEventListener("error",a)},i=()=>{r(he(t.result)),s()},a=()=>{n(t.error),s()};t.addEventListener("success",i),t.addEventListener("error",a)});return e.then(r=>{r instanceof IDBCursor&&Un.set(r,t)}).catch(()=>{}),Ir.set(e,t),e}function Zi(t){if(ur.has(t))return;const e=new Promise((r,n)=>{const s=()=>{t.removeEventListener("complete",i),t.removeEventListener("error",a),t.removeEventListener("abort",a)},i=()=>{r(),s()},a=()=>{n(t.error||new DOMException("AbortError","AbortError")),s()};t.addEventListener("complete",i),t.addEventListener("error",a),t.addEventListener("abort",a)});ur.set(t,e)}let hr={get(t,e,r){if(t instanceof IDBTransaction){if(e==="done")return ur.get(t);if(e==="objectStoreNames")return t.objectStoreNames||jn.get(t);if(e==="store")return r.objectStoreNames[1]?void 0:r.objectStore(r.objectStoreNames[0])}return he(t[e])},set(t,e,r){return t[e]=r,!0},has(t,e){return t instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in t}};function Qi(t){hr=t(hr)}function ea(t){return t===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...r){const n=t.call(Kt(this),e,...r);return jn.set(n,e.sort?e.sort():[e]),he(n)}:Xi().includes(t)?function(...e){return t.apply(Kt(this),e),he(Un.get(this))}:function(...e){return he(t.apply(Kt(this),e))}}function ta(t){return typeof t=="function"?ea(t):(t instanceof IDBTransaction&&Zi(t),qi(t,Ji())?new Proxy(t,hr):t)}function he(t){if(t instanceof IDBRequest)return Yi(t);if(Gt.has(t))return Gt.get(t);const e=ta(t);return e!==t&&(Gt.set(t,e),Ir.set(e,t)),e}const Kt=t=>Ir.get(t);function ra(t,e,{blocked:r,upgrade:n,blocking:s,terminated:i}={}){const a=indexedDB.open(t,e),c=he(a);return n&&a.addEventListener("upgradeneeded",l=>{n(he(a.result),l.oldVersion,l.newVersion,he(a.transaction),l)}),r&&a.addEventListener("blocked",l=>r(l.oldVersion,l.newVersion,l)),c.then(l=>{i&&l.addEventListener("close",()=>i()),s&&l.addEventListener("versionchange",d=>s(d.oldVersion,d.newVersion,d))}).catch(()=>{}),c}const na=["get","getKey","getAll","getAllKeys","count"],sa=["put","add","delete","clear"],qt=new Map;function $r(t,e){if(!(t instanceof IDBDatabase&&!(e in t)&&typeof e=="string"))return;if(qt.get(e))return qt.get(e);const r=e.replace(/FromIndex$/,""),n=e!==r,s=sa.includes(r);if(!(r in(n?IDBIndex:IDBObjectStore).prototype)||!(s||na.includes(r)))return;const i=async function(a,...c){const l=this.transaction(a,s?"readwrite":"readonly");let d=l.store;return n&&(d=d.index(c.shift())),(await Promise.all([d[r](...c),s&&l.done]))[0]};return qt.set(e,i),i}Qi(t=>({...t,get:(e,r,n)=>$r(e,r)||t.get(e,r,n),has:(e,r)=>!!$r(e,r)||t.has(e,r)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ia{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(r=>{if(aa(r)){const n=r.getImmediate();return`${n.library}/${n.version}`}else return null}).filter(r=>r).join(" ")}}function aa(t){return t.getComponent()?.type==="VERSION"}const fr="@firebase/app",zr="0.14.7";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const te=new Mn("@firebase/app"),oa="@firebase/app-compat",ca="@firebase/analytics-compat",la="@firebase/analytics",da="@firebase/app-check-compat",ua="@firebase/app-check",ha="@firebase/auth",fa="@firebase/auth-compat",pa="@firebase/database",ma="@firebase/data-connect",ga="@firebase/database-compat",wa="@firebase/functions",_a="@firebase/functions-compat",ba="@firebase/installations",ya="@firebase/installations-compat",va="@firebase/messaging",Ea="@firebase/messaging-compat",Ia="@firebase/performance",Ta="@firebase/performance-compat",Sa="@firebase/remote-config",Ra="@firebase/remote-config-compat",ka="@firebase/storage",xa="@firebase/storage-compat",Ca="@firebase/firestore",Aa="@firebase/ai",Na="@firebase/firestore-compat",Pa="firebase",Oa="12.8.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pr="[DEFAULT]",La={[fr]:"fire-core",[oa]:"fire-core-compat",[la]:"fire-analytics",[ca]:"fire-analytics-compat",[ua]:"fire-app-check",[da]:"fire-app-check-compat",[ha]:"fire-auth",[fa]:"fire-auth-compat",[pa]:"fire-rtdb",[ma]:"fire-data-connect",[ga]:"fire-rtdb-compat",[wa]:"fire-fn",[_a]:"fire-fn-compat",[ba]:"fire-iid",[ya]:"fire-iid-compat",[va]:"fire-fcm",[Ea]:"fire-fcm-compat",[Ia]:"fire-perf",[Ta]:"fire-perf-compat",[Sa]:"fire-rc",[Ra]:"fire-rc-compat",[ka]:"fire-gcs",[xa]:"fire-gcs-compat",[Ca]:"fire-fst",[Na]:"fire-fst-compat",[Aa]:"fire-vertex","fire-js":"fire-js",[Pa]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ct=new Map,Da=new Map,mr=new Map;function Wr(t,e){try{t.container.addComponent(e)}catch(r){te.debug(`Component ${e.name} failed to register with FirebaseApp ${t.name}`,r)}}function ot(t){const e=t.name;if(mr.has(e))return te.debug(`There were multiple attempts to register component ${e}.`),!1;mr.set(e,t);for(const r of Ct.values())Wr(r,t);for(const r of Da.values())Wr(r,t);return!0}function Vn(t,e){const r=t.container.getProvider("heartbeat").getImmediate({optional:!0});return r&&r.triggerHeartbeat(),t.container.getProvider(e)}function q(t){return t==null?!1:t.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ma={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},fe=new dt("app","Firebase",Ma);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ua{constructor(e,r,n){this._isDeleted=!1,this._options={...e},this._config={...r},this._name=r.name,this._automaticDataCollectionEnabled=r.automaticDataCollectionEnabled,this._container=n,this.container.addComponent(new ze("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw fe.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ut=Oa;function Fn(t,e={}){let r=t;typeof e!="object"&&(e={name:e});const n={name:pr,automaticDataCollectionEnabled:!0,...e},s=n.name;if(typeof s!="string"||!s)throw fe.create("bad-app-name",{appName:String(s)});if(r||(r=Ln()),!r)throw fe.create("no-options");const i=Ct.get(s);if(i){if($e(r,i.options)&&$e(n,i.config))return i;throw fe.create("duplicate-app",{appName:s})}const a=new $i(s);for(const l of mr.values())a.addComponent(l);const c=new Ua(r,n,a);return Ct.set(s,c),c}function ja(t=pr){const e=Ct.get(t);if(!e&&t===pr&&Ln())return Fn();if(!e)throw fe.create("no-app",{appName:t});return e}function je(t,e,r){let n=La[t]??t;r&&(n+=`-${r}`);const s=n.match(/\s|\//),i=e.match(/\s|\//);if(s||i){const a=[`Unable to register library "${n}" with version "${e}":`];s&&a.push(`library name "${n}" contains illegal characters (whitespace or "/")`),s&&i&&a.push("and"),i&&a.push(`version name "${e}" contains illegal characters (whitespace or "/")`),te.warn(a.join(" "));return}ot(new ze(`${n}-version`,()=>({library:n,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Va="firebase-heartbeat-database",Fa=1,ct="firebase-heartbeat-store";let Jt=null;function Bn(){return Jt||(Jt=ra(Va,Fa,{upgrade:(t,e)=>{switch(e){case 0:try{t.createObjectStore(ct)}catch{}}}}).catch(t=>{throw fe.create("idb-open",{originalErrorMessage:t.message})})),Jt}async function Ba(t){try{const r=(await Bn()).transaction(ct),n=await r.objectStore(ct).get(Hn(t));return await r.done,n}catch(e){if(e instanceof me)te.warn(e.message);else{const r=fe.create("idb-get",{originalErrorMessage:e?.message});te.warn(r.message)}}}async function Gr(t,e){try{const n=(await Bn()).transaction(ct,"readwrite");await n.objectStore(ct).put(e,Hn(t)),await n.done}catch(r){if(r instanceof me)te.warn(r.message);else{const n=fe.create("idb-set",{originalErrorMessage:r?.message});te.warn(n.message)}}}function Hn(t){return`${t.name}!${t.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ha=1024,$a=30;class za{constructor(e){this.container=e,this._heartbeatsCache=null;const r=this.container.getProvider("app").getImmediate();this._storage=new Ga(r),this._heartbeatsCachePromise=this._storage.read().then(n=>(this._heartbeatsCache=n,n))}async triggerHeartbeat(){try{const r=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),n=Kr();if(this._heartbeatsCache?.heartbeats==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,this._heartbeatsCache?.heartbeats==null)||this._heartbeatsCache.lastSentHeartbeatDate===n||this._heartbeatsCache.heartbeats.some(s=>s.date===n))return;if(this._heartbeatsCache.heartbeats.push({date:n,agent:r}),this._heartbeatsCache.heartbeats.length>$a){const s=Ka(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(s,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(e){te.warn(e)}}async getHeartbeatsHeader(){try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,this._heartbeatsCache?.heartbeats==null||this._heartbeatsCache.heartbeats.length===0)return"";const e=Kr(),{heartbeatsToSend:r,unsentEntries:n}=Wa(this._heartbeatsCache.heartbeats),s=Pn(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=e,n.length>0?(this._heartbeatsCache.heartbeats=n,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),s}catch(e){return te.warn(e),""}}}function Kr(){return new Date().toISOString().substring(0,10)}function Wa(t,e=Ha){const r=[];let n=t.slice();for(const s of t){const i=r.find(a=>a.agent===s.agent);if(i){if(i.dates.push(s.date),qr(r)>e){i.dates.pop();break}}else if(r.push({agent:s.agent,dates:[s.date]}),qr(r)>e){r.pop();break}n=n.slice(1)}return{heartbeatsToSend:r,unsentEntries:n}}class Ga{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Ni()?Pi().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const r=await Ba(this.app);return r?.heartbeats?r:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const n=await this.read();return Gr(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??n.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const n=await this.read();return Gr(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??n.lastSentHeartbeatDate,heartbeats:[...n.heartbeats,...e.heartbeats]})}else return}}function qr(t){return Pn(JSON.stringify({version:2,heartbeats:t})).length}function Ka(t){if(t.length===0)return-1;let e=0,r=t[0].date;for(let n=1;n<t.length;n++)t[n].date<r&&(r=t[n].date,e=n);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qa(t){ot(new ze("platform-logger",e=>new ia(e),"PRIVATE")),ot(new ze("heartbeat",e=>new za(e),"PRIVATE")),je(fr,zr,t),je(fr,zr,"esm2020"),je("fire-js","")}qa("");var Ja="firebase",Xa="12.8.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */je(Ja,Xa,"app");function $n(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Ya=$n,zn=new dt("auth","Firebase",$n());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const At=new Mn("@firebase/auth");function Za(t,...e){At.logLevel<=E.WARN&&At.warn(`Auth (${ut}): ${t}`,...e)}function St(t,...e){At.logLevel<=E.ERROR&&At.error(`Auth (${ut}): ${t}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function re(t,...e){throw Tr(t,...e)}function V(t,...e){return Tr(t,...e)}function Wn(t,e,r){const n={...Ya(),[e]:r};return new dt("auth","Firebase",n).create(e,{appName:t.name})}function pe(t){return Wn(t,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Tr(t,...e){if(typeof t!="string"){const r=e[0],n=[...e.slice(1)];return n[0]&&(n[0].appName=t.name),t._errorFactory.create(r,...n)}return zn.create(t,...e)}function p(t,e,...r){if(!t)throw Tr(e,...r)}function Q(t){const e="INTERNAL ASSERTION FAILED: "+t;throw St(e),new Error(e)}function ne(t,e){t||Q(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gr(){return typeof self<"u"&&self.location?.href||""}function Gn(){return Jr()==="http:"||Jr()==="https:"}function Jr(){return typeof self<"u"&&self.location?.protocol||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qa(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Gn()||xi()||"connection"in navigator)?navigator.onLine:!0}function eo(){if(typeof navigator>"u")return null;const t=navigator;return t.languages&&t.languages[0]||t.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ht{constructor(e,r){this.shortDelay=e,this.longDelay=r,ne(r>e,"Short delay should be less than long delay!"),this.isMobile=Ri()||Ci()}get(){return Qa()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sr(t,e){ne(t.emulator,"Emulator should always be set here");const{url:r}=t.emulator;return e?`${r}${e.startsWith("/")?e.slice(1):e}`:r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kn{static initialize(e,r,n){this.fetchImpl=e,r&&(this.headersImpl=r),n&&(this.responseImpl=n)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;Q("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;Q("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;Q("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const to={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ro=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],no=new ht(3e4,6e4);function X(t,e){return t.tenantId&&!e.tenantId?{...e,tenantId:t.tenantId}:e}async function G(t,e,r,n,s={}){return qn(t,s,async()=>{let i={},a={};n&&(e==="GET"?a=n:i={body:JSON.stringify(n)});const c=Ge({key:t.config.apiKey,...a}).slice(1),l=await t._getAdditionalHeaders();l["Content-Type"]="application/json",t.languageCode&&(l["X-Firebase-Locale"]=t.languageCode);const d={method:e,headers:l,...i};return ki()||(d.referrerPolicy="no-referrer"),t.emulatorConfig&&Mt(t.emulatorConfig.host)&&(d.credentials="include"),Kn.fetch()(await Jn(t,t.config.apiHost,r,c),d)})}async function qn(t,e,r){t._canInitEmulator=!1;const n={...to,...e};try{const s=new io(t),i=await Promise.race([r(),s.promise]);s.clearNetworkTimeout();const a=await i.json();if("needConfirmation"in a)throw et(t,"account-exists-with-different-credential",a);if(i.ok&&!("errorMessage"in a))return a;{const c=i.ok?a.errorMessage:a.error.message,[l,d]=c.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw et(t,"credential-already-in-use",a);if(l==="EMAIL_EXISTS")throw et(t,"email-already-in-use",a);if(l==="USER_DISABLED")throw et(t,"user-disabled",a);const f=n[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(d)throw Wn(t,f,d);re(t,f)}}catch(s){if(s instanceof me)throw s;re(t,"network-request-failed",{message:String(s)})}}async function Ut(t,e,r,n,s={}){const i=await G(t,e,r,n,s);return"mfaPendingCredential"in i&&re(t,"multi-factor-auth-required",{_serverResponse:i}),i}async function Jn(t,e,r,n){const s=`${e}${r}?${n}`,i=t,a=i.config.emulator?Sr(t.config,s):`${t.config.apiScheme}://${s}`;return ro.includes(r)&&(await i._persistenceManagerAvailable,i._getPersistenceType()==="COOKIE")?i._getPersistence()._getFinalTarget(a).toString():a}function so(t){switch(t){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class io{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((r,n)=>{this.timer=setTimeout(()=>n(V(this.auth,"network-request-failed")),no.get())})}}function et(t,e,r){const n={appName:t.name};r.email&&(n.email=r.email),r.phoneNumber&&(n.phoneNumber=r.phoneNumber);const s=V(t,e,n);return s.customData._tokenResponse=r,s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xr(t){return t!==void 0&&t.getResponse!==void 0}function Yr(t){return t!==void 0&&t.enterprise!==void 0}class Xn{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const r of this.recaptchaEnforcementState)if(r.provider&&r.provider===e)return so(r.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}isAnyProviderEnabled(){return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")||this.isProviderEnabled("PHONE_PROVIDER")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ao(t){return(await G(t,"GET","/v1/recaptchaParams")).recaptchaSiteKey||""}async function Yn(t,e){return G(t,"GET","/v2/recaptchaConfig",X(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function oo(t,e){return G(t,"POST","/v1/accounts:delete",e)}async function Nt(t,e){return G(t,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rt(t){if(t)try{const e=new Date(Number(t));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function co(t,e=!1){const r=xe(t),n=await r.getIdToken(e),s=Rr(n);p(s&&s.exp&&s.auth_time&&s.iat,r.auth,"internal-error");const i=typeof s.firebase=="object"?s.firebase:void 0,a=i?.sign_in_provider;return{claims:s,token:n,authTime:rt(Xt(s.auth_time)),issuedAtTime:rt(Xt(s.iat)),expirationTime:rt(Xt(s.exp)),signInProvider:a||null,signInSecondFactor:i?.sign_in_second_factor||null}}function Xt(t){return Number(t)*1e3}function Rr(t){const[e,r,n]=t.split(".");if(e===void 0||r===void 0||n===void 0)return St("JWT malformed, contained fewer than 3 sections"),null;try{const s=On(r);return s?JSON.parse(s):(St("Failed to decode base64 JWT payload"),null)}catch(s){return St("Caught error parsing JWT payload as JSON",s?.toString()),null}}function Zr(t){const e=Rr(t);return p(e,"internal-error"),p(typeof e.exp<"u","internal-error"),p(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function lt(t,e,r=!1){if(r)return e;try{return await e}catch(n){throw n instanceof me&&lo(n)&&t.auth.currentUser===t&&await t.auth.signOut(),n}}function lo({code:t}){return t==="auth/user-disabled"||t==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uo{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const r=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),r}else{this.errorBackoff=3e4;const n=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,n)}}schedule(e=!1){if(!this.isRunning)return;const r=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},r)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){e?.code==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wr{constructor(e,r){this.createdAt=e,this.lastLoginAt=r,this._initializeTime()}_initializeTime(){this.lastSignInTime=rt(this.lastLoginAt),this.creationTime=rt(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Pt(t){const e=t.auth,r=await t.getIdToken(),n=await lt(t,Nt(e,{idToken:r}));p(n?.users.length,e,"internal-error");const s=n.users[0];t._notifyReloadListener(s);const i=s.providerUserInfo?.length?Zn(s.providerUserInfo):[],a=fo(t.providerData,i),c=t.isAnonymous,l=!(t.email&&s.passwordHash)&&!a?.length,d=c?l:!1,f={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:a,metadata:new wr(s.createdAt,s.lastLoginAt),isAnonymous:d};Object.assign(t,f)}async function ho(t){const e=xe(t);await Pt(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function fo(t,e){return[...t.filter(n=>!e.some(s=>s.providerId===n.providerId)),...e]}function Zn(t){return t.map(({providerId:e,...r})=>({providerId:e,uid:r.rawId||"",displayName:r.displayName||null,email:r.email||null,phoneNumber:r.phoneNumber||null,photoURL:r.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function po(t,e){const r=await qn(t,{},async()=>{const n=Ge({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:s,apiKey:i}=t.config,a=await Jn(t,s,"/v1/token",`key=${i}`),c=await t._getAdditionalHeaders();c["Content-Type"]="application/x-www-form-urlencoded";const l={method:"POST",headers:c,body:n};return t.emulatorConfig&&Mt(t.emulatorConfig.host)&&(l.credentials="include"),Kn.fetch()(a,l)});return{accessToken:r.access_token,expiresIn:r.expires_in,refreshToken:r.refresh_token}}async function mo(t,e){return G(t,"POST","/v2/accounts:revokeToken",X(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ve{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){p(e.idToken,"internal-error"),p(typeof e.idToken<"u","internal-error"),p(typeof e.refreshToken<"u","internal-error");const r="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):Zr(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,r)}updateFromIdToken(e){p(e.length!==0,"internal-error");const r=Zr(e);this.updateTokensAndExpiration(e,null,r)}async getToken(e,r=!1){return!r&&this.accessToken&&!this.isExpired?this.accessToken:(p(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,r){const{accessToken:n,refreshToken:s,expiresIn:i}=await po(e,r);this.updateTokensAndExpiration(n,s,Number(i))}updateTokensAndExpiration(e,r,n){this.refreshToken=r||null,this.accessToken=e||null,this.expirationTime=Date.now()+n*1e3}static fromJSON(e,r){const{refreshToken:n,accessToken:s,expirationTime:i}=r,a=new Ve;return n&&(p(typeof n=="string","internal-error",{appName:e}),a.refreshToken=n),s&&(p(typeof s=="string","internal-error",{appName:e}),a.accessToken=s),i&&(p(typeof i=="number","internal-error",{appName:e}),a.expirationTime=i),a}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new Ve,this.toJSON())}_performRefresh(){return Q("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ae(t,e){p(typeof t=="string"||typeof t>"u","internal-error",{appName:e})}class W{constructor({uid:e,auth:r,stsTokenManager:n,...s}){this.providerId="firebase",this.proactiveRefresh=new uo(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=r,this.stsTokenManager=n,this.accessToken=n.accessToken,this.displayName=s.displayName||null,this.email=s.email||null,this.emailVerified=s.emailVerified||!1,this.phoneNumber=s.phoneNumber||null,this.photoURL=s.photoURL||null,this.isAnonymous=s.isAnonymous||!1,this.tenantId=s.tenantId||null,this.providerData=s.providerData?[...s.providerData]:[],this.metadata=new wr(s.createdAt||void 0,s.lastLoginAt||void 0)}async getIdToken(e){const r=await lt(this,this.stsTokenManager.getToken(this.auth,e));return p(r,this.auth,"internal-error"),this.accessToken!==r&&(this.accessToken=r,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),r}getIdTokenResult(e){return co(this,e)}reload(){return ho(this)}_assign(e){this!==e&&(p(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(r=>({...r})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const r=new W({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return r.metadata._copy(this.metadata),r}_onReload(e){p(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,r=!1){let n=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),n=!0),r&&await Pt(this),await this.auth._persistUserIfCurrent(this),n&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(q(this.auth.app))return Promise.reject(pe(this.auth));const e=await this.getIdToken();return await lt(this,oo(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,r){const n=r.displayName??void 0,s=r.email??void 0,i=r.phoneNumber??void 0,a=r.photoURL??void 0,c=r.tenantId??void 0,l=r._redirectEventId??void 0,d=r.createdAt??void 0,f=r.lastLoginAt??void 0,{uid:u,emailVerified:h,isAnonymous:_,providerData:I,stsTokenManager:b}=r;p(u&&b,e,"internal-error");const v=Ve.fromJSON(this.name,b);p(typeof u=="string",e,"internal-error"),ae(n,e.name),ae(s,e.name),p(typeof h=="boolean",e,"internal-error"),p(typeof _=="boolean",e,"internal-error"),ae(i,e.name),ae(a,e.name),ae(c,e.name),ae(l,e.name),ae(d,e.name),ae(f,e.name);const C=new W({uid:u,auth:e,email:s,emailVerified:h,displayName:n,isAnonymous:_,photoURL:a,phoneNumber:i,tenantId:c,stsTokenManager:v,createdAt:d,lastLoginAt:f});return I&&Array.isArray(I)&&(C.providerData=I.map(S=>({...S}))),l&&(C._redirectEventId=l),C}static async _fromIdTokenResponse(e,r,n=!1){const s=new Ve;s.updateFromServerResponse(r);const i=new W({uid:r.localId,auth:e,stsTokenManager:s,isAnonymous:n});return await Pt(i),i}static async _fromGetAccountInfoResponse(e,r,n){const s=r.users[0];p(s.localId!==void 0,"internal-error");const i=s.providerUserInfo!==void 0?Zn(s.providerUserInfo):[],a=!(s.email&&s.passwordHash)&&!i?.length,c=new Ve;c.updateFromIdToken(n);const l=new W({uid:s.localId,auth:e,stsTokenManager:c,isAnonymous:a}),d={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:i,metadata:new wr(s.createdAt,s.lastLoginAt),isAnonymous:!(s.email&&s.passwordHash)&&!i?.length};return Object.assign(l,d),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qr=new Map;function ee(t){ne(t instanceof Function,"Expected a class definition");let e=Qr.get(t);return e?(ne(e instanceof t,"Instance stored in cache mismatched with class"),e):(e=new t,Qr.set(t,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qn{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,r){this.storage[e]=r}async _get(e){const r=this.storage[e];return r===void 0?null:r}async _remove(e){delete this.storage[e]}_addListener(e,r){}_removeListener(e,r){}}Qn.type="NONE";const en=Qn;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rt(t,e,r){return`firebase:${t}:${e}:${r}`}class Fe{constructor(e,r,n){this.persistence=e,this.auth=r,this.userKey=n;const{config:s,name:i}=this.auth;this.fullUserKey=Rt(this.userKey,s.apiKey,i),this.fullPersistenceKey=Rt("persistence",s.apiKey,i),this.boundEventHandler=r._onStorageEvent.bind(r),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const r=await Nt(this.auth,{idToken:e}).catch(()=>{});return r?W._fromGetAccountInfoResponse(this.auth,r,e):null}return W._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const r=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,r)return this.setCurrentUser(r)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,r,n="authUser"){if(!r.length)return new Fe(ee(en),e,n);const s=(await Promise.all(r.map(async d=>{if(await d._isAvailable())return d}))).filter(d=>d);let i=s[0]||ee(en);const a=Rt(n,e.config.apiKey,e.name);let c=null;for(const d of r)try{const f=await d._get(a);if(f){let u;if(typeof f=="string"){const h=await Nt(e,{idToken:f}).catch(()=>{});if(!h)break;u=await W._fromGetAccountInfoResponse(e,h,f)}else u=W._fromJSON(e,f);d!==i&&(c=u),i=d;break}}catch{}const l=s.filter(d=>d._shouldAllowMigration);return!i._shouldAllowMigration||!l.length?new Fe(i,e,n):(i=l[0],c&&await i._set(a,c.toJSON()),await Promise.all(r.map(async d=>{if(d!==i)try{await d._remove(a)}catch{}})),new Fe(i,e,n))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tn(t){const e=t.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(ns(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(es(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(is(e))return"Blackberry";if(as(e))return"Webos";if(ts(e))return"Safari";if((e.includes("chrome/")||rs(e))&&!e.includes("edge/"))return"Chrome";if(ss(e))return"Android";{const r=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,n=t.match(r);if(n?.length===2)return n[1]}return"Other"}function es(t=D()){return/firefox\//i.test(t)}function ts(t=D()){const e=t.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function rs(t=D()){return/crios\//i.test(t)}function ns(t=D()){return/iemobile/i.test(t)}function ss(t=D()){return/android/i.test(t)}function is(t=D()){return/blackberry/i.test(t)}function as(t=D()){return/webos/i.test(t)}function kr(t=D()){return/iphone|ipad|ipod/i.test(t)||/macintosh/i.test(t)&&/mobile/i.test(t)}function go(t=D()){return kr(t)&&!!window.navigator?.standalone}function wo(){return Ai()&&document.documentMode===10}function os(t=D()){return kr(t)||ss(t)||as(t)||is(t)||/windows phone/i.test(t)||ns(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cs(t,e=[]){let r;switch(t){case"Browser":r=tn(D());break;case"Worker":r=`${tn(D())}-${t}`;break;default:r=t}const n=e.length?e.join(","):"FirebaseCore-web";return`${r}/JsCore/${ut}/${n}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _o{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,r){const n=i=>new Promise((a,c)=>{try{const l=e(i);a(l)}catch(l){c(l)}});n.onAbort=r,this.queue.push(n);const s=this.queue.length-1;return()=>{this.queue[s]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const r=[];try{for(const n of this.queue)await n(e),n.onAbort&&r.push(n.onAbort)}catch(n){r.reverse();for(const s of r)try{s()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:n?.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function bo(t,e={}){return G(t,"GET","/v2/passwordPolicy",X(t,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yo=6;class vo{constructor(e){const r=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=r.minPasswordLength??yo,r.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=r.maxPasswordLength),r.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=r.containsLowercaseCharacter),r.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=r.containsUppercaseCharacter),r.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=r.containsNumericCharacter),r.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=r.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=e.allowedNonAlphanumericCharacters?.join("")??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const r={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,r),this.validatePasswordCharacterOptions(e,r),r.isValid&&(r.isValid=r.meetsMinPasswordLength??!0),r.isValid&&(r.isValid=r.meetsMaxPasswordLength??!0),r.isValid&&(r.isValid=r.containsLowercaseLetter??!0),r.isValid&&(r.isValid=r.containsUppercaseLetter??!0),r.isValid&&(r.isValid=r.containsNumericCharacter??!0),r.isValid&&(r.isValid=r.containsNonAlphanumericCharacter??!0),r}validatePasswordLengthOptions(e,r){const n=this.customStrengthOptions.minPasswordLength,s=this.customStrengthOptions.maxPasswordLength;n&&(r.meetsMinPasswordLength=e.length>=n),s&&(r.meetsMaxPasswordLength=e.length<=s)}validatePasswordCharacterOptions(e,r){this.updatePasswordCharacterOptionsStatuses(r,!1,!1,!1,!1);let n;for(let s=0;s<e.length;s++)n=e.charAt(s),this.updatePasswordCharacterOptionsStatuses(r,n>="a"&&n<="z",n>="A"&&n<="Z",n>="0"&&n<="9",this.allowedNonAlphanumericCharacters.includes(n))}updatePasswordCharacterOptionsStatuses(e,r,n,s,i){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=r)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=n)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=s)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Eo{constructor(e,r,n,s){this.app=e,this.heartbeatServiceProvider=r,this.appCheckServiceProvider=n,this.config=s,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new rn(this),this.idTokenSubscription=new rn(this),this.beforeStateQueue=new _o(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=zn,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=s.sdkClientVersion,this._persistenceManagerAvailable=new Promise(i=>this._resolvePersistenceManagerAvailable=i)}_initializeWithPersistence(e,r){return r&&(this._popupRedirectResolver=ee(r)),this._initializationPromise=this.queue(async()=>{if(!this._deleted&&(this.persistenceManager=await Fe.create(this,e),this._resolvePersistenceManagerAvailable?.(),!this._deleted)){if(this._popupRedirectResolver?._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(r),this.lastNotifiedUid=this.currentUser?.uid||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const r=await Nt(this,{idToken:e}),n=await W._fromGetAccountInfoResponse(this,r,e);await this.directlySetCurrentUser(n)}catch{await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){if(q(this.app)){const i=this.app.settings.authIdToken;return i?new Promise(a=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(i).then(a,a))}):this.directlySetCurrentUser(null)}const r=await this.assertedPersistence.getCurrentUser();let n=r,s=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const i=this.redirectUser?._redirectEventId,a=n?._redirectEventId,c=await this.tryRedirectSignIn(e);(!i||i===a)&&c?.user&&(n=c.user,s=!0)}if(!n)return this.directlySetCurrentUser(null);if(!n._redirectEventId){if(s)try{await this.beforeStateQueue.runMiddleware(n)}catch(i){n=r,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(i))}return n?this.reloadAndSetCurrentUserOrClear(n):this.directlySetCurrentUser(null)}return p(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===n._redirectEventId?this.directlySetCurrentUser(n):this.reloadAndSetCurrentUserOrClear(n)}async tryRedirectSignIn(e){let r=null;try{r=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return r}async reloadAndSetCurrentUserOrClear(e){try{await Pt(e)}catch(r){if(r?.code!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=eo()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(q(this.app))return Promise.reject(pe(this));const r=e?xe(e):null;return r&&p(r.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(r&&r._clone(this))}async _updateCurrentUser(e,r=!1){if(!this._deleted)return e&&p(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),r||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return q(this.app)?Promise.reject(pe(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return q(this.app)?Promise.reject(pe(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(ee(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const r=this._getPasswordPolicyInternal();return r.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):r.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await bo(this),r=new vo(e);this.tenantId===null?this._projectPasswordPolicy=r:this._tenantPasswordPolicies[this.tenantId]=r}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new dt("auth","Firebase",e())}onAuthStateChanged(e,r,n){return this.registerStateListener(this.authStateSubscription,e,r,n)}beforeAuthStateChanged(e,r){return this.beforeStateQueue.pushCallback(e,r)}onIdTokenChanged(e,r,n){return this.registerStateListener(this.idTokenSubscription,e,r,n)}authStateReady(){return new Promise((e,r)=>{if(this.currentUser)e();else{const n=this.onAuthStateChanged(()=>{n(),e()},r)}})}async revokeAccessToken(e){if(this.currentUser){const r=await this.currentUser.getIdToken(),n={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:r};this.tenantId!=null&&(n.tenantId=this.tenantId),await mo(this,n)}}toJSON(){return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:this._currentUser?.toJSON()}}async _setRedirectUser(e,r){const n=await this.getOrInitRedirectPersistenceManager(r);return e===null?n.removeCurrentUser():n.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const r=e&&ee(e)||this._popupRedirectResolver;p(r,this,"argument-error"),this.redirectPersistenceManager=await Fe.create(this,[ee(r._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){return this._isInitialized&&await this.queue(async()=>{}),this._currentUser?._redirectEventId===e?this._currentUser:this.redirectUser?._redirectEventId===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=this.currentUser?.uid??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,r,n,s){if(this._deleted)return()=>{};const i=typeof r=="function"?r:r.next.bind(r);let a=!1;const c=this._isInitialized?Promise.resolve():this._initializationPromise;if(p(c,this,"internal-error"),c.then(()=>{a||i(this.currentUser)}),typeof r=="function"){const l=e.addObserver(r,n,s);return()=>{a=!0,l()}}else{const l=e.addObserver(r);return()=>{a=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return p(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=cs(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const r=await this.heartbeatServiceProvider.getImmediate({optional:!0})?.getHeartbeatsHeader();r&&(e["X-Firebase-Client"]=r);const n=await this._getAppCheckToken();return n&&(e["X-Firebase-AppCheck"]=n),e}async _getAppCheckToken(){if(q(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await this.appCheckServiceProvider.getImmediate({optional:!0})?.getToken();return e?.error&&Za(`Error while retrieving App Check token: ${e.error}`),e?.token}}function ge(t){return xe(t)}class rn{constructor(e){this.auth=e,this.observer=null,this.addObserver=Ui(r=>this.observer=r)}get next(){return p(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ft={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function Io(t){ft=t}function xr(t){return ft.loadJS(t)}function To(){return ft.recaptchaV2Script}function So(){return ft.recaptchaEnterpriseScript}function Ro(){return ft.gapiScript}function ls(t){return`__${t}${Math.floor(Math.random()*1e6)}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ko=500,xo=6e4,Tt=1e12;class Co{constructor(e){this.auth=e,this.counter=Tt,this._widgets=new Map}render(e,r){const n=this.counter;return this._widgets.set(n,new Po(e,this.auth.name,r||{})),this.counter++,n}reset(e){const r=e||Tt;this._widgets.get(r)?.delete(),this._widgets.delete(r)}getResponse(e){const r=e||Tt;return this._widgets.get(r)?.getResponse()||""}async execute(e){const r=e||Tt;return this._widgets.get(r)?.execute(),""}}class Ao{constructor(){this.enterprise=new No}ready(e){e()}execute(e,r){return Promise.resolve("token")}render(e,r){return""}}class No{ready(e){e()}execute(e,r){return Promise.resolve("token")}render(e,r){return""}}class Po{constructor(e,r,n){this.params=n,this.timerId=null,this.deleted=!1,this.responseToken=null,this.clickHandler=()=>{this.execute()};const s=typeof e=="string"?document.getElementById(e):e;p(s,"argument-error",{appName:r}),this.container=s,this.isVisible=this.params.size!=="invisible",this.isVisible?this.execute():this.container.addEventListener("click",this.clickHandler)}getResponse(){return this.checkIfDeleted(),this.responseToken}delete(){this.checkIfDeleted(),this.deleted=!0,this.timerId&&(clearTimeout(this.timerId),this.timerId=null),this.container.removeEventListener("click",this.clickHandler)}execute(){this.checkIfDeleted(),!this.timerId&&(this.timerId=window.setTimeout(()=>{this.responseToken=Oo(50);const{callback:e,"expired-callback":r}=this.params;if(e)try{e(this.responseToken)}catch{}this.timerId=window.setTimeout(()=>{if(this.timerId=null,this.responseToken=null,r)try{r()}catch{}this.isVisible&&this.execute()},xo)},ko))}checkIfDeleted(){if(this.deleted)throw new Error("reCAPTCHA mock was already deleted!")}}function Oo(t){const e=[],r="1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";for(let n=0;n<t;n++)e.push(r.charAt(Math.floor(Math.random()*r.length)));return e.join("")}const Lo="recaptcha-enterprise",nt="NO_RECAPTCHA";class ds{constructor(e){this.type=Lo,this.auth=ge(e)}async verify(e="verify",r=!1){async function n(i){if(!r){if(i.tenantId==null&&i._agentRecaptchaConfig!=null)return i._agentRecaptchaConfig.siteKey;if(i.tenantId!=null&&i._tenantRecaptchaConfigs[i.tenantId]!==void 0)return i._tenantRecaptchaConfigs[i.tenantId].siteKey}return new Promise(async(a,c)=>{Yn(i,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(l=>{if(l.recaptchaKey===void 0)c(new Error("recaptcha Enterprise site key undefined"));else{const d=new Xn(l);return i.tenantId==null?i._agentRecaptchaConfig=d:i._tenantRecaptchaConfigs[i.tenantId]=d,a(d.siteKey)}}).catch(l=>{c(l)})})}function s(i,a,c){const l=window.grecaptcha;Yr(l)?l.enterprise.ready(()=>{l.enterprise.execute(i,{action:e}).then(d=>{a(d)}).catch(()=>{a(nt)})}):c(Error("No reCAPTCHA enterprise script loaded."))}return this.auth.settings.appVerificationDisabledForTesting?new Ao().execute("siteKey",{action:"verify"}):new Promise((i,a)=>{n(this.auth).then(c=>{if(!r&&Yr(window.grecaptcha))s(c,i,a);else{if(typeof window>"u"){a(new Error("RecaptchaVerifier is only supported in browser"));return}let l=So();l.length!==0&&(l+=c),xr(l).then(()=>{s(c,i,a)}).catch(d=>{a(d)})}}).catch(c=>{a(c)})})}}async function Yt(t,e,r,n=!1,s=!1){const i=new ds(t);let a;if(s)a=nt;else try{a=await i.verify(r)}catch{a=await i.verify(r,!0)}const c={...e};if(r==="mfaSmsEnrollment"||r==="mfaSmsSignIn"){if("phoneEnrollmentInfo"in c){const l=c.phoneEnrollmentInfo.phoneNumber,d=c.phoneEnrollmentInfo.recaptchaToken;Object.assign(c,{phoneEnrollmentInfo:{phoneNumber:l,recaptchaToken:d,captchaResponse:a,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}else if("phoneSignInInfo"in c){const l=c.phoneSignInInfo.recaptchaToken;Object.assign(c,{phoneSignInInfo:{recaptchaToken:l,captchaResponse:a,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}return c}return n?Object.assign(c,{captchaResp:a}):Object.assign(c,{captchaResponse:a}),Object.assign(c,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(c,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),c}async function Zt(t,e,r,n,s){if(t._getRecaptchaConfig()?.isProviderEnabled("PHONE_PROVIDER")){const i=await Yt(t,e,r);return n(t,i).catch(async a=>{if(t._getRecaptchaConfig()?.getProviderEnforcementState("PHONE_PROVIDER")==="AUDIT"&&(a.code==="auth/missing-recaptcha-token"||a.code==="auth/invalid-app-credential")){const c=await Yt(t,e,r,!1,!0);return n(t,c)}return Promise.reject(a)})}else{const i=await Yt(t,e,r,!1,!0);return n(t,i)}}async function Do(t){const e=ge(t),r=await Yn(e,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}),n=new Xn(r);e.tenantId==null?e._agentRecaptchaConfig=n:e._tenantRecaptchaConfigs[e.tenantId]=n,n.isAnyProviderEnabled()&&new ds(e).verify()}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Mo(t,e){const r=Vn(t,"auth");if(r.isInitialized()){const s=r.getImmediate(),i=r.getOptions();if($e(i,e??{}))return s;re(s,"already-initialized")}return r.initialize({options:e})}function Uo(t,e){const r=e?.persistence||[],n=(Array.isArray(r)?r:[r]).map(ee);e?.errorMap&&t._updateErrorMap(e.errorMap),t._initializeWithPersistence(n,e?.popupRedirectResolver)}function jo(t,e,r){const n=ge(t);p(/^https?:\/\//.test(e),n,"invalid-emulator-scheme");const s=!1,i=us(e),{host:a,port:c}=Vo(e),l=c===null?"":`:${c}`,d={url:`${i}//${a}${l}/`},f=Object.freeze({host:a,port:c,protocol:i.replace(":",""),options:Object.freeze({disableWarnings:s})});if(!n._canInitEmulator){p(n.config.emulator&&n.emulatorConfig,n,"emulator-config-failed"),p($e(d,n.config.emulator)&&$e(f,n.emulatorConfig),n,"emulator-config-failed");return}n.config.emulator=d,n.emulatorConfig=f,n.settings.appVerificationDisabledForTesting=!0,Mt(a)?(Ei(`${i}//${a}${l}`),Si("Auth",!0)):Fo()}function us(t){const e=t.indexOf(":");return e<0?"":t.substr(0,e+1)}function Vo(t){const e=us(t),r=/(\/\/)?([^?#/]+)/.exec(t.substr(e.length));if(!r)return{host:"",port:null};const n=r[2].split("@").pop()||"",s=/^(\[[^\]]+\])(:|$)/.exec(n);if(s){const i=s[1];return{host:i,port:nn(n.substr(i.length+1))}}else{const[i,a]=n.split(":");return{host:i,port:nn(a)}}}function nn(t){if(!t)return null;const e=Number(t);return isNaN(e)?null:e}function Fo(){function t(){const e=document.createElement("p"),r=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",r.position="fixed",r.width="100%",r.backgroundColor="#ffffff",r.border=".1em solid #000000",r.color="#b50000",r.bottom="0px",r.left="0px",r.margin="0px",r.zIndex="10000",r.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",t):t())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cr{constructor(e,r){this.providerId=e,this.signInMethod=r}toJSON(){return Q("not implemented")}_getIdTokenResponse(e){return Q("not implemented")}_linkToIdToken(e,r){return Q("not implemented")}_getReauthenticationResolver(e){return Q("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Be(t,e){return Ut(t,"POST","/v1/accounts:signInWithIdp",X(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bo="http://localhost";class Re extends Cr{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const r=new Re(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(r.idToken=e.idToken),e.accessToken&&(r.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(r.nonce=e.nonce),e.pendingToken&&(r.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(r.accessToken=e.oauthToken,r.secret=e.oauthTokenSecret):re("argument-error"),r}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const r=typeof e=="string"?JSON.parse(e):e,{providerId:n,signInMethod:s,...i}=r;if(!n||!s)return null;const a=new Re(n,s);return a.idToken=i.idToken||void 0,a.accessToken=i.accessToken||void 0,a.secret=i.secret,a.nonce=i.nonce,a.pendingToken=i.pendingToken||null,a}_getIdTokenResponse(e){const r=this.buildRequest();return Be(e,r)}_linkToIdToken(e,r){const n=this.buildRequest();return n.idToken=r,Be(e,n)}_getReauthenticationResolver(e){const r=this.buildRequest();return r.autoCreate=!1,Be(e,r)}buildRequest(){const e={requestUri:Bo,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const r={};this.idToken&&(r.id_token=this.idToken),this.accessToken&&(r.access_token=this.accessToken),this.secret&&(r.oauth_token_secret=this.secret),r.providerId=this.providerId,this.nonce&&!this.pendingToken&&(r.nonce=this.nonce),e.postBody=Ge(r)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function sn(t,e){return G(t,"POST","/v1/accounts:sendVerificationCode",X(t,e))}async function Ho(t,e){return Ut(t,"POST","/v1/accounts:signInWithPhoneNumber",X(t,e))}async function $o(t,e){const r=await Ut(t,"POST","/v1/accounts:signInWithPhoneNumber",X(t,e));if(r.temporaryProof)throw et(t,"account-exists-with-different-credential",r);return r}const zo={USER_NOT_FOUND:"user-not-found"};async function Wo(t,e){const r={...e,operation:"REAUTH"};return Ut(t,"POST","/v1/accounts:signInWithPhoneNumber",X(t,r),zo)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class st extends Cr{constructor(e){super("phone","phone"),this.params=e}static _fromVerification(e,r){return new st({verificationId:e,verificationCode:r})}static _fromTokenResponse(e,r){return new st({phoneNumber:e,temporaryProof:r})}_getIdTokenResponse(e){return Ho(e,this._makeVerificationRequest())}_linkToIdToken(e,r){return $o(e,{idToken:r,...this._makeVerificationRequest()})}_getReauthenticationResolver(e){return Wo(e,this._makeVerificationRequest())}_makeVerificationRequest(){const{temporaryProof:e,phoneNumber:r,verificationId:n,verificationCode:s}=this.params;return e&&r?{temporaryProof:e,phoneNumber:r}:{sessionInfo:n,code:s}}toJSON(){const e={providerId:this.providerId};return this.params.phoneNumber&&(e.phoneNumber=this.params.phoneNumber),this.params.temporaryProof&&(e.temporaryProof=this.params.temporaryProof),this.params.verificationCode&&(e.verificationCode=this.params.verificationCode),this.params.verificationId&&(e.verificationId=this.params.verificationId),e}static fromJSON(e){typeof e=="string"&&(e=JSON.parse(e));const{verificationId:r,verificationCode:n,phoneNumber:s,temporaryProof:i}=e;return!n&&!r&&!s&&!i?null:new st({verificationId:r,verificationCode:n,phoneNumber:s,temporaryProof:i})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hs{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pt extends hs{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ce extends pt{constructor(){super("facebook.com")}static credential(e){return Re._fromParams({providerId:ce.PROVIDER_ID,signInMethod:ce.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return ce.credentialFromTaggedObject(e)}static credentialFromError(e){return ce.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return ce.credential(e.oauthAccessToken)}catch{return null}}}ce.FACEBOOK_SIGN_IN_METHOD="facebook.com";ce.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class le extends pt{constructor(){super("google.com"),this.addScope("profile")}static credential(e,r){return Re._fromParams({providerId:le.PROVIDER_ID,signInMethod:le.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:r})}static credentialFromResult(e){return le.credentialFromTaggedObject(e)}static credentialFromError(e){return le.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:r,oauthAccessToken:n}=e;if(!r&&!n)return null;try{return le.credential(r,n)}catch{return null}}}le.GOOGLE_SIGN_IN_METHOD="google.com";le.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class de extends pt{constructor(){super("github.com")}static credential(e){return Re._fromParams({providerId:de.PROVIDER_ID,signInMethod:de.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return de.credentialFromTaggedObject(e)}static credentialFromError(e){return de.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return de.credential(e.oauthAccessToken)}catch{return null}}}de.GITHUB_SIGN_IN_METHOD="github.com";de.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ue extends pt{constructor(){super("twitter.com")}static credential(e,r){return Re._fromParams({providerId:ue.PROVIDER_ID,signInMethod:ue.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:r})}static credentialFromResult(e){return ue.credentialFromTaggedObject(e)}static credentialFromError(e){return ue.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:r,oauthTokenSecret:n}=e;if(!r||!n)return null;try{return ue.credential(r,n)}catch{return null}}}ue.TWITTER_SIGN_IN_METHOD="twitter.com";ue.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class We{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,r,n,s=!1){const i=await W._fromIdTokenResponse(e,n,s),a=an(n);return new We({user:i,providerId:a,_tokenResponse:n,operationType:r})}static async _forOperation(e,r,n){await e._updateTokensIfNecessary(n,!0);const s=an(n);return new We({user:e,providerId:s,_tokenResponse:n,operationType:r})}}function an(t){return t.providerId?t.providerId:"phoneNumber"in t?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ot extends me{constructor(e,r,n,s){super(r.code,r.message),this.operationType=n,this.user=s,Object.setPrototypeOf(this,Ot.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:r.customData._serverResponse,operationType:n}}static _fromErrorAndOperation(e,r,n,s){return new Ot(e,r,n,s)}}function fs(t,e,r,n){return(e==="reauthenticate"?r._getReauthenticationResolver(t):r._getIdTokenResponse(t)).catch(i=>{throw i.code==="auth/multi-factor-auth-required"?Ot._fromErrorAndOperation(t,i,e,n):i})}async function Go(t,e,r=!1){const n=await lt(t,e._linkToIdToken(t.auth,await t.getIdToken()),r);return We._forOperation(t,"link",n)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ko(t,e,r=!1){const{auth:n}=t;if(q(n.app))return Promise.reject(pe(n));const s="reauthenticate";try{const i=await lt(t,fs(n,s,e,t),r);p(i.idToken,n,"internal-error");const a=Rr(i.idToken);p(a,n,"internal-error");const{sub:c}=a;return p(t.uid===c,n,"user-mismatch"),We._forOperation(t,s,i)}catch(i){throw i?.code==="auth/user-not-found"&&re(n,"user-mismatch"),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ps(t,e,r=!1){if(q(t.app))return Promise.reject(pe(t));const n="signIn",s=await fs(t,n,e),i=await We._fromIdTokenResponse(t,n,s);return r||await t._updateCurrentUser(i.user),i}async function qo(t,e){return ps(ge(t),e)}function Jo(t,e,r,n){return xe(t).onIdTokenChanged(e,r,n)}function Xo(t,e,r){return xe(t).beforeAuthStateChanged(e,r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function on(t,e){return G(t,"POST","/v2/accounts/mfaEnrollment:start",X(t,e))}const Lt="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ms{constructor(e,r){this.storageRetriever=e,this.type=r}_isAvailable(){try{return this.storage?(this.storage.setItem(Lt,"1"),this.storage.removeItem(Lt),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,r){return this.storage.setItem(e,JSON.stringify(r)),Promise.resolve()}_get(e){const r=this.storage.getItem(e);return Promise.resolve(r?JSON.parse(r):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Yo=1e3,Zo=10;class gs extends ms{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,r)=>this.onStorageEvent(e,r),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=os(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const r of Object.keys(this.listeners)){const n=this.storage.getItem(r),s=this.localCache[r];n!==s&&e(r,s,n)}}onStorageEvent(e,r=!1){if(!e.key){this.forAllChangedKeys((a,c,l)=>{this.notifyListeners(a,l)});return}const n=e.key;r?this.detachListener():this.stopPolling();const s=()=>{const a=this.storage.getItem(n);!r&&this.localCache[n]===a||this.notifyListeners(n,a)},i=this.storage.getItem(n);wo()&&i!==e.newValue&&e.newValue!==e.oldValue?setTimeout(s,Zo):s()}notifyListeners(e,r){this.localCache[e]=r;const n=this.listeners[e];if(n)for(const s of Array.from(n))s(r&&JSON.parse(r))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,r,n)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:r,newValue:n}),!0)})},Yo)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,r){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(r)}_removeListener(e,r){this.listeners[e]&&(this.listeners[e].delete(r),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,r){await super._set(e,r),this.localCache[e]=JSON.stringify(r)}async _get(e){const r=await super._get(e);return this.localCache[e]=JSON.stringify(r),r}async _remove(e){await super._remove(e),delete this.localCache[e]}}gs.type="LOCAL";const Qo=gs;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ws extends ms{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,r){}_removeListener(e,r){}}ws.type="SESSION";const _s=ws;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ec(t){return Promise.all(t.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(r){return{fulfilled:!1,reason:r}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jt{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const r=this.receivers.find(s=>s.isListeningto(e));if(r)return r;const n=new jt(e);return this.receivers.push(n),n}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const r=e,{eventId:n,eventType:s,data:i}=r.data,a=this.handlersMap[s];if(!a?.size)return;r.ports[0].postMessage({status:"ack",eventId:n,eventType:s});const c=Array.from(a).map(async d=>d(r.origin,i)),l=await ec(c);r.ports[0].postMessage({status:"done",eventId:n,eventType:s,response:l})}_subscribe(e,r){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(r)}_unsubscribe(e,r){this.handlersMap[e]&&r&&this.handlersMap[e].delete(r),(!r||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}jt.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ar(t="",e=10){let r="";for(let n=0;n<e;n++)r+=Math.floor(Math.random()*10);return t+r}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tc{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,r,n=50){const s=typeof MessageChannel<"u"?new MessageChannel:null;if(!s)throw new Error("connection_unavailable");let i,a;return new Promise((c,l)=>{const d=Ar("",20);s.port1.start();const f=setTimeout(()=>{l(new Error("unsupported_event"))},n);a={messageChannel:s,onMessage(u){const h=u;if(h.data.eventId===d)switch(h.data.status){case"ack":clearTimeout(f),i=setTimeout(()=>{l(new Error("timeout"))},3e3);break;case"done":clearTimeout(i),c(h.data.response);break;default:clearTimeout(f),clearTimeout(i),l(new Error("invalid_response"));break}}},this.handlers.add(a),s.port1.addEventListener("message",a.onMessage),this.target.postMessage({eventType:e,eventId:d,data:r},[s.port2])}).finally(()=>{a&&this.removeMessageHandler(a)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function x(){return window}function rc(t){x().location.href=t}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nr(){return typeof x().WorkerGlobalScope<"u"&&typeof x().importScripts=="function"}async function nc(){if(!navigator?.serviceWorker)return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function sc(){return navigator?.serviceWorker?.controller||null}function ic(){return Nr()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bs="firebaseLocalStorageDb",ac=1,Dt="firebaseLocalStorage",ys="fbase_key";class mt{constructor(e){this.request=e}toPromise(){return new Promise((e,r)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{r(this.request.error)})})}}function Vt(t,e){return t.transaction([Dt],e?"readwrite":"readonly").objectStore(Dt)}function oc(){const t=indexedDB.deleteDatabase(bs);return new mt(t).toPromise()}function _r(){const t=indexedDB.open(bs,ac);return new Promise((e,r)=>{t.addEventListener("error",()=>{r(t.error)}),t.addEventListener("upgradeneeded",()=>{const n=t.result;try{n.createObjectStore(Dt,{keyPath:ys})}catch(s){r(s)}}),t.addEventListener("success",async()=>{const n=t.result;n.objectStoreNames.contains(Dt)?e(n):(n.close(),await oc(),e(await _r()))})})}async function cn(t,e,r){const n=Vt(t,!0).put({[ys]:e,value:r});return new mt(n).toPromise()}async function cc(t,e){const r=Vt(t,!1).get(e),n=await new mt(r).toPromise();return n===void 0?null:n.value}function ln(t,e){const r=Vt(t,!0).delete(e);return new mt(r).toPromise()}const lc=800,dc=3;class vs{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await _r(),this.db)}async _withRetries(e){let r=0;for(;;)try{const n=await this._openDb();return await e(n)}catch(n){if(r++>dc)throw n;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Nr()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=jt._getInstance(ic()),this.receiver._subscribe("keyChanged",async(e,r)=>({keyProcessed:(await this._poll()).includes(r.key)})),this.receiver._subscribe("ping",async(e,r)=>["keyChanged"])}async initializeSender(){if(this.activeServiceWorker=await nc(),!this.activeServiceWorker)return;this.sender=new tc(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&e[0]?.fulfilled&&e[0]?.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||sc()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await _r();return await cn(e,Lt,"1"),await ln(e,Lt),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,r){return this._withPendingWrite(async()=>(await this._withRetries(n=>cn(n,e,r)),this.localCache[e]=r,this.notifyServiceWorker(e)))}async _get(e){const r=await this._withRetries(n=>cc(n,e));return this.localCache[e]=r,r}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(r=>ln(r,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(s=>{const i=Vt(s,!1).getAll();return new mt(i).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const r=[],n=new Set;if(e.length!==0)for(const{fbase_key:s,value:i}of e)n.add(s),JSON.stringify(this.localCache[s])!==JSON.stringify(i)&&(this.notifyListeners(s,i),r.push(s));for(const s of Object.keys(this.localCache))this.localCache[s]&&!n.has(s)&&(this.notifyListeners(s,null),r.push(s));return r}notifyListeners(e,r){this.localCache[e]=r;const n=this.listeners[e];if(n)for(const s of Array.from(n))s(r)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),lc)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,r){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(r)}_removeListener(e,r){this.listeners[e]&&(this.listeners[e].delete(r),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}vs.type="LOCAL";const uc=vs;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dn(t,e){return G(t,"POST","/v2/accounts/mfaSignIn:start",X(t,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qt=ls("rcb"),hc=new ht(3e4,6e4);class fc{constructor(){this.hostLanguage="",this.counter=0,this.librarySeparatelyLoaded=!!x().grecaptcha?.render}load(e,r=""){return p(pc(r),e,"argument-error"),this.shouldResolveImmediately(r)&&Xr(x().grecaptcha)?Promise.resolve(x().grecaptcha):new Promise((n,s)=>{const i=x().setTimeout(()=>{s(V(e,"network-request-failed"))},hc.get());x()[Qt]=()=>{x().clearTimeout(i),delete x()[Qt];const c=x().grecaptcha;if(!c||!Xr(c)){s(V(e,"internal-error"));return}const l=c.render;c.render=(d,f)=>{const u=l(d,f);return this.counter++,u},this.hostLanguage=r,n(c)};const a=`${To()}?${Ge({onload:Qt,render:"explicit",hl:r})}`;xr(a).catch(()=>{clearTimeout(i),s(V(e,"internal-error"))})})}clearedOneInstance(){this.counter--}shouldResolveImmediately(e){return!!x().grecaptcha?.render&&(e===this.hostLanguage||this.counter>0||this.librarySeparatelyLoaded)}}function pc(t){return t.length<=6&&/^\s*[a-zA-Z0-9\-]*\s*$/.test(t)}class mc{async load(e){return new Co(e)}clearedOneInstance(){}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const it="recaptcha",gc={theme:"light",type:"image"};class er{constructor(e,r,n={...gc}){this.parameters=n,this.type=it,this.destroyed=!1,this.widgetId=null,this.tokenChangeListeners=new Set,this.renderPromise=null,this.recaptcha=null,this.auth=ge(e),this.isInvisible=this.parameters.size==="invisible",p(typeof document<"u",this.auth,"operation-not-supported-in-this-environment");const s=typeof r=="string"?document.getElementById(r):r;p(s,this.auth,"argument-error"),this.container=s,this.parameters.callback=this.makeTokenCallback(this.parameters.callback),this._recaptchaLoader=this.auth.settings.appVerificationDisabledForTesting?new mc:new fc,this.validateStartingState()}async verify(){this.assertNotDestroyed();const e=await this.render(),r=this.getAssertedRecaptcha(),n=r.getResponse(e);return n||new Promise(s=>{const i=a=>{a&&(this.tokenChangeListeners.delete(i),s(a))};this.tokenChangeListeners.add(i),this.isInvisible&&r.execute(e)})}render(){try{this.assertNotDestroyed()}catch(e){return Promise.reject(e)}return this.renderPromise?this.renderPromise:(this.renderPromise=this.makeRenderPromise().catch(e=>{throw this.renderPromise=null,e}),this.renderPromise)}_reset(){this.assertNotDestroyed(),this.widgetId!==null&&this.getAssertedRecaptcha().reset(this.widgetId)}clear(){this.assertNotDestroyed(),this.destroyed=!0,this._recaptchaLoader.clearedOneInstance(),this.isInvisible||this.container.childNodes.forEach(e=>{this.container.removeChild(e)})}validateStartingState(){p(!this.parameters.sitekey,this.auth,"argument-error"),p(this.isInvisible||!this.container.hasChildNodes(),this.auth,"argument-error"),p(typeof document<"u",this.auth,"operation-not-supported-in-this-environment")}makeTokenCallback(e){return r=>{if(this.tokenChangeListeners.forEach(n=>n(r)),typeof e=="function")e(r);else if(typeof e=="string"){const n=x()[e];typeof n=="function"&&n(r)}}}assertNotDestroyed(){p(!this.destroyed,this.auth,"internal-error")}async makeRenderPromise(){if(await this.init(),!this.widgetId){let e=this.container;if(!this.isInvisible){const r=document.createElement("div");e.appendChild(r),e=r}this.widgetId=this.getAssertedRecaptcha().render(e,this.parameters)}return this.widgetId}async init(){p(Gn()&&!Nr(),this.auth,"internal-error"),await wc(),this.recaptcha=await this._recaptchaLoader.load(this.auth,this.auth.languageCode||void 0);const e=await ao(this.auth);p(e,this.auth,"internal-error"),this.parameters.sitekey=e}getAssertedRecaptcha(){return p(this.recaptcha,this.auth,"internal-error"),this.recaptcha}}function wc(){let t=null;return new Promise(e=>{if(document.readyState==="complete"){e();return}t=()=>e(),window.addEventListener("load",t)}).catch(e=>{throw t&&window.removeEventListener("load",t),e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _c{constructor(e,r){this.verificationId=e,this.onConfirmation=r}confirm(e){const r=st._fromVerification(this.verificationId,e);return this.onConfirmation(r)}}async function tr(t,e,r){if(q(t.app))return Promise.reject(pe(t));const n=ge(t),s=await bc(n,e,xe(r));return new _c(s,i=>qo(n,i))}async function bc(t,e,r){if(!t._getRecaptchaConfig())try{await Do(t)}catch{}try{let n;if(typeof e=="string"?n={phoneNumber:e}:n=e,"session"in n){const s=n.session;if("phoneNumber"in n){p(s.type==="enroll",t,"internal-error");const i={idToken:s.credential,phoneEnrollmentInfo:{phoneNumber:n.phoneNumber,clientType:"CLIENT_TYPE_WEB"}};return(await Zt(t,i,"mfaSmsEnrollment",async(d,f)=>{if(f.phoneEnrollmentInfo.captchaResponse===nt){p(r?.type===it,d,"argument-error");const u=await rr(d,f,r);return on(d,u)}return on(d,f)},"PHONE_PROVIDER").catch(d=>Promise.reject(d))).phoneSessionInfo.sessionInfo}else{p(s.type==="signin",t,"internal-error");const i=n.multiFactorHint?.uid||n.multiFactorUid;p(i,t,"missing-multi-factor-info");const a={mfaPendingCredential:s.credential,mfaEnrollmentId:i,phoneSignInInfo:{clientType:"CLIENT_TYPE_WEB"}};return(await Zt(t,a,"mfaSmsSignIn",async(f,u)=>{if(u.phoneSignInInfo.captchaResponse===nt){p(r?.type===it,f,"argument-error");const h=await rr(f,u,r);return dn(f,h)}return dn(f,u)},"PHONE_PROVIDER").catch(f=>Promise.reject(f))).phoneResponseInfo.sessionInfo}}else{const s={phoneNumber:n.phoneNumber,clientType:"CLIENT_TYPE_WEB"};return(await Zt(t,s,"sendVerificationCode",async(l,d)=>{if(d.captchaResponse===nt){p(r?.type===it,l,"argument-error");const f=await rr(l,d,r);return sn(l,f)}return sn(l,d)},"PHONE_PROVIDER").catch(l=>Promise.reject(l))).sessionInfo}}finally{r?._reset()}}async function rr(t,e,r){p(r.type===it,t,"argument-error");const n=await r.verify();p(typeof n=="string",t,"argument-error");const s={...e};if("phoneEnrollmentInfo"in s){const i=s.phoneEnrollmentInfo.phoneNumber,a=s.phoneEnrollmentInfo.captchaResponse,c=s.phoneEnrollmentInfo.clientType,l=s.phoneEnrollmentInfo.recaptchaVersion;return Object.assign(s,{phoneEnrollmentInfo:{phoneNumber:i,recaptchaToken:n,captchaResponse:a,clientType:c,recaptchaVersion:l}}),s}else if("phoneSignInInfo"in s){const i=s.phoneSignInInfo.captchaResponse,a=s.phoneSignInInfo.clientType,c=s.phoneSignInInfo.recaptchaVersion;return Object.assign(s,{phoneSignInInfo:{recaptchaToken:n,captchaResponse:i,clientType:a,recaptchaVersion:c}}),s}else return Object.assign(s,{recaptchaToken:n}),s}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function yc(t,e){return e?ee(e):(p(t._popupRedirectResolver,t,"argument-error"),t._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pr extends Cr{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return Be(e,this._buildIdpRequest())}_linkToIdToken(e,r){return Be(e,this._buildIdpRequest(r))}_getReauthenticationResolver(e){return Be(e,this._buildIdpRequest())}_buildIdpRequest(e){const r={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(r.idToken=e),r}}function vc(t){return ps(t.auth,new Pr(t),t.bypassAuthState)}function Ec(t){const{auth:e,user:r}=t;return p(r,e,"internal-error"),Ko(r,new Pr(t),t.bypassAuthState)}async function Ic(t){const{auth:e,user:r}=t;return p(r,e,"internal-error"),Go(r,new Pr(t),t.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Es{constructor(e,r,n,s,i=!1){this.auth=e,this.resolver=n,this.user=s,this.bypassAuthState=i,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(r)?r:[r]}execute(){return new Promise(async(e,r)=>{this.pendingPromise={resolve:e,reject:r};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(n){this.reject(n)}})}async onAuthEvent(e){const{urlResponse:r,sessionId:n,postBody:s,tenantId:i,error:a,type:c}=e;if(a){this.reject(a);return}const l={auth:this.auth,requestUri:r,sessionId:n,tenantId:i||void 0,postBody:s||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(c)(l))}catch(d){this.reject(d)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return vc;case"linkViaPopup":case"linkViaRedirect":return Ic;case"reauthViaPopup":case"reauthViaRedirect":return Ec;default:re(this.auth,"internal-error")}}resolve(e){ne(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){ne(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tc=new ht(2e3,1e4);class De extends Es{constructor(e,r,n,s,i){super(e,r,s,i),this.provider=n,this.authWindow=null,this.pollId=null,De.currentPopupAction&&De.currentPopupAction.cancel(),De.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return p(e,this.auth,"internal-error"),e}async onExecution(){ne(this.filter.length===1,"Popup operations only handle one event");const e=Ar();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(r=>{this.reject(r)}),this.resolver._isIframeWebStorageSupported(this.auth,r=>{r||this.reject(V(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){return this.authWindow?.associatedEvent||null}cancel(){this.reject(V(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,De.currentPopupAction=null}pollUserCancellation(){const e=()=>{if(this.authWindow?.window?.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(V(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,Tc.get())};e()}}De.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sc="pendingRedirect",kt=new Map;class Rc extends Es{constructor(e,r,n=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],r,void 0,n),this.eventId=null}async execute(){let e=kt.get(this.auth._key());if(!e){try{const n=await kc(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(n)}catch(r){e=()=>Promise.reject(r)}kt.set(this.auth._key(),e)}return this.bypassAuthState||kt.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const r=await this.auth._redirectUserForId(e.eventId);if(r)return this.user=r,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function kc(t,e){const r=Ac(e),n=Cc(t);if(!await n._isAvailable())return!1;const s=await n._get(r)==="true";return await n._remove(r),s}function xc(t,e){kt.set(t._key(),e)}function Cc(t){return ee(t._redirectPersistence)}function Ac(t){return Rt(Sc,t.config.apiKey,t.name)}async function Nc(t,e,r=!1){if(q(t.app))return Promise.reject(pe(t));const n=ge(t),s=yc(n,e),a=await new Rc(n,s,r).execute();return a&&!r&&(delete a.user._redirectEventId,await n._persistUserIfCurrent(a.user),await n._setRedirectUser(null,e)),a}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pc=10*60*1e3;class Oc{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let r=!1;return this.consumers.forEach(n=>{this.isEventForConsumer(e,n)&&(r=!0,this.sendToConsumer(e,n),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!Lc(e)||(this.hasHandledPotentialRedirect=!0,r||(this.queuedRedirectEvent=e,r=!0)),r}sendToConsumer(e,r){if(e.error&&!Is(e)){const n=e.error.code?.split("auth/")[1]||"internal-error";r.onError(V(this.auth,n))}else r.onAuthEvent(e)}isEventForConsumer(e,r){const n=r.eventId===null||!!e.eventId&&e.eventId===r.eventId;return r.filter.includes(e.type)&&n}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=Pc&&this.cachedEventUids.clear(),this.cachedEventUids.has(un(e))}saveEventToCache(e){this.cachedEventUids.add(un(e)),this.lastProcessedEventTime=Date.now()}}function un(t){return[t.type,t.eventId,t.sessionId,t.tenantId].filter(e=>e).join("-")}function Is({type:t,error:e}){return t==="unknown"&&e?.code==="auth/no-auth-event"}function Lc(t){switch(t.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return Is(t);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Dc(t,e={}){return G(t,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mc=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Uc=/^https?/;async function jc(t){if(t.config.emulator)return;const{authorizedDomains:e}=await Dc(t);for(const r of e)try{if(Vc(r))return}catch{}re(t,"unauthorized-domain")}function Vc(t){const e=gr(),{protocol:r,hostname:n}=new URL(e);if(t.startsWith("chrome-extension://")){const a=new URL(t);return a.hostname===""&&n===""?r==="chrome-extension:"&&t.replace("chrome-extension://","")===e.replace("chrome-extension://",""):r==="chrome-extension:"&&a.hostname===n}if(!Uc.test(r))return!1;if(Mc.test(t))return n===t;const s=t.replace(/\./g,"\\.");return new RegExp("^(.+\\."+s+"|"+s+")$","i").test(n)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fc=new ht(3e4,6e4);function hn(){const t=x().___jsl;if(t?.H){for(const e of Object.keys(t.H))if(t.H[e].r=t.H[e].r||[],t.H[e].L=t.H[e].L||[],t.H[e].r=[...t.H[e].L],t.CP)for(let r=0;r<t.CP.length;r++)t.CP[r]=null}}function Bc(t){return new Promise((e,r)=>{function n(){hn(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{hn(),r(V(t,"network-request-failed"))},timeout:Fc.get()})}if(x().gapi?.iframes?.Iframe)e(gapi.iframes.getContext());else if(x().gapi?.load)n();else{const s=ls("iframefcb");return x()[s]=()=>{gapi.load?n():r(V(t,"network-request-failed"))},xr(`${Ro()}?onload=${s}`).catch(i=>r(i))}}).catch(e=>{throw xt=null,e})}let xt=null;function Hc(t){return xt=xt||Bc(t),xt}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $c=new ht(5e3,15e3),zc="__/auth/iframe",Wc="emulator/auth/iframe",Gc={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},Kc=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function qc(t){const e=t.config;p(e.authDomain,t,"auth-domain-config-required");const r=e.emulator?Sr(e,Wc):`https://${t.config.authDomain}/${zc}`,n={apiKey:e.apiKey,appName:t.name,v:ut},s=Kc.get(t.config.apiHost);s&&(n.eid=s);const i=t._getFrameworks();return i.length&&(n.fw=i.join(",")),`${r}?${Ge(n).slice(1)}`}async function Jc(t){const e=await Hc(t),r=x().gapi;return p(r,t,"internal-error"),e.open({where:document.body,url:qc(t),messageHandlersFilter:r.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:Gc,dontclear:!0},n=>new Promise(async(s,i)=>{await n.restyle({setHideOnLeave:!1});const a=V(t,"network-request-failed"),c=x().setTimeout(()=>{i(a)},$c.get());function l(){x().clearTimeout(c),s(n)}n.ping(l).then(l,()=>{i(a)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xc={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},Yc=500,Zc=600,Qc="_blank",el="http://localhost";class fn{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function tl(t,e,r,n=Yc,s=Zc){const i=Math.max((window.screen.availHeight-s)/2,0).toString(),a=Math.max((window.screen.availWidth-n)/2,0).toString();let c="";const l={...Xc,width:n.toString(),height:s.toString(),top:i,left:a},d=D().toLowerCase();r&&(c=rs(d)?Qc:r),es(d)&&(e=e||el,l.scrollbars="yes");const f=Object.entries(l).reduce((h,[_,I])=>`${h}${_}=${I},`,"");if(go(d)&&c!=="_self")return rl(e||"",c),new fn(null);const u=window.open(e||"",c,f);p(u,t,"popup-blocked");try{u.focus()}catch{}return new fn(u)}function rl(t,e){const r=document.createElement("a");r.href=t,r.target=e;const n=document.createEvent("MouseEvent");n.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),r.dispatchEvent(n)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nl="__/auth/handler",sl="emulator/auth/handler",il=encodeURIComponent("fac");async function pn(t,e,r,n,s,i){p(t.config.authDomain,t,"auth-domain-config-required"),p(t.config.apiKey,t,"invalid-api-key");const a={apiKey:t.config.apiKey,appName:t.name,authType:r,redirectUrl:n,v:ut,eventId:s};if(e instanceof hs){e.setDefaultLanguage(t.languageCode),a.providerId=e.providerId||"",Mi(e.getCustomParameters())||(a.customParameters=JSON.stringify(e.getCustomParameters()));for(const[f,u]of Object.entries({}))a[f]=u}if(e instanceof pt){const f=e.getScopes().filter(u=>u!=="");f.length>0&&(a.scopes=f.join(","))}t.tenantId&&(a.tid=t.tenantId);const c=a;for(const f of Object.keys(c))c[f]===void 0&&delete c[f];const l=await t._getAppCheckToken(),d=l?`#${il}=${encodeURIComponent(l)}`:"";return`${al(t)}?${Ge(c).slice(1)}${d}`}function al({config:t}){return t.emulator?Sr(t,sl):`https://${t.authDomain}/${nl}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nr="webStorageSupport";class ol{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=_s,this._completeRedirectFn=Nc,this._overrideRedirectResult=xc}async _openPopup(e,r,n,s){ne(this.eventManagers[e._key()]?.manager,"_initialize() not called before _openPopup()");const i=await pn(e,r,n,gr(),s);return tl(e,i,Ar())}async _openRedirect(e,r,n,s){await this._originValidation(e);const i=await pn(e,r,n,gr(),s);return rc(i),new Promise(()=>{})}_initialize(e){const r=e._key();if(this.eventManagers[r]){const{manager:s,promise:i}=this.eventManagers[r];return s?Promise.resolve(s):(ne(i,"If manager is not set, promise should be"),i)}const n=this.initAndGetManager(e);return this.eventManagers[r]={promise:n},n.catch(()=>{delete this.eventManagers[r]}),n}async initAndGetManager(e){const r=await Jc(e),n=new Oc(e);return r.register("authEvent",s=>(p(s?.authEvent,e,"invalid-auth-event"),{status:n.onEvent(s.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:n},this.iframes[e._key()]=r,n}_isIframeWebStorageSupported(e,r){this.iframes[e._key()].send(nr,{type:nr},s=>{const i=s?.[0]?.[nr];i!==void 0&&r(!!i),re(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const r=e._key();return this.originValidationPromises[r]||(this.originValidationPromises[r]=jc(e)),this.originValidationPromises[r]}get _shouldInitProactively(){return os()||ts()||kr()}}const cl=ol;var mn="@firebase/auth",gn="1.12.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ll{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){return this.assertAuthConfigured(),this.auth.currentUser?.uid||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const r=this.auth.onIdTokenChanged(n=>{e(n?.stsTokenManager.accessToken||null)});this.internalListeners.set(e,r),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const r=this.internalListeners.get(e);r&&(this.internalListeners.delete(e),r(),this.updateProactiveRefresh())}assertAuthConfigured(){p(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dl(t){switch(t){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function ul(t){ot(new ze("auth",(e,{options:r})=>{const n=e.getProvider("app").getImmediate(),s=e.getProvider("heartbeat"),i=e.getProvider("app-check-internal"),{apiKey:a,authDomain:c}=n.options;p(a&&!a.includes(":"),"invalid-api-key",{appName:n.name});const l={apiKey:a,authDomain:c,clientPlatform:t,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:cs(t)},d=new Eo(n,s,i,l);return Uo(d,r),d},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,r,n)=>{e.getProvider("auth-internal").initialize()})),ot(new ze("auth-internal",e=>{const r=ge(e.getProvider("auth").getImmediate());return(n=>new ll(n))(r)},"PRIVATE").setInstantiationMode("EXPLICIT")),je(mn,gn,dl(t)),je(mn,gn,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hl=5*60,fl=Dn("authIdTokenMaxAge")||hl;let wn=null;const pl=t=>async e=>{const r=e&&await e.getIdTokenResult(),n=r&&(new Date().getTime()-Date.parse(r.issuedAtTime))/1e3;if(n&&n>fl)return;const s=r?.token;wn!==s&&(wn=s,await fetch(t,{method:s?"POST":"DELETE",headers:s?{Authorization:`Bearer ${s}`}:{}}))};function ml(t=ja()){const e=Vn(t,"auth");if(e.isInitialized())return e.getImmediate();const r=Mo(t,{popupRedirectResolver:cl,persistence:[uc,Qo,_s]}),n=Dn("authTokenSyncURL");if(n&&typeof isSecureContext=="boolean"&&isSecureContext){const i=new URL(n,location.origin);if(location.origin===i.origin){const a=pl(i.toString());Xo(r,a,()=>a(r.currentUser)),Jo(r,c=>a(c))}}const s=yi("auth");return s&&jo(r,`http://${s}`),r}function gl(){return document.getElementsByTagName("head")?.[0]??document}Io({loadJS(t){return new Promise((e,r)=>{const n=document.createElement("script");n.setAttribute("src",t),n.onload=e,n.onerror=s=>{const i=V("internal-error");i.customData=s,r(i)},n.type="text/javascript",n.charset="UTF-8",gl().appendChild(n)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});ul("Browser");const wl={apiKey:"AIzaSyA5ly1G-IcAs-We5Fl2_8YIoHgc_sPf7-A",authDomain:"villagelink-96b4c.firebaseapp.com",projectId:"villagelink-96b4c",storageBucket:"villagelink-96b4c.firebasestorage.app",messagingSenderId:"428748007277",appId:"1:428748007277:web:76f0eec16523044b575c64",measurementId:"G-TWQ8ELYRN1"},_l=Fn(wl),Z=ml(_l),bl=({onSuccess:t,lang:e="EN",toggleLang:r,toggleTheme:n,darkMode:s})=>{const i=g=>Dr[e][g]||Dr.EN[g],[a,c]=m.useState("LOGIN"),[l,d]=m.useState(!1),[f,u]=m.useState(null),[h,_]=m.useState(null),[I,b]=m.useState(!1),[v,C]=m.useState("Click mic to speak..."),[S,R]=m.useState(""),[Y,we]=m.useState(""),[_e,wt]=m.useState(""),[Ce,be]=m.useState(""),[U,P]=m.useState("PASSENGER"),[Ke,Ft]=m.useState(""),[Ae,_t]=m.useState(""),[N,Ne]=m.useState(""),[Pe,K]=m.useState("40"),[qe,Bt]=m.useState("BUS"),[ye,se]=m.useState(""),[Oe,ve]=m.useState(""),[Ee,Je]=m.useState(""),[M,bt]=m.useState(""),[Xe,yt]=m.useState(""),[ie,vt]=m.useState(""),[Le,Ht]=m.useState(null),Os=async()=>{if(!S||!/^\+?[0-9]{10,13}$/.test(S)&&!/^[0-9]{10}$/.test(S)){u("Please enter a valid 10-digit phone number for auto-OTP login.");return}d(!0),u(null);try{if(window.recaptchaVerifier)try{window.recaptchaVerifier.clear()}catch{}window.recaptchaVerifier=new er(Z,"recaptcha-login",{size:"invisible"});const g=S.startsWith("+")?S:`+91${S}`,w=await tr(Z,g,window.recaptchaVerifier);Ht(w),c("LOGIN_VERIFY"),_(`OTP sent to ${g}`)}catch(g){u("Failed to send OTP: "+g.message)}finally{d(!1)}},Ls=async g=>{if(g.preventDefault(),!(!Le||!_e)){d(!0),u(null);try{await Le.confirm(_e);const w=await Z.currentUser?.getIdToken();if(!w)throw new Error("No ID Token available");const y=await Hs(w);y.success&&y.user?t(y.user):u(y.message)}catch(w){u("Invalid OTP: "+w.message)}finally{d(!1)}}},Ds=async g=>{if(g.preventDefault(),!S||!Y){u("Please enter both ID and Password");return}d(!0),u(null);const w=await Lr(S,Y);d(!1),w.success&&w.user?t(w.user):u(w.message||"Login failed")},Ms=()=>{if(!("webkitSpeechRecognition"in window)&&!("SpeechRecognition"in window)){u("Voice Login not supported in this browser.");return}b(!0),C("Listening... Say 'Login as Passenger'");const g=window.SpeechRecognition||window.webkitSpeechRecognition,w=new g;w.lang="en-US",w.interimResults=!1,w.maxAlternatives=1,w.onresult=async y=>{const O=y.results[0][0].transcript.toLowerCase();if(C(`Heard: "${O}"`),O.includes("passenger")||O.includes("login")){C("Voice Verified. Logging in...");const Ye=await Lr("USR-999","pass");Ye.success&&Ye.user?t(Ye.user):(u("Voice match failed."),b(!1))}else u("Phrase not recognized. Try 'Login as Passenger'"),setTimeout(()=>b(!1),2e3)},w.onerror=y=>{u("Voice Error: "+y.error),b(!1)},w.onend=()=>{v.startsWith("Listening")&&b(!1)},w.start()},Us=async g=>{if(g.preventDefault(),!Ae&&!N){u("Please provide either Email or Phone number");return}if(d(!0),u(null),N)try{if(window.recaptchaVerifier)try{window.recaptchaVerifier.clear()}catch{}window.recaptchaVerifier=new er(Z,"recaptcha-reg",{size:"invisible"});const w=N.startsWith("+")?N:`+91${N}`,y=await tr(Z,w,window.recaptchaVerifier);Ht(y),c("REGISTER_VERIFY"),_(`OTP sent to ${w} for secure registration`)}catch(w){u("Failed to send Registration OTP: "+w.message)}finally{d(!1)}else{const w=U==="DRIVER"?parseInt(Pe):void 0,y=await Bs(Ce,U,Ke,Ae,N,w,qe,ye,Oe);d(!1),y.success&&y.user?(alert(`Account Created! User ID: ${y.user.id}`),c("LOGIN"),R(y.user.id)):u(y.message||"Registration failed")}},js=async g=>{if(g.preventDefault(),!(!Le||!Ee)){d(!0),u(null);try{await Le.confirm(Ee);const w=await Z.currentUser?.getIdToken();if(!w)throw new Error("No ID Token available");const y=U==="DRIVER"?parseInt(Pe):void 0,O=await $s(w,Ce,U,Ae,y,qe,ye,Oe);O.success&&O.user?(alert("Account verified and created successfully!"),c("LOGIN"),R(O.user?.id||N)):u(O.message||"Registration failed on server.")}catch(w){u("Registration verification failed: "+w.message)}finally{d(!1)}}},Vs=async g=>{if(g.preventDefault(),d(!0),u(null),/^\+?[0-9]{10,13}$/.test(M)||/^[0-9]{10}$/.test(M))try{if(window.recaptchaVerifier)try{window.recaptchaVerifier.clear()}catch{}window.recaptchaVerifier=new er(Z,"recaptcha-container",{size:"invisible",callback:()=>{}});const y=window.recaptchaVerifier,O=M.startsWith("+")?M:`+91${M}`,Ye=await tr(Z,O,y);Ht(Ye),_(`OTP sent to ${O} via Firebase`),c("RESET")}catch(y){if(window.recaptchaVerifier){try{window.recaptchaVerifier.clear()}catch{}window.recaptchaVerifier=null}u("Firebase SMS Failed: "+y.message)}finally{d(!1)}else{const y=await zs(M);if(d(!1),y.error)u(y.error);else{const O=y.otp?` (Simulated OTP: ${y.otp})`:"";_(y.message+O),c("RESET")}}},Fs=async g=>{if(g.preventDefault(),d(!0),u(null),Le)try{await Le.confirm(Xe);const w=await Z.currentUser?.getIdToken();if(!w)throw new Error("Failed to retrieve token");const y=await Ws(w,ie);y.success?(alert("Password Reset Successfully!"),c("LOGIN"),R(M),we(ie)):u(y.message||"Backend update failed")}catch(w){u("Invalid OTP or Verification Failed: "+w.message)}finally{d(!1)}else{const w=await Gs(M,Xe,ie);d(!1),w.error?u(w.error):(alert(w.message),c("LOGIN"),R(M),we(ie))}};return o.jsxs("div",{className:"w-full max-w-md mx-auto animate-fade-in relative",children:[o.jsx("div",{className:"animated-bg"}),o.jsx("div",{className:"relative z-20 flex justify-center -mb-20 pointer-events-none",children:o.jsxs("div",{className:"cyber-van-v3 animate-float-banana",children:[o.jsxs("div",{className:"van-body",children:[o.jsx("div",{className:"van-window"}),o.jsx("div",{className:"van-glow"})]}),o.jsx("div",{className:"van-shadow"})]})}),o.jsxs("div",{className:"glass-portal rounded-[32px] p-8 pt-16 shadow-2xl relative overflow-hidden bg-slate-900/80 backdrop-blur-xl border border-white/20",children:[o.jsx("div",{className:"absolute -top-20 -right-20 w-60 h-60 bg-luxe-gold rounded-full blur-[100px] opacity-20 animate-pulse-glow"}),o.jsx("div",{className:"absolute -bottom-20 -left-20 w-60 h-60 bg-luxe-rust rounded-full blur-[100px] opacity-20"}),o.jsxs("div",{className:"relative z-10 flex justify-between items-center mb-10 w-full px-2",children:[o.jsxs("div",{className:"flex items-center gap-2",children:[o.jsx("div",{className:"w-8 h-8 bg-gradient-to-br from-brand-600 to-brand-400 rounded-lg flex items-center justify-center text-white font-bold text-lg shadow-lg",children:"V"}),o.jsxs("span",{className:"font-bold text-xl tracking-tight text-white drop-shadow-md",children:["Village",o.jsx("span",{className:"text-luxe-gold",children:"Link"})]})]}),o.jsxs("div",{className:"flex items-center gap-2",children:[o.jsxs("button",{onClick:r,className:"px-3 py-2 rounded-full bg-white/10 backdrop-blur-md text-white shadow-sm border border-white/20 font-bold text-xs flex items-center gap-1 hover:bg-white/20 transition-all",children:[o.jsx(kn,{size:14}),e==="EN"?"अ":"A"]}),o.jsx("button",{onClick:n,className:"p-2 rounded-full bg-white/10 backdrop-blur-md text-white shadow-sm border border-white/20 hover:bg-white/20 transition-all",children:s?o.jsx(xn,{size:18}):o.jsx(Cn,{size:18})})]})]}),o.jsxs("div",{className:"relative z-10 text-center mb-6",children:[o.jsx("h2",{className:"text-3xl font-black text-white tracking-tight drop-shadow-md",children:a.includes("LOGIN")?"Sign In":a.includes("REGISTER")?i("register"):"Reset Password"}),o.jsx("p",{className:"text-luxe-gold mt-2 text-sm font-bold tracking-wide",children:"VillageLink V6 Luxe"})]}),f&&o.jsx("div",{className:"mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-100 rounded-xl text-red-600 dark:text-red-300 text-sm font-medium text-center",children:f}),h&&o.jsx("div",{className:"mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 rounded-xl text-blue-600 dark:text-blue-300 text-sm font-medium text-center",children:h}),a==="LOGIN"&&o.jsxs("div",{className:"space-y-6",children:[I?o.jsxs("div",{className:"py-8 flex flex-col items-center justify-center animate-fade-in glass-panel rounded-2xl border-none bg-white/5",children:[o.jsxs("div",{className:"w-24 h-24 bg-luxe-sienna/20 rounded-full flex items-center justify-center mb-6 relative",children:[o.jsx("div",{className:"absolute inset-0 bg-luxe-sienna rounded-full animate-ping opacity-30"}),o.jsx(Zs,{size:40,className:"text-luxe-gold"})]}),o.jsx("p",{className:"text-lg font-bold text-white tracking-wide",children:v}),o.jsx("button",{onClick:()=>b(!1),className:"mt-6 px-4 py-2 rounded-full bg-red-500/20 text-red-400 text-xs font-bold hover:bg-red-500/30 transition-all",children:"ABORT VOICE LOGON"})]}):o.jsxs("form",{onSubmit:Ds,className:"space-y-5",autoComplete:"on",children:[o.jsxs("div",{className:"space-y-2",children:[o.jsxs("label",{className:"text-[10px] font-black text-white uppercase ml-1 tracking-widest drop-shadow-md",children:[i("phone")," / ID"]}),o.jsxs("div",{className:"relative group",children:[o.jsx("div",{className:"absolute inset-0 bg-brand-600/30 blur-lg rounded-xl opacity-0 group-focus-within:opacity-100 transition-opacity"}),o.jsx(Qs,{className:"absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 z-10",size:18}),o.jsx("input",{type:"text",name:"username",value:S,onChange:g=>R(g.target.value),className:"w-full pl-12 pr-4 py-4 bg-white text-slate-900 border-2 border-slate-200 focus:border-brand-500 rounded-xl outline-none relative z-10 placeholder-slate-400 font-bold transition-all shadow-inner",placeholder:"Enter Mobile or ID",autoComplete:"username",required:!0})]})]}),o.jsxs("div",{className:"space-y-2",children:[o.jsxs("div",{className:"flex justify-between",children:[o.jsx("label",{className:"text-[10px] font-black text-white uppercase ml-1 tracking-widest drop-shadow-md",children:i("password")}),o.jsx("button",{type:"button",onClick:()=>c("FORGOT"),className:"text-[10px] font-black text-luxe-gold hover:text-white transition-colors uppercase drop-shadow-md",children:"Recover Key?"})]}),o.jsxs("div",{className:"relative group",children:[o.jsx("div",{className:"absolute inset-0 bg-brand-600/30 blur-lg rounded-xl opacity-0 group-focus-within:opacity-100 transition-opacity"}),o.jsx($t,{className:"absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 z-10",size:18}),o.jsx("input",{type:"password",name:"password",value:Y,onChange:g=>we(g.target.value),className:"w-full pl-12 pr-4 py-4 bg-white text-slate-900 border-2 border-slate-200 focus:border-brand-500 rounded-xl outline-none relative z-10 placeholder-slate-400 font-bold transition-all shadow-inner",placeholder:"••••••••",autoComplete:"current-password",required:!0})]})]}),o.jsxs("div",{className:"flex gap-2 w-full",children:[o.jsx("button",{type:"submit",disabled:l,className:"flex-1 py-4 bg-luxe-sienna hover:bg-luxe-rust text-white font-black rounded-xl shadow-[0_0_20px_rgba(190,81,3,0.4)] hover:shadow-[0_0_30px_rgba(183,65,14,0.6)] transition-all transform hover:-translate-y-1 active:scale-[0.98] flex items-center justify-center gap-2 uppercase tracking-wide text-sm",children:l?o.jsx(It,{className:"animate-spin"}):o.jsxs(o.Fragment,{children:[i("login")," ",o.jsx($t,{size:16})]})}),o.jsx("button",{type:"button",onClick:Os,disabled:l,className:"flex-1 py-4 bg-brand-600 hover:bg-brand-700 text-white font-black rounded-xl shadow-lg transition-all transform hover:-translate-y-1 active:scale-[0.98] flex items-center justify-center gap-2 uppercase tracking-wide text-sm",children:l?o.jsx(It,{className:"animate-spin"}):o.jsxs(o.Fragment,{children:["OTP ",o.jsx(ei,{size:16})]})})]}),o.jsx("div",{id:"recaptcha-login"}),o.jsxs("div",{className:"relative flex py-2 items-center opacity-50",children:[o.jsx("div",{className:"flex-grow border-t border-white/10"}),o.jsx("span",{className:"flex-shrink-0 mx-4 text-[10px] text-white/40 font-bold uppercase tracking-[0.2em]",children:"Biometric Link"}),o.jsx("div",{className:"flex-grow border-t border-white/10"})]}),o.jsxs("button",{type:"button",onClick:Ms,className:"w-full py-3 rounded-xl border border-white/20 bg-white/10 flex items-center justify-center gap-2 hover:bg-white/20 transition-colors group shadow-sm",children:[o.jsx(ti,{size:18,className:"text-luxe-teal group-hover:animate-bounce"}),o.jsx("span",{className:"text-sm font-bold text-white group-hover:text-luxe-gold transition-colors block drop-shadow-md",children:"Initialize Voice Protocol"})]})]}),o.jsx("div",{className:"text-center pt-2",children:o.jsxs("button",{onClick:()=>c("REGISTER"),className:"text-sm font-bold text-white hover:text-luxe-gold transition-colors flex items-center justify-center gap-1 mx-auto drop-shadow-md",children:["New User? ",o.jsx("span",{className:"font-black text-luxe-teal underline decoration-luxe-teal/80 underline-offset-4",children:"Create Identity"})]})})]}),a==="REGISTER"&&o.jsxs("form",{onSubmit:Us,className:"space-y-4",autoComplete:"off",children:[o.jsxs("div",{className:"grid grid-cols-4 gap-2 mb-4",children:[o.jsxs("button",{type:"button",onClick:()=>P("SHOPKEEPER"),className:`p-2 rounded-xl border flex flex-col items-center gap-1 ${U==="SHOPKEEPER"?"bg-brand-50 border-brand-500 text-brand-700":"border-slate-200 text-slate-500"}`,children:[o.jsx(ri,{size:18}),o.jsx("span",{className:"text-[9px] font-bold",children:i("shopkeeper")})]}),o.jsxs("button",{type:"button",onClick:()=>P("MESS_MANAGER"),className:`p-2 rounded-xl border flex flex-col items-center gap-1 ${U==="MESS_MANAGER"?"bg-brand-50 border-brand-500 text-brand-700":"border-slate-200 text-slate-500"}`,children:[o.jsx(ni,{size:18}),o.jsx("span",{className:"text-[9px] font-bold",children:"Mess"})]})]}),o.jsx("input",{type:"text",name:"name",value:Ce,onChange:g=>be(g.target.value),className:"w-full px-4 py-3 bg-white/50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl outline-none dark:text-white",placeholder:U==="MESS_MANAGER"?"Mess Name":"Full Name",required:!0}),o.jsxs("div",{className:"space-y-2",children:[o.jsx("label",{className:"text-xs font-bold text-white drop-shadow-md uppercase",children:"Contact Info (At least one)"}),o.jsxs("div",{className:"relative",children:[o.jsx(si,{className:"absolute left-4 top-1/2 -translate-y-1/2 text-slate-300",size:18}),o.jsx("input",{type:"email",name:"email",value:Ae,onChange:g=>_t(g.target.value),className:"w-full pl-12 pr-4 py-3 bg-white/10 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-600 rounded-xl outline-none text-slate-900 dark:text-white placeholder-slate-500 font-medium font-medium",placeholder:"Email Address"})]}),o.jsxs("div",{className:"relative",children:[o.jsx(ii,{className:"absolute left-4 top-1/2 -translate-y-1/2 text-slate-300",size:18}),o.jsx("input",{type:"tel",name:"phone",value:N,onChange:g=>Ne(g.target.value),className:"w-full pl-12 pr-4 py-3 bg-white/10 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-600 rounded-xl outline-none text-slate-900 dark:text-white placeholder-slate-500 font-medium font-medium",placeholder:"Mobile Number"})]})]}),U==="MESS_MANAGER"&&o.jsxs("div",{className:"space-y-3 p-4 bg-slate-50/90 dark:bg-slate-800/90 rounded-xl border border-slate-200 dark:border-slate-600 animate-fade-in shadow-md",children:[o.jsx("p",{className:"text-xs font-bold text-slate-700 dark:text-slate-200 uppercase drop-shadow-sm",children:"Mess Location"}),o.jsx("input",{type:"text",value:ye,onChange:g=>se(g.target.value),className:"w-full px-4 py-3 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl outline-none text-slate-900 dark:text-white placeholder-slate-500 font-medium",placeholder:"Full Address / Shop No.",required:!0}),o.jsx("input",{type:"text",value:Oe,onChange:g=>ve(g.target.value),className:"w-full px-4 py-3 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl outline-none text-slate-900 dark:text-white placeholder-slate-500 font-medium",placeholder:"Pin Code",maxLength:6,required:!0})]}),U==="DRIVER"&&o.jsxs("div",{className:"space-y-3 p-4 bg-slate-50/90 dark:bg-slate-800/90 rounded-xl border border-slate-200 dark:border-slate-600 shadow-md",children:[o.jsx("p",{className:"text-xs font-bold text-slate-700 dark:text-slate-200 uppercase drop-shadow-sm",children:"Vehicle Details"}),o.jsxs("div",{className:"relative",children:[o.jsx(ai,{className:"absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 dark:text-slate-300",size:18}),o.jsx("input",{type:"number",value:Pe,onChange:g=>K(g.target.value),className:"w-full pl-12 pr-4 py-3 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl outline-none text-slate-900 dark:text-white placeholder-slate-500 font-medium",placeholder:"Seats Capacity",required:!0})]}),o.jsx("div",{className:"grid grid-cols-4 gap-2",children:["BUS","TAXI","AUTO","BIKE"].map(g=>o.jsxs("div",{onClick:()=>Bt(g),className:`cursor-pointer p-2 rounded-lg border flex flex-col items-center justify-center gap-1 ${qe===g?"bg-luxe-sienna text-white border-luxe-sienna":"bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-400"}`,children:[g==="BUS"&&o.jsx(oi,{size:16}),g==="TAXI"&&o.jsx(ci,{size:16}),g==="AUTO"&&o.jsx(li,{size:16}),g==="BIKE"&&o.jsx(di,{size:16}),o.jsx("span",{className:"text-[9px] font-bold",children:g})]},g))})]}),o.jsx("input",{type:"password",name:"new-password",value:Ke,onChange:g=>Ft(g.target.value),className:"w-full px-4 py-3 bg-white/10 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-600 rounded-xl outline-none text-slate-900 dark:text-white placeholder-slate-500 font-medium",placeholder:"Password",autoComplete:"new-password",required:!0}),o.jsx("div",{id:"recaptcha-reg"}),o.jsx(Ze,{type:"submit",fullWidth:!0,disabled:l,children:l?o.jsx(It,{className:"animate-spin"}):i("register")}),o.jsx("button",{type:"button",onClick:()=>c("LOGIN"),className:"w-full text-center text-sm font-bold text-white drop-shadow-md hover:text-luxe-gold transition-colors mt-3",children:"Back to Login"})]}),a==="LOGIN_VERIFY"&&o.jsxs("form",{onSubmit:Ls,className:"space-y-4",children:[o.jsxs("div",{className:"bg-brand-50 dark:bg-brand-900/30 p-3 rounded-lg text-center text-xs text-brand-700 dark:text-brand-300",children:["Enter the OTP sent to ",o.jsx("b",{children:S})," for Secure Login"]}),o.jsxs("div",{className:"relative",children:[o.jsx(zt,{className:"absolute left-4 top-1/2 -translate-y-1/2 text-slate-400",size:18}),o.jsx("input",{type:"text",value:_e,onChange:g=>wt(g.target.value),className:"w-full pl-12 pr-4 py-3 bg-white/50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl outline-none dark:text-white text-center tracking-[0.5em] font-bold text-xl",placeholder:"XXXXXX",maxLength:6,required:!0})]}),o.jsx(Ze,{type:"submit",fullWidth:!0,disabled:l,children:"Verify & Login"}),o.jsx("button",{type:"button",onClick:()=>c("LOGIN"),className:"w-full text-center text-sm font-bold text-slate-400 mt-2",children:"Cancel"})]}),a==="REGISTER_VERIFY"&&o.jsxs("form",{onSubmit:js,className:"space-y-4",children:[o.jsxs("div",{className:"bg-brand-50 dark:bg-brand-900/30 p-3 rounded-lg text-center text-xs text-brand-700 dark:text-brand-300",children:["Enter the OTP sent to ",o.jsx("b",{children:N})," to Complete Registration"]}),o.jsxs("div",{className:"relative",children:[o.jsx(zt,{className:"absolute left-4 top-1/2 -translate-y-1/2 text-slate-400",size:18}),o.jsx("input",{type:"text",value:Ee,onChange:g=>Je(g.target.value),className:"w-full pl-12 pr-4 py-3 bg-white/50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl outline-none dark:text-white text-center tracking-[0.5em] font-bold text-xl",placeholder:"XXXXXX",maxLength:6,required:!0})]}),o.jsx(Ze,{type:"submit",fullWidth:!0,disabled:l,children:"Verify & Register"}),o.jsx("button",{type:"button",onClick:()=>c("LOGIN"),className:"w-full text-center text-sm font-bold text-slate-400 mt-2",children:"Cancel"})]}),a==="FORGOT"&&o.jsxs("form",{onSubmit:Vs,className:"space-y-4",children:[o.jsx("p",{className:"text-sm font-medium text-white drop-shadow-md mb-2",children:"Enter your registered Email or Mobile Number to receive a reset OTP."}),o.jsx("input",{type:"text",value:M,onChange:g=>bt(g.target.value),className:"w-full px-4 py-3 bg-white/10 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-600 rounded-xl outline-none text-slate-900 dark:text-white placeholder-slate-500 font-medium",placeholder:"Email or Phone",required:!0}),o.jsx("div",{id:"recaptcha-container"}),o.jsx(Ze,{type:"submit",fullWidth:!0,disabled:l,children:l?o.jsx(It,{className:"animate-spin"}):"Send OTP"}),o.jsx("button",{type:"button",onClick:()=>c("LOGIN"),className:"w-full text-center text-sm font-bold text-white drop-shadow-md hover:text-luxe-gold mt-3",children:"Cancel"})]}),a==="RESET"&&o.jsxs("form",{onSubmit:Fs,className:"space-y-4",children:[o.jsxs("div",{className:"bg-brand-50/90 dark:bg-brand-900/80 p-3 rounded-xl text-center text-xs text-brand-700 dark:text-brand-300 shadow-sm border border-brand-200 dark:border-brand-700 font-medium",children:["Enter the OTP sent to ",o.jsx("b",{className:"text-brand-800 dark:text-brand-200",children:M})]}),o.jsxs("div",{className:"relative",children:[o.jsx(zt,{className:"absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 dark:text-slate-400",size:18}),o.jsx("input",{type:"text",value:Xe,onChange:g=>yt(g.target.value),className:"w-full pl-12 pr-4 py-3 bg-white/90 dark:bg-slate-800/90 border border-slate-300 dark:border-slate-600 rounded-xl outline-none text-slate-900 dark:text-white placeholder-slate-500 font-medium text-center tracking-[0.5em] font-bold text-xl shadow-inner",placeholder:"XXXXXX",maxLength:6,required:!0})]}),o.jsxs("div",{className:"relative",children:[o.jsx($t,{className:"absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 dark:text-slate-400",size:18}),o.jsx("input",{type:"password",value:ie,onChange:g=>vt(g.target.value),className:"w-full pl-12 pr-4 py-3 bg-white/90 dark:bg-slate-800/90 border border-slate-300 dark:border-slate-600 rounded-xl outline-none text-slate-900 dark:text-white placeholder-slate-500 font-medium shadow-inner",placeholder:"New Password",required:!0})]}),o.jsx(Ze,{type:"submit",fullWidth:!0,disabled:l,className:"shadow-lg hover:shadow-xl transition-shadow font-bold",children:"Verify & Reset Password"})]})]})]})},ke={BATCH_SIZE:10,FLUSH_INTERVAL:3e4,MAX_QUEUE_SIZE:100,LATENCY_THRESHOLD:3e3,RAGE_CLICK_THRESHOLD:3,RAGE_CLICK_INTERVAL:500};let H=[],yl=vl(),_n=0,Qe=0,bn=null,yn=!1;function vl(){return`sess_${Date.now()}_${Math.random().toString(36).substr(2,9)}`}function El(){return`err_${Date.now()}_${Math.random().toString(36).substr(2,9)}`}function Il(){const t=navigator,e=t.connection||t.mozConnection||t.webkitConnection;return{browser:Tl(),browserVersion:Sl(),os:Rl(),osVersion:kl(),screenWidth:window.screen.width,screenHeight:window.screen.height,connectionType:e?.type,effectiveType:e?.effectiveType,language:navigator.language,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone}}function Tl(){const t=navigator.userAgent;return t.includes("Chrome")?"Chrome":t.includes("Firefox")?"Firefox":t.includes("Safari")?"Safari":t.includes("Edge")?"Edge":t.includes("Opera")?"Opera":"Unknown"}function Sl(){const e=navigator.userAgent.match(/(chrome|firefox|safari|edge|opera|opr)\/?\s*(\d+)/i);return e?e[2]:"Unknown"}function Rl(){const t=navigator.userAgent;return t.includes("Windows")?"Windows":t.includes("Mac")?"macOS":t.includes("Linux")?"Linux":t.includes("Android")?"Android":t.includes("iOS")||t.includes("iPhone")||t.includes("iPad")?"iOS":"Unknown"}function kl(){const e=navigator.userAgent.match(/(?:windows nt|mac os x|android|ios)\s*([\d._]+)/i);return e?e[1].replace(/_/g,"."):"Unknown"}function xl(t){return t.type==="SERVICE_FAILURE"?"CRITICAL":t.type==="SERVER_ERROR"||t.networkInfo?.statusCode&&t.networkInfo.statusCode>=500||t.performanceMetrics?.latency&&t.performanceMetrics.latency>1e4?"HIGH":(t.uxMetrics?.rageClicks&&t.uxMetrics.rageClicks>=5,"MEDIUM")}function Se(t){const e=vr(),r={errorId:El(),type:t.type||"CLIENT_ERROR",severity:t.severity||xl(t),message:t.message||"Unknown error",stack:t.stack,code:t.code,url:window.location.href,component:t.component,action:t.action,userId:e?.id,sessionId:yl,deviceInfo:Il(),performanceMetrics:t.performanceMetrics,networkInfo:t.networkInfo,uxMetrics:t.uxMetrics,context:t.context,timestamp:Date.now()};H.push(r),(r.severity==="CRITICAL"||H.length>=ke.BATCH_SIZE)&&He(),H.length>ke.MAX_QUEUE_SIZE&&(H=H.slice(-100))}async function He(){if(H.length===0)return;const t=[...H];H=[];try{const e=Sn();await fetch(`${dr}/api/errors/report`,{method:"POST",headers:{"Content-Type":"application/json",...e?{Authorization:`Bearer ${e}`}:{}},body:JSON.stringify({errors:t})})}catch{H=[...t,...H].slice(0,ke.MAX_QUEUE_SIZE);try{const r=JSON.parse(localStorage.getItem("errorQueue")||"[]");localStorage.setItem("errorQueue",JSON.stringify([...r,...t].slice(-50)))}catch{}}}function Cl(){window.onerror=(t,e,r,n,s)=>(Se({type:"CLIENT_ERROR",message:String(t),stack:s?.stack,context:{source:e,lineno:r,colno:n}}),!1),window.addEventListener("unhandledrejection",t=>{Se({type:"CLIENT_ERROR",message:t.reason?.message||String(t.reason),stack:t.reason?.stack,context:{type:"unhandledrejection"}})}),window.addEventListener("error",t=>{if(t.target&&t.target.tagName){const e=t.target;["IMG","SCRIPT","LINK"].includes(e.tagName)&&Se({type:"NETWORK_ERROR",severity:"LOW",message:`Failed to load ${e.tagName.toLowerCase()}: ${e.src||e.href}`,context:{tagName:e.tagName}})}},!0)}function Al(){if(window.addEventListener("load",()=>{setTimeout(()=>{const t=performance.timing,e=t.loadEventEnd-t.navigationStart;e>ke.LATENCY_THRESHOLD&&Se({type:"PERFORMANCE",severity:"LOW",message:`Slow page load: ${e}ms`,performanceMetrics:{loadTime:e}})},0)}),"PerformanceObserver"in window)try{new PerformanceObserver(e=>{for(const r of e.getEntries())r.duration>100&&Se({type:"PERFORMANCE",severity:"LOW",message:`Long task detected: ${Math.round(r.duration)}ms`,performanceMetrics:{latency:r.duration}})}).observe({entryTypes:["longtask"]})}catch{}}function Nl(){document.addEventListener("click",t=>{const e=Date.now();t.target===bn&&e-_n<ke.RAGE_CLICK_INTERVAL?(Qe++,Qe>=ke.RAGE_CLICK_THRESHOLD&&(Se({type:"UX_ISSUE",severity:"MEDIUM",message:"Rage clicks detected",uxMetrics:{rageClicks:Qe},context:{target:t.target?.tagName,className:t.target?.className}}),Qe=0)):Qe=1,_n=e,bn=t.target}),document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"&&(document.querySelectorAll("form").forEach(e=>{const r=e.querySelectorAll("input, textarea, select");let n=!1;r.forEach(s=>{s.value&&(n=!0)}),n&&Se({type:"UX_ISSUE",severity:"LOW",message:"Potential form abandonment",uxMetrics:{formAbandonment:!0}})}),He())})}function Ts(){if(!(yn||typeof window>"u")){Cl(),Al(),Nl(),setInterval(He,ke.FLUSH_INTERVAL),window.addEventListener("beforeunload",()=>{He()});try{const t=JSON.parse(localStorage.getItem("errorQueue")||"[]");t.length>0&&(H=[...H,...t],localStorage.removeItem("errorQueue"),He())}catch{}yn=!0}}typeof window<"u"&&setTimeout(Ts,1e3);m.lazy(()=>k(()=>import("../views/PassengerView-C5y6awzv.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])).then(t=>({default:t.PassengerView})));const Pl=m.lazy(()=>k(()=>import("../views/DriverView-B4DpsSpR.js"),__vite__mapDeps([16,1,2,3,4,8,9,17,7,6,11,10])).then(t=>({default:t.DriverView}))),Ol=m.lazy(()=>k(()=>import("../views/AdminView-BUzbuDKI.js"),__vite__mapDeps([18,1,2,3,4,17,8,9])).then(t=>({default:t.AdminView}))),Ll=m.lazy(()=>k(()=>import("../views/ShopkeeperView-CjinT01B.js"),__vite__mapDeps([19,1,2,3,4,13,10,9]))),Dl=m.lazy(()=>k(()=>import("../views/MessManagerView-C3Oj5qR_.js"),__vite__mapDeps([20,1,2,3,4,9])));m.lazy(()=>k(()=>import("../views/VendorView-DuESuoFU.js"),__vite__mapDeps([21,1,2,3,4,9])));const Ml=m.lazy(()=>k(()=>import("../views/VyaparSaathiView-D7MFrKB4.js"),__vite__mapDeps([22,1,2,3,4,9])).then(t=>({default:t.VyaparSaathiView}))),Ul=m.lazy(()=>k(()=>import("../views/LuxeOSView-BtEZK-gB.js"),__vite__mapDeps([23,1,2,3,4,9])).then(t=>({default:t.LuxeOSView}))),vn=m.lazy(()=>k(()=>import("../views/VillageManagerView-BRuH_m4v.js"),__vite__mapDeps([24,1,2,3,4,9]))),En=m.lazy(()=>k(()=>import("../views/KisanApp-CuIkvKOe.js"),__vite__mapDeps([25,1,2,3,4,6,9]))),jl=m.lazy(()=>k(()=>import("../views/UserProfile-DiQsBBn2.js"),__vite__mapDeps([12,1,2,3,4,7,6,9])).then(t=>({default:t.UserProfile}))),Vl=m.lazy(()=>k(()=>import("../views/DriverApp-DHAnxidA.js"),__vite__mapDeps([26,1,2,3,4,16,8,9,17,7,6,11,10])).then(t=>({default:t.DriverApp}))),Fl=m.lazy(()=>k(()=>import("../views/VyapariApp-CZknXxE2.js"),__vite__mapDeps([27,1,2,3,4,9])).then(t=>({default:t.VyapariApp}))),Bl=m.lazy(()=>k(()=>import("../views/MessApp-Dg9iHf2o.js"),__vite__mapDeps([28,1,2,3,4,9])).then(t=>({default:t.MessApp}))),Hl=m.lazy(()=>k(()=>import("../views/StorageApp-DZY6hRlx.js"),__vite__mapDeps([29,1,2,3,4,9])).then(t=>({default:t.StorageApp}))),$l=m.lazy(()=>k(()=>import("../views/LogisticsApp-Z8h-lm7r.js"),__vite__mapDeps([30,1,2,3,4,9])).then(t=>({default:t.LogisticsApp})));m.lazy(()=>k(()=>import("../views/UserPanel-Cjo2rth4.js"),__vite__mapDeps([31,1,2,3,4,9])).then(t=>({default:t.UserPanel})));const zl=m.lazy(()=>k(()=>import("../views/CargoShipmentView-DzfFpbTW.js"),__vite__mapDeps([32,1,2,3,4,9]))),sr=m.lazy(()=>k(()=>import("../views/UserApp-CDxcL-ad.js"),__vite__mapDeps([33,1,2,3,4,9,14,7,30,0,5,6,8,10,11,12,13,15,34,35]))),Wl=m.lazy(()=>k(()=>import("../views/ProviderApp-R70YWdCg.js"),__vite__mapDeps([36,1,2,3,4,9,35,16,8,17,7,6,11,10,25,21,20,19,13]))),Gl=()=>{const t=window.location.pathname.toLowerCase();return t.startsWith("/app")||t.startsWith("/consumer")?"USS_USER":t.startsWith("/provider")||t.startsWith("/partner")?"USS_PROVIDER":t.startsWith("/kisan")?"KISAN":t.startsWith("/driver")?"DRIVER":t.startsWith("/vyapari")?"VYAPARI":t.startsWith("/mess")?"MESS":t.startsWith("/storage")?"STORAGE":t.startsWith("/logistics")?"LOGISTICS":t.startsWith("/cargo")?"CARGO":t.startsWith("/villagemanager")?"VILLAGE_MANAGER":"USER"},Kl=()=>{const[t,e]=m.useState(null),[r,n]=m.useState(!1),[s,i]=m.useState("HOME"),[a,c]=m.useState("EN"),[l,d]=m.useState(!1);m.useEffect(()=>{const v=vr(),C=Sn();v&&C&&e(v),d(!0),Ts(),typeof requestIdleCallback<"u"?requestIdleCallback(()=>{Mr(),Ur().then(R=>{R.length>0}),v&&C&&Et()},{timeout:2e3}):setTimeout(()=>{Mr(),Ur().then(R=>{R.length>0}),v&&C&&Et()},100);const S=()=>{alert("Session Expired: You have logged in on another device."),h()};return window.addEventListener("auth_error",S),window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches&&n(!0),()=>window.removeEventListener("auth_error",S)},[]),m.useEffect(()=>{r?document.documentElement.classList.add("dark"):document.documentElement.classList.remove("dark")},[r]);const f=()=>n(!r),u=()=>c(v=>v==="EN"?"HI":"EN"),h=()=>{qs(),e(null),i("HOME")},_=v=>{e(v),typeof requestIdleCallback<"u"?requestIdleCallback(()=>Et(),{timeout:1e3}):setTimeout(()=>Et(),100)},I=()=>{if(!t)return null;switch(t.role){case"ADMIN":return o.jsx(Ol,{user:t});case"PASSENGER":return o.jsx(sr,{user:t,onLogout:h,lang:a,darkMode:r,toggleTheme:f});case"DRIVER":return o.jsx(Pl,{user:t,lang:a});case"SHOPKEEPER":return o.jsx(Ll,{user:t});case"MESS_MANAGER":return o.jsx(Dl,{user:t});case"FOOD_VENDOR":return o.jsx(Ml,{user:t});case"RESTAURANT_MANAGER":return o.jsx(Ul,{user:t});case"FARMER":return o.jsx(En,{});case"VILLAGE_MANAGER":return o.jsx(vn,{user:t});default:return o.jsx(sr,{user:t,onLogout:h,lang:a,darkMode:r,toggleTheme:f})}},b=Gl();if(b==="KISAN")return o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx(En,{})});if(b==="DRIVER")return o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx(Vl,{})});if(b==="VYAPARI")return o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx(Fl,{})});if(b==="MESS")return o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx(Bl,{})});if(b==="STORAGE")return o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx(Hl,{})});if(b==="LOGISTICS")return o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx($l,{})});if(b==="VILLAGE_MANAGER")return o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx(vn,{user:t||{id:"guest",name:"Guest",role:"VILLAGE_MANAGER"}})});if(b==="CARGO"){const v={id:"guest",name:"Guest User",phone:""};return o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx(zl,{user:t||v})})}return b==="USS_USER"||t&&t.role==="PASSENGER"?o.jsx("div",{className:"min-h-screen bg-obsidian-deep",children:o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx(sr,{user:t,onLogout:h,lang:a})})}):b==="USS_PROVIDER"?o.jsx(m.Suspense,{fallback:o.jsx(F,{}),children:o.jsx(Wl,{user:t,onLogout:h})}):o.jsxs("div",{className:"min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-50 transition-colors duration-500 overflow-x-hidden",children:[o.jsx("div",{className:"veo-cinematic-bg"}),o.jsx("div",{className:"veo-drift-grain"}),o.jsxs("div",{className:"max-w-4xl mx-auto min-h-screen relative flex flex-col p-4 z-10",children:[t&&o.jsxs("header",{className:"sticky top-0 z-50 flex justify-between items-center py-4 mb-6 bg-slate-50/90 dark:bg-slate-950/90 backdrop-blur-md -mx-4 px-4 border-b border-slate-200/50 dark:border-slate-800/50",children:[o.jsxs("div",{className:"flex items-center gap-2 cursor-pointer",onClick:()=>i("HOME"),children:[o.jsx("div",{className:"w-8 h-8 bg-gradient-to-br from-brand-600 to-brand-400 rounded-lg flex items-center justify-center text-white font-bold text-lg shadow-lg",children:"V"}),o.jsxs("span",{className:"font-bold text-xl tracking-tight dark:text-white",children:["Village",o.jsx("span",{className:"text-brand-600 dark:text-brand-400",children:"Link"})]})]}),o.jsxs("div",{className:"flex items-center gap-2",children:[o.jsxs("button",{onClick:u,className:"px-3 py-2 rounded-full bg-white/50 dark:bg-slate-800/50 backdrop-blur-md text-slate-800 dark:text-white shadow-sm border border-slate-200 dark:border-slate-700 font-bold text-xs flex items-center gap-1",children:[o.jsx(kn,{size:14}),a==="EN"?"अ":"A"]}),o.jsx("button",{onClick:f,className:"p-2 rounded-full bg-white/50 dark:bg-slate-800/50 backdrop-blur-md text-slate-800 dark:text-white shadow-sm border border-slate-200 dark:border-slate-700",children:r?o.jsx(xn,{size:18}):o.jsx(Cn,{size:18})}),o.jsx("button",{onClick:h,"aria-label":"Logout",className:"p-2 rounded-full bg-white/50 dark:bg-slate-800/50 backdrop-blur-md text-red-500 dark:text-red-400 shadow-sm border border-slate-200 dark:border-slate-700",children:o.jsx(ui,{size:18})})]})]}),o.jsx("main",{className:"relative flex-grow",children:l?t?o.jsx(m.Suspense,{fallback:s==="PROFILE"?o.jsx(Ks,{}):o.jsx(F,{}),children:s==="PROFILE"?o.jsx(jl,{user:t,onBack:()=>i("HOME"),onLogout:h}):I()}):o.jsx("div",{className:"my-auto py-10",children:o.jsx(bl,{onSuccess:_,lang:a,toggleLang:u,toggleTheme:f,darkMode:r})}):o.jsx(F,{})})]})]})};var A;(function(t){t.Documents="DOCUMENTS",t.Data="DATA",t.Library="LIBRARY",t.Cache="CACHE",t.External="EXTERNAL",t.ExternalStorage="EXTERNAL_STORAGE",t.ExternalCache="EXTERNAL_CACHE",t.LibraryNoCloud="LIBRARY_NO_CLOUD",t.Temporary="TEMPORARY"})(A||(A={}));var In;(function(t){t.UTF8="utf8",t.ASCII="ascii",t.UTF16="utf16"})(In||(In={}));const L=Rn("Filesystem",{web:()=>k(()=>import("./web-btCmyIj0.js"),__vite__mapDeps([37,1,2,3,4,5,9,17])).then(t=>new t.FilesystemWeb)});Js();async function ql(){try{await L.readdir({path:"ota_tmp",directory:A.Data}).catch(()=>null)&&await L.rmdir({path:"ota_tmp",directory:A.Data,recursive:!0}),await L.readdir({path:"ota_staging",directory:A.Data}).catch(()=>null)&&await L.rmdir({path:"ota_staging",directory:A.Data,recursive:!0})}catch{}}const ir=Rn("Preferences",{web:()=>k(()=>import("./web-oUPHiLW5.js"),__vite__mapDeps([38,1,2,3,4])).then(t=>new t.PreferencesWeb)});var j=Uint8Array,Me=Uint16Array,Jl=Int32Array,Ss=new j([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),Rs=new j([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),Xl=new j([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),ks=function(t,e){for(var r=new Me(31),n=0;n<31;++n)r[n]=e+=1<<t[n-1];for(var s=new Jl(r[30]),n=1;n<30;++n)for(var i=r[n];i<r[n+1];++i)s[i]=i-r[n]<<5|n;return{b:r,r:s}},xs=ks(Ss,2),Cs=xs.b,Yl=xs.r;Cs[28]=258,Yl[258]=28;var Zl=ks(Rs,0),Ql=Zl.b,br=new Me(32768);for(var T=0;T<32768;++T){var oe=(T&43690)>>1|(T&21845)<<1;oe=(oe&52428)>>2|(oe&13107)<<2,oe=(oe&61680)>>4|(oe&3855)<<4,br[T]=((oe&65280)>>8|(oe&255)<<8)>>1}var at=function(t,e,r){for(var n=t.length,s=0,i=new Me(e);s<n;++s)t[s]&&++i[t[s]-1];var a=new Me(e);for(s=1;s<e;++s)a[s]=a[s-1]+i[s-1]<<1;var c;if(r){c=new Me(1<<e);var l=15-e;for(s=0;s<n;++s)if(t[s])for(var d=s<<4|t[s],f=e-t[s],u=a[t[s]-1]++<<f,h=u|(1<<f)-1;u<=h;++u)c[br[u]>>l]=d}else for(c=new Me(n),s=0;s<n;++s)t[s]&&(c[s]=br[a[t[s]-1]++]>>15-t[s]);return c},gt=new j(288);for(var T=0;T<144;++T)gt[T]=8;for(var T=144;T<256;++T)gt[T]=9;for(var T=256;T<280;++T)gt[T]=7;for(var T=280;T<288;++T)gt[T]=8;var As=new j(32);for(var T=0;T<32;++T)As[T]=5;var ed=at(gt,9,1),td=at(As,5,1),ar=function(t){for(var e=t[0],r=1;r<t.length;++r)t[r]>e&&(e=t[r]);return e},$=function(t,e,r){var n=e/8|0;return(t[n]|t[n+1]<<8)>>(e&7)&r},or=function(t,e){var r=e/8|0;return(t[r]|t[r+1]<<8|t[r+2]<<16)>>(e&7)},rd=function(t){return(t+7)/8|0},Or=function(t,e,r){return(e==null||e<0)&&(e=0),(r==null||r>t.length)&&(r=t.length),new j(t.subarray(e,r))},nd=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],B=function(t,e,r){var n=new Error(e||nd[t]);if(n.code=t,Error.captureStackTrace&&Error.captureStackTrace(n,B),!r)throw n;return n},sd=function(t,e,r,n){var s=t.length,i=n?n.length:0;if(!s||e.f&&!e.l)return r||new j(0);var a=!r,c=a||e.i!=2,l=e.i;a&&(r=new j(s*3));var d=function(yt){var ie=r.length;if(yt>ie){var vt=new j(Math.max(ie*2,yt));vt.set(r),r=vt}},f=e.f||0,u=e.p||0,h=e.b||0,_=e.l,I=e.d,b=e.m,v=e.n,C=s*8;do{if(!_){f=$(t,u,1);var S=$(t,u+1,3);if(u+=3,S)if(S==1)_=ed,I=td,b=9,v=5;else if(S==2){var _e=$(t,u,31)+257,wt=$(t,u+10,15)+4,Ce=_e+$(t,u+5,31)+1;u+=14;for(var be=new j(Ce),U=new j(19),P=0;P<wt;++P)U[Xl[P]]=$(t,u+P*3,7);u+=wt*3;for(var Ke=ar(U),Ft=(1<<Ke)-1,Ae=at(U,Ke,1),P=0;P<Ce;){var _t=Ae[$(t,u,Ft)];u+=_t&15;var R=_t>>4;if(R<16)be[P++]=R;else{var N=0,Ne=0;for(R==16?(Ne=3+$(t,u,3),u+=2,N=be[P-1]):R==17?(Ne=3+$(t,u,7),u+=3):R==18&&(Ne=11+$(t,u,127),u+=7);Ne--;)be[P++]=N}}var Pe=be.subarray(0,_e),K=be.subarray(_e);b=ar(Pe),v=ar(K),_=at(Pe,b,1),I=at(K,v,1)}else B(1);else{var R=rd(u)+4,Y=t[R-4]|t[R-3]<<8,we=R+Y;if(we>s){l&&B(0);break}c&&d(h+Y),r.set(t.subarray(R,we),h),e.b=h+=Y,e.p=u=we*8,e.f=f;continue}if(u>C){l&&B(0);break}}c&&d(h+131072);for(var qe=(1<<b)-1,Bt=(1<<v)-1,ye=u;;ye=u){var N=_[or(t,u)&qe],se=N>>4;if(u+=N&15,u>C){l&&B(0);break}if(N||B(2),se<256)r[h++]=se;else if(se==256){ye=u,_=null;break}else{var Oe=se-254;if(se>264){var P=se-257,ve=Ss[P];Oe=$(t,u,(1<<ve)-1)+Cs[P],u+=ve}var Ee=I[or(t,u)&Bt],Je=Ee>>4;Ee||B(3),u+=Ee&15;var K=Ql[Je];if(Je>3){var ve=Rs[Je];K+=or(t,u)&(1<<ve)-1,u+=ve}if(u>C){l&&B(0);break}c&&d(h+131072);var M=h+Oe;if(h<K){var bt=i-K,Xe=Math.min(K,M);for(bt+h<0&&B(3);h<Xe;++h)r[h]=n[bt+h]}for(;h<M;++h)r[h]=r[h-K]}}e.l=_,e.p=ye,e.b=h,e.f=f,_&&(f=1,e.m=b,e.d=I,e.n=v)}while(!f);return h!=r.length&&a?Or(r,0,h):r.subarray(0,h)},id=new j(0),J=function(t,e){return t[e]|t[e+1]<<8},z=function(t,e){return(t[e]|t[e+1]<<8|t[e+2]<<16|t[e+3]<<24)>>>0},cr=function(t,e){return z(t,e)+z(t,e+4)*4294967296};function ad(t,e){return sd(t,{i:2},e&&e.out,e&&e.dictionary)}var yr=typeof TextDecoder<"u"&&new TextDecoder,od=0;try{yr.decode(id,{stream:!0}),od=1}catch{}var cd=function(t){for(var e="",r=0;;){var n=t[r++],s=(n>127)+(n>223)+(n>239);if(r+s>t.length)return{s:e,r:Or(t,r-1)};s?s==3?(n=((n&15)<<18|(t[r++]&63)<<12|(t[r++]&63)<<6|t[r++]&63)-65536,e+=String.fromCharCode(55296|n>>10,56320|n&1023)):s&1?e+=String.fromCharCode((n&31)<<6|t[r++]&63):e+=String.fromCharCode((n&15)<<12|(t[r++]&63)<<6|t[r++]&63):e+=String.fromCharCode(n)}};function ld(t,e){if(e){for(var r="",n=0;n<t.length;n+=16384)r+=String.fromCharCode.apply(null,t.subarray(n,n+16384));return r}else{if(yr)return yr.decode(t);var s=cd(t),i=s.s,r=s.r;return r.length&&B(8),i}}var dd=function(t,e){return e+30+J(t,e+26)+J(t,e+28)},ud=function(t,e,r){var n=J(t,e+28),s=ld(t.subarray(e+46,e+46+n),!(J(t,e+8)&2048)),i=e+46+n,a=z(t,e+20),c=r&&a==4294967295?hd(t,i):[a,z(t,e+24),z(t,e+42)],l=c[0],d=c[1],f=c[2];return[J(t,e+10),l,d,s,i+J(t,e+30)+J(t,e+32),f]},hd=function(t,e){for(;J(t,e)!=1;e+=4+J(t,e+2));return[cr(t,e+12),cr(t,e+4),cr(t,e+20)]};function fd(t,e){for(var r={},n=t.length-22;z(t,n)!=101010256;--n)(!n||t.length-n>65558)&&B(13);var s=J(t,n+8);if(!s)return{};var i=z(t,n+16),a=i==4294967295||s==65535;if(a){var c=z(t,n-12);a=z(t,c)==101075792,a&&(s=z(t,c+32),i=z(t,c+48))}for(var l=0;l<s;++l){var d=ud(t,i,a),f=d[0],u=d[1],h=d[2],_=d[3],I=d[4],b=d[5],v=dd(t,b);i=I,f?f==8?r[_]=ad(t.subarray(v,v+u),{out:new j(h)}):B(14,"unknown compression type "+f):r[_]=Or(t,v,v+u)}return r}const Tn="http://10.30.45.75:8080",Ie={STAGING:"ota_staging",TMP:"ota_tmp",BUNDLES:"ota_bundles"},lr={CURRENT_VERSION:"ota_current_version",BUNDLE_PATH:"ota_bundle_path"},pd=15*1024*1024;class Ue{constructor(){}static getInstance(){return Ue.instance||(Ue.instance=new Ue),Ue.instance}async checkForUpdate(){try{const e=await fetch(`${Tn}/version.json?t=${Date.now()}`);if(!e.ok)return;const r=await e.json(),s=(await ir.get({key:lr.CURRENT_VERSION})).value||"0.0.0";this.isNewerVersion(s,r.version)&&await this.downloadAndApplyUpdate(r)}catch{}}isNewerVersion(e,r){const n=e.split(".").map(Number),s=r.split(".").map(Number);for(let i=0;i<3;i++){if((s[i]||0)>(n[i]||0))return!0;if((s[i]||0)<(n[i]||0))return!1}return!1}async downloadAndApplyUpdate(e){const r=e.url||`${Tn}/app-bundle-${e.version}.zip`;if(!(e.size&&e.size>pd))try{await L.mkdir({path:Ie.TMP,directory:A.Data,recursive:!0}).catch(()=>{});const s=await(await fetch(r)).arrayBuffer(),i=new Uint8Array(s),a=`${Ie.STAGING}/v${e.version}`;await L.mkdir({path:a,directory:A.Data,recursive:!0}).catch(()=>{});const c=fd(i);for(const[u,h]of Object.entries(c)){if(h.length===0||u.endsWith("/")){await L.mkdir({path:`${a}/${u}`,directory:A.Data,recursive:!0}).catch(()=>{});continue}let _="";for(let b=0;b<h.length;b++)_+=String.fromCharCode(h[b]);const I=window.btoa(_);await L.writeFile({path:`${a}/${u}`,data:I,directory:A.Data,recursive:!0})}const l=`${Ie.BUNDLES}/v${e.version}`;await L.mkdir({path:Ie.BUNDLES,directory:A.Data,recursive:!0}).catch(()=>{}),await L.rmdir({path:l,directory:A.Data,recursive:!0}).catch(()=>{}),await L.rename({from:a,to:l,directory:A.Data});let f=(await L.stat({path:l,directory:A.Data})).uri;await ir.set({key:lr.BUNDLE_PATH,value:f}),await ir.set({key:lr.CURRENT_VERSION,value:e.version}),await this.cleanupOldBundles(e.version),window.dispatchEvent(new CustomEvent("ota_update_ready",{detail:{version:e.version}}))}catch{await L.rmdir({path:Ie.STAGING,directory:A.Data,recursive:!0}).catch(()=>{})}}async cleanupOldBundles(e){try{const r=await L.readdir({path:Ie.BUNDLES,directory:A.Data});for(const n of r.files){const s=typeof n=="string"?n:n.name;s.startsWith("v")&&s!==`v${e}`&&await L.rmdir({path:`${Ie.BUNDLES}/${s}`,directory:A.Data,recursive:!0}).catch(i=>{})}}catch{}}}const Ns=(t,e,r)=>{const n=vr(),s=JSON.stringify({message:t,stackTrace:e,componentStack:r,userId:n?.id||"ANONYMOUS"});fetch(`${dr}/api/bugs/report`,{method:"POST",headers:{"Content-Type":"application/json"},body:s}).catch(()=>{navigator.sendBeacon(`${dr}/api/bugs/report`,s)})};window.onerror=(t,e,r,n,s)=>{Ns(t.toString(),s?.stack||`${e}:${r}:${n}`)};window.onunhandledrejection=t=>{Ns(`Unhandled Promise Rejection: ${t.reason}`,t.reason?.stack||"")};const Ps=document.getElementById("root");if(!Ps)throw new Error("Could not find root element to mount to");async function md(){await ql(),Xs.createRoot(Ps).render(o.jsx(Ys.StrictMode,{children:o.jsx(Kl,{})})),setTimeout(()=>{Ue.getInstance().checkForUpdate().catch(console.error)},5e3)}md();export{In as E};
