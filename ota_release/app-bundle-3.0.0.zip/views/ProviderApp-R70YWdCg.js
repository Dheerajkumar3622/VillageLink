import{A as S,j as e,B}from"../assets/synapse-DJbL7Np4.js";import{r as i,R as O}from"../assets/vendor-react-BR5y8XGT.js";import{aa as Q,ar as Y,aR as fe,A as ee,T as se,w as ne,aS as je,aT as ve,m as W,a0 as H,a2 as ae,a5 as L,P as Ne,N as ye,al as we,$ as ke,c as _,e as G,ap as Ce,F as Se,aU as Re,aK as Pe,aV as Ee,aW as Ae,aj as oe,aX as Te,W as ce,ay as de,l as xe,aY as me,q as Oe,aN as qe,x as ze,ah as De,ai as re,o as Ie,aZ as $e}from"../assets/vendor-ui-C2GrFI-5.js";import{C as Le,G as X,R as Me}from"../assets/index-B8VbTDW_.js";import{DriverView as ie}from"./DriverView-B4DpsSpR.js";import{KisanApp as Be}from"./KisanApp-CuIkvKOe.js";import{VendorView as Ve}from"./VendorView-DuESuoFU.js";import Fe from"./MessManagerView-C3Oj5qR_.js";import Ue from"./ShopkeeperView-CjinT01B.js";import"../assets/vendor-socket-TjCxX7sJ.js";import"../assets/LocationSelector-Jcc1jE6F.js";import"../assets/adminService-DYIzXK5E.js";import"../assets/blockchainService-B4N5Ogdy.js";import"../assets/mlService-Bs6DwhV3.js";import"../assets/advancedFeatures-CV2JTQEo.js";import"../assets/Modal-DXxO_P8Y.js";import"../assets/marketingService-B16yCu59.js";const Ke=({user:a,onOpenChat:m})=>{const[n,r]=i.useState(null),[l,d]=i.useState(!1),[x,b]=i.useState(!1);i.useEffect(()=>{const j=setTimeout(()=>b(!0),1500);w();const k=setInterval(w,12e4);return()=>{clearTimeout(j),clearInterval(k)}},[]);const w=async()=>{try{const j=localStorage.getItem("villagelink_token"),v=await(await fetch(`${S}/api/ai/insights`,{headers:{Authorization:`Bearer ${j}`}})).json();v.success&&v.insight&&r(v.insight)}catch{}};return x?e.jsxs("div",{className:"fixed bottom-24 right-4 z-[100] flex flex-col items-end gap-3 pointer-events-none",children:[n&&!l&&e.jsxs("div",{className:"animate-slide-up pointer-events-auto bg-[var(--bg-elevated)] border border-[var(--border-glow)] rounded-2xl p-3 pr-8 shadow-2xl max-w-[240px] relative",children:[e.jsx("button",{onClick:()=>r(null),className:"absolute top-1 right-1 p-1 opacity-50 hover:opacity-100",title:"Close Insight",children:e.jsx(Q,{size:12})}),e.jsxs("div",{className:"flex gap-2",children:[e.jsx("div",{className:"w-6 h-6 rounded-full bg-[var(--accent-primary)]/20 flex items-center justify-center flex-shrink-0",children:e.jsx(Y,{size:12,className:"text-[var(--accent-primary)]"})}),e.jsx("p",{className:"text-[11px] leading-tight text-[var(--text-primary)]",children:n})]})]}),e.jsxs("div",{className:"pointer-events-auto flex flex-col items-end",children:[l&&e.jsx("div",{className:"mb-2 bg-[var(--bg-surface)] border border-[var(--border-subtle)] rounded-2xl p-2 shadow-2xl min-w-[200px] animate-fade-in origin-bottom-right",children:e.jsxs("button",{onClick:m,className:"w-full flex items-center justify-between p-3 rounded-xl hover:bg-white/5 transition-colors group",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(fe,{size:16,className:"text-[var(--accent-primary)]"}),e.jsx("span",{className:"text-sm font-semibold",children:"Talk to Sahayak"})]}),e.jsx(ee,{size:14,className:"opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all"})]})}),e.jsxs("button",{onClick:()=>d(!l),className:`w-14 h-14 rounded-full flex items-center justify-center shadow-whisk-float transition-all duration-500 relative group
                                ${l?"bg-[var(--bg-elevated)] rotate-90":"bg-gradient-to-br from-[var(--accent-primary)] to-[var(--accent-secondary)]"}`,children:[!l&&e.jsx("div",{className:"absolute inset-0 rounded-full bg-[var(--accent-primary)] animate-ping opacity-20 group-hover:opacity-40 transition-opacity"}),l?e.jsx(Q,{size:24,className:"text-[var(--text-primary)]"}):e.jsx(Y,{size:28,className:"text-[var(--bg-void)] drop-shadow-lg"})]})]}),e.jsx("style",{children:`
                .animate-slide-up {
                    animation: sahayakSlideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
                .animate-fade-in {
                    animation: sahayakFadeIn 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
                @keyframes sahayakSlideUp {
                    from { opacity: 0; transform: translateY(10px) scale(0.95); }
                    to { opacity: 1; transform: translateY(0) scale(1); }
                }
                @keyframes sahayakFadeIn {
                    from { opacity: 0; transform: scale(0.9); }
                    to { opacity: 1; transform: scale(1); }
                }
            `})]}):null},Qe=({name:a,balance:m,avatarUrl:n,onClick:r})=>{const l=a?.charAt(0)?.toUpperCase()||"U",d=typeof m=="number"?`₹${m.toLocaleString()}`:m||"₹0",x=a?.split(" ")[0]||"User";return e.jsxs("div",{className:"v5-profile-pill",onClick:r,role:"button",tabIndex:0,children:[e.jsx("div",{className:"w-8 h-8 rounded-full bg-gradient-to-br from-[var(--accent-tertiary)] to-[var(--accent-hot)] flex items-center justify-center text-xs font-bold text-white",children:n?e.jsx("img",{src:n,alt:a,className:"w-full h-full rounded-full object-cover"}):l}),e.jsxs("div",{className:"flex flex-col",children:[e.jsx("span",{className:"text-xs font-semibold text-[var(--text-primary)]",children:x}),m!==void 0&&e.jsx("span",{className:"text-[10px] font-semibold text-[var(--accent-primary)] font-mono",children:d})]})]})},le={AUTO:{weight:20,volume:50},BUS:{weight:100,volume:200},TEMPO:{weight:500,volume:1e3},TRUCK:{weight:2e3,volume:5e3},BIKE:{weight:5,volume:20},CAR:{weight:30,volume:100}},_e=["PRODUCE","GOODS","FOOD","DOCUMENTS","PACKAGE"],Ge=({driverId:a,driverName:m,currentRoute:n,onBack:r})=>{const[l,d]=i.useState(!1),[x,b]=i.useState(null),[w,j]=i.useState([]),[k,v]=i.useState([]),[q,E]=i.useState([]),[T,z]=i.useState(!1),[R,D]=i.useState(!1),[I,A]=i.useState(!1),[u,t]=i.useState(null),[o,N]=i.useState(""),[f,g]=i.useState(!1);i.useEffect(()=>{V(),C();const s=setInterval(C,1e4);return()=>clearInterval(s)},[a]);const V=async()=>{try{const p=await(await fetch(`${S}/api/cargo/capacity/${a}`)).json();p.success&&b(p.capacity)}catch{}},C=async()=>{try{const p=await(await fetch(`${S}/api/cargo/driver/${a}`)).json();p.success&&(j(p.assignedCargo||[]),v(p.availableCargo||[]),E(p.pendingMatches||[]))}catch{}},$=async s=>{d(!0);try{const P=await(await fetch(`${S}/api/cargo/capacity/${a}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({...x,...s,driverName:m})})).json();P.success&&b(P.capacity)}catch{}d(!1)},c=()=>{x&&$({acceptingCargo:!x.acceptingCargo})},y=async s=>{g(!0);try{(await(await fetch(`${S}/api/cargo/accept`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({matchId:s.id,driverId:a,acceptedPrice:s.offerPrice})})).json()).success&&(C(),alert("✅ Cargo accepted! Pickup OTP will be shown."))}catch{}g(!1)},h=async()=>{if(u){g(!0);try{const p=await(await fetch(`${S}/api/cargo/pickup/${u.id}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({otp:o,driverId:a,photo:""})})).json();p.success?(alert("✅ Pickup confirmed! Deliver to: "+u.dropoffLocation.name),D(!1),N(""),C()):alert("❌ "+p.error)}catch{}g(!1)}},F=async()=>{if(u){g(!0);try{const p=await(await fetch(`${S}/api/cargo/deliver/${u.id}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({otp:o,driverId:a,photo:""})})).json();p.success?(alert("✅ Delivery confirmed! Earnings added to wallet."),A(!1),N(""),C(),V()):alert("❌ "+p.error)}catch{}g(!1)}},M=s=>({PRODUCE:"🌾",GOODS:"📦",FOOD:"🍱",DOCUMENTS:"📄",PACKAGE:"📬"})[s]||"📦",pe=()=>e.jsxs("div",{className:"bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl p-4 mb-4",children:[e.jsxs("div",{className:"flex justify-between items-center mb-3",children:[e.jsxs("h3",{className:"text-white font-semibold flex items-center gap-2",children:[e.jsx(se,{size:18})," Cargo Status"]}),e.jsx("button",{onClick:()=>z(!T),className:"text-slate-400 hover:text-white transition-colors","aria-label":"Settings",children:e.jsx(ne,{size:18})})]}),e.jsxs("div",{className:"grid grid-cols-3 gap-3 mb-3",children:[e.jsxs("div",{className:"bg-slate-700/50 p-3 rounded-xl text-center",children:[e.jsxs("p",{className:"text-2xl font-bold text-white",children:[x?.currentLoadKg||0,"kg"]}),e.jsx("p",{className:"text-xs text-slate-400",children:"Current Load"})]}),e.jsxs("div",{className:"bg-slate-700/50 p-3 rounded-xl text-center",children:[e.jsxs("p",{className:"text-2xl font-bold text-emerald-400",children:[x?.maxWeightKg||20,"kg"]}),e.jsx("p",{className:"text-xs text-slate-400",children:"Capacity"})]}),e.jsxs("div",{className:"bg-slate-700/50 p-3 rounded-xl text-center",children:[e.jsx("p",{className:"text-2xl font-bold text-amber-400",children:x?.totalDeliveries||0}),e.jsx("p",{className:"text-xs text-slate-400",children:"Deliveries"})]})]}),e.jsxs("button",{onClick:c,className:`w-full flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${x?.acceptingCargo?"bg-emerald-500/20 border border-emerald-500/50":"bg-slate-700/50 border border-slate-600"}`,"aria-label":x?.acceptingCargo?"Stop Accepting Cargo":"Start Accepting Cargo",children:[e.jsx("span",{className:"text-sm font-medium text-white",children:"Accept Cargo Requests"}),x?.acceptingCargo?e.jsx(je,{size:24,className:"text-emerald-400"}):e.jsx(ve,{size:24,className:"text-slate-400"})]})]}),he=()=>e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-2xl p-4 mb-4 border border-slate-200 dark:border-slate-700",children:[e.jsx("h4",{className:"font-semibold text-slate-800 dark:text-white mb-4",children:"Cargo Settings"}),e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"text-xs font-bold text-slate-500 uppercase mb-2 block",children:"Vehicle Type"}),e.jsx("div",{className:"grid grid-cols-3 gap-2",children:Object.keys(le).map(s=>e.jsx("button",{onClick:()=>$({vehicleType:s,maxWeightKg:le[s].weight}),className:`py-2 px-3 rounded-lg text-xs font-bold border transition-all ${x?.vehicleType===s?"bg-orange-100 border-orange-500 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300":"bg-slate-100 dark:bg-slate-700 border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-300"}`,children:s},s))})]}),e.jsxs("div",{children:[e.jsx("label",{className:"text-xs font-bold text-slate-500 uppercase mb-2 block",children:"Accepted Item Types"}),e.jsx("div",{className:"flex flex-wrap gap-2",children:_e.map(s=>{const p=x?.acceptedTypes?.includes(s);return e.jsxs("button",{onClick:()=>{const P=x?.acceptedTypes||[],J=p?P.filter(be=>be!==s):[...P,s];$({acceptedTypes:J})},className:`py-1.5 px-3 rounded-full text-xs font-medium border transition-all ${p?"bg-emerald-100 border-emerald-500 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300":"bg-slate-100 dark:bg-slate-700 border-slate-200 dark:border-slate-600 text-slate-500 dark:text-slate-400"}`,children:[M(s)," ",s]},s)})})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"text-xs font-bold text-slate-500 uppercase mb-2 block",children:["Price per km/kg: ₹",x?.pricePerKmPerKg||2]}),e.jsx("input",{type:"range",min:"1",max:"10",value:x?.pricePerKmPerKg||2,onChange:s=>$({pricePerKmPerKg:parseInt(s.target.value)}),className:"w-full","aria-label":"Price per km/kg"})]})]})]}),ue=()=>e.jsxs("div",{className:"space-y-3 mb-4",children:[e.jsxs("h4",{className:"font-semibold text-slate-800 dark:text-white flex items-center gap-2",children:[e.jsx(W,{size:16,className:"text-orange-500"})," Active Cargo (",w.length,")"]}),w.length===0?e.jsxs("div",{className:"bg-slate-100 dark:bg-slate-800 p-6 rounded-xl text-center",children:[e.jsx(W,{size:32,className:"mx-auto text-slate-300 mb-2"}),e.jsx("p",{className:"text-sm text-slate-500",children:"No active cargo"})]}):w.map(s=>e.jsxs("div",{className:"bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-4",children:[e.jsxs("div",{className:"flex justify-between items-start mb-3",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"text-2xl",children:M(s.itemType)}),e.jsxs("div",{children:[e.jsx("p",{className:"font-semibold text-slate-800 dark:text-white",children:s.itemName}),e.jsxs("p",{className:"text-xs text-slate-500",children:[s.weightKg,"kg • ₹",s.offeredPrice]})]})]}),e.jsx("span",{className:`px-2 py-1 rounded-full text-xs font-medium ${s.status==="DRIVER_ACCEPTED"?"bg-purple-100 text-purple-700":s.status==="PICKED_UP"?"bg-blue-100 text-blue-700":"bg-gray-100 text-gray-700"}`,children:s.status==="DRIVER_ACCEPTED"?"📍 Pickup":s.status==="PICKED_UP"?"🚛 Deliver":s.status})]}),e.jsxs("div",{className:"flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 mb-3",children:[e.jsx(H,{size:14,className:"text-green-500"}),e.jsx("span",{className:"truncate",children:s.pickupLocation.name}),e.jsx(ae,{size:14}),e.jsx(H,{size:14,className:"text-red-500"}),e.jsx("span",{className:"truncate",children:s.dropoffLocation.name})]}),e.jsxs("div",{className:"flex gap-2",children:[s.status==="DRIVER_ACCEPTED"&&e.jsxs("button",{onClick:()=>{t(s),D(!0)},className:"flex-1 bg-emerald-500 text-white py-2 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2",children:[e.jsx(L,{size:16})," Confirm Pickup"]}),s.status==="PICKED_UP"&&e.jsxs("button",{onClick:()=>{t(s),A(!0)},className:"flex-1 bg-blue-500 text-white py-2 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2",children:[e.jsx(L,{size:16})," Confirm Delivery"]}),e.jsx("a",{href:`tel:${s.shipperPhone}`,className:"bg-slate-100 dark:bg-slate-700 p-2 rounded-lg","aria-label":"Call Shipper",children:e.jsx(Ne,{size:16,className:"text-slate-600 dark:text-slate-300"})})]})]},s.id))]}),ge=()=>e.jsxs("div",{className:"space-y-3",children:[e.jsxs("h4",{className:"font-semibold text-slate-800 dark:text-white flex items-center gap-2",children:[e.jsx(ye,{size:16,className:"text-amber-500"})," Available on Your Route (",k.length,")"]}),k.length===0?e.jsxs("div",{className:"bg-amber-50 dark:bg-amber-900/20 p-4 rounded-xl text-center border border-amber-200 dark:border-amber-800",children:[e.jsx("p",{className:"text-sm text-amber-700 dark:text-amber-300",children:"No cargo available on your route"}),e.jsx("p",{className:"text-xs text-amber-600 dark:text-amber-400 mt-1",children:"Keep cargo acceptance ON to receive requests"})]}):k.map((s,p)=>{const P=q.find(J=>J.cargoRequestId===s.id);return e.jsxs("div",{className:"bg-white dark:bg-slate-800 border-2 border-amber-200 dark:border-amber-800 rounded-xl p-4",children:[e.jsxs("div",{className:"flex justify-between items-start mb-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"text-2xl",children:M(s.itemType)}),e.jsxs("div",{children:[e.jsx("p",{className:"font-semibold text-slate-800 dark:text-white",children:s.itemName}),e.jsxs("p",{className:"text-xs text-slate-500",children:[s.weightKg,"kg from ",s.shipperName]})]})]}),e.jsxs("div",{className:"text-right",children:[e.jsxs("p",{className:"font-bold text-lg text-orange-600",children:["₹",s.offeredPrice]}),n&&(s.pickupLocation.name===n.from||s.dropoffLocation.name===n.to)&&e.jsxs("div",{className:"flex items-center gap-1 bg-brand-500 text-white px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest animate-pulse mt-1",children:[e.jsx(we,{size:10})," Smart Match"]})]})]}),e.jsxs("div",{className:"flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 mb-3",children:[e.jsx(H,{size:14,className:"text-green-500"}),e.jsx("span",{className:"truncate",children:s.pickupLocation.name}),e.jsx(ae,{size:14}),e.jsx(H,{size:14,className:"text-red-500"}),e.jsx("span",{className:"truncate",children:s.dropoffLocation.name})]}),P&&e.jsxs("div",{className:"flex gap-2 text-xs text-slate-500 mb-3",children:[e.jsxs("span",{className:"bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded",children:[e.jsx(ke,{size:10,className:"inline mr-1"}),"Pickup: ",P.estimatedPickupTime," min"]}),e.jsxs("span",{className:"bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded",children:["Delivery: ",P.estimatedDeliveryTime," min"]})]}),e.jsxs("div",{className:"flex gap-2",children:[e.jsxs("button",{onClick:()=>P&&y(P),disabled:f,className:"flex-1 bg-emerald-500 text-white py-2 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-50",children:[e.jsx(L,{size:16})," Accept"]}),e.jsx("button",{className:"bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 py-2 px-4 rounded-lg font-semibold text-sm",children:"Counter"})]})]},s.id)})]}),te=s=>e.jsx("div",{className:"fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4",children:e.jsxs("div",{className:"bg-white dark:bg-slate-800 rounded-2xl p-6 w-full max-w-sm",children:[e.jsx("h3",{className:"font-bold text-lg text-slate-800 dark:text-white mb-4 text-center",children:s==="pickup"?"📦 Confirm Pickup":"✅ Confirm Delivery"}),u&&e.jsxs("div",{className:"bg-slate-100 dark:bg-slate-700 p-3 rounded-xl mb-4",children:[e.jsx("p",{className:"font-semibold",children:u.itemName}),e.jsx("p",{className:"text-sm text-slate-500",children:s==="pickup"?u.pickupLocation.name:u.dropoffLocation.name})]}),e.jsxs("p",{className:"text-sm text-slate-600 dark:text-slate-400 text-center mb-4",children:["Ask ",s==="pickup"?"shipper":"receiver"," for OTP"]}),e.jsx("input",{type:"text","aria-label":"Enter OTP",value:o,onChange:p=>N(p.target.value),placeholder:"Enter 4-digit OTP",maxLength:4,className:"w-full p-4 text-center text-2xl tracking-widest font-bold border border-slate-300 dark:border-slate-600 rounded-xl mb-4"}),e.jsxs("div",{className:"flex gap-3",children:[e.jsx("button",{onClick:()=>{s==="pickup"?D(!1):A(!1),N("")},className:"flex-1 py-3 border border-slate-300 dark:border-slate-600 rounded-xl font-semibold",children:"Cancel"}),e.jsxs("button",{onClick:s==="pickup"?h:F,disabled:f||o.length!==4,className:"flex-1 py-3 bg-emerald-500 text-white rounded-xl font-semibold disabled:opacity-50 flex items-center justify-center gap-2",children:[f?e.jsx(_,{className:"animate-spin",size:18}):e.jsx(L,{size:18}),"Verify"]})]})]})});return e.jsxs("div",{className:"space-y-4",children:[pe(),T&&he(),ue(),ge(),R&&te("pickup"),I&&te("delivery")]})},He=({user:a,role:m,onClose:n})=>{const[r,l]=i.useState("SHOP"),[d,x]=i.useState({SHOP:null,PAYMENT:null,PRODUCT:null}),[b,w]=i.useState(!0),[j,k]=i.useState(!1),[v,q]=i.useState(!1);i.useEffect(()=>{E()},[]);const E=async()=>{try{const t=localStorage.getItem("villagelink_token"),N=await(await fetch(`${S}/api/qr/my-codes`,{headers:{Authorization:`Bearer ${t}`}})).json();if(N.success&&N.qrCodes){const f={SHOP:null,PAYMENT:null,PRODUCT:null};N.qrCodes.forEach(g=>{(g.qrType==="SHOP"||g.qrType==="PAYMENT"||g.qrType==="PRODUCT")&&(f[g.qrType]=g)}),x(f)}}catch{}finally{w(!1)}},T=async t=>{k(!0);try{const o=localStorage.getItem("villagelink_token"),f=await(await fetch(`${S}/api/qr/generate`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${o}`},body:JSON.stringify({qrType:t,name:t==="SHOP"?a.businessName||a.name:t==="PAYMENT"?`Pay ${a.name}`:"Product QR"})})).json();f.success&&x({...d,[t]:f.qrCode})}catch{}finally{k(!1)}},z=t=>`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(t)}`,R=()=>{const t=d[r];t&&(navigator.clipboard.writeText(`https://villagelink.app/qr/${t.id}`),q(!0),setTimeout(()=>q(!1),2e3))},D=()=>{const t=d[r];if(t){const o=document.createElement("a");o.href=z(t.payload),o.download=`villagelink-${t.type.toLowerCase()}-qr.png`,o.click()}},I=async()=>{const t=d[r];if(t&&navigator.share)try{await navigator.share({title:`${a.name}'s VillageLink QR`,text:`Scan this QR to ${r==="SHOP"?"visit my shop":r==="PAYMENT"?"pay me":"view product"}`,url:`https://villagelink.app/qr/${t.id}`})}catch{}},A=()=>{window.print()},u=d[r];return e.jsxs("div",{className:"my-qr-modal",children:[e.jsxs("div",{className:"my-qr-container",children:[e.jsxs("div",{className:"qr-header",children:[e.jsx("h2",{children:"My QR Codes"}),e.jsx("button",{className:"close-btn","aria-label":"Close",onClick:n,children:e.jsx(Q,{className:"w-6 h-6"})})]}),e.jsxs("div",{className:"qr-type-tabs",children:[e.jsxs("button",{className:`type-tab ${r==="SHOP"?"active":""}`,onClick:()=>l("SHOP"),children:[e.jsx(G,{className:"w-4 h-4"}),"Shop"]}),e.jsxs("button",{className:`type-tab ${r==="PAYMENT"?"active":""}`,onClick:()=>l("PAYMENT"),children:[e.jsx(Ce,{className:"w-4 h-4"}),"Payment"]}),e.jsxs("button",{className:`type-tab ${r==="PRODUCT"?"active":""}`,onClick:()=>l("PRODUCT"),children:[e.jsx(Se,{className:"w-4 h-4"}),"Product"]})]}),e.jsx("div",{className:"qr-display",children:b?e.jsxs("div",{className:"qr-loading",children:[e.jsx(_,{className:"w-8 h-8 animate-spin text-gray-400"}),e.jsx("p",{children:"Loading QR codes..."})]}):u?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"qr-card",children:[e.jsx("div",{className:"qr-name",children:u.name}),e.jsx("img",{src:z(u.payload),alt:"QR Code",className:"qr-image"}),e.jsxs("p",{className:"scan-hint",children:["Scan to ",r==="SHOP"?"visit shop":r==="PAYMENT"?"make payment":"view product"]})]}),e.jsx("div",{className:"qr-stats",children:e.jsxs("div",{className:"stat",children:[e.jsx("span",{className:"stat-value",children:u.scanCount||0}),e.jsx("span",{className:"stat-label",children:"Total Scans"})]})}),e.jsxs("div",{className:"qr-actions",children:[e.jsxs("button",{className:"action-btn",onClick:R,children:[v?e.jsx(L,{className:"w-5 h-5"}):e.jsx(Re,{className:"w-5 h-5"}),v?"Copied!":"Copy Link"]}),e.jsxs("button",{className:"action-btn",onClick:D,children:[e.jsx(Pe,{className:"w-5 h-5"}),"Download"]}),e.jsxs("button",{className:"action-btn",onClick:I,children:[e.jsx(Ee,{className:"w-5 h-5"}),"Share"]}),e.jsxs("button",{className:"action-btn",onClick:A,children:[e.jsx(Ae,{className:"w-5 h-5"}),"Print"]})]})]}):e.jsxs("div",{className:"no-qr",children:[e.jsx(oe,{className:"w-16 h-16 text-gray-300"}),e.jsxs("h3",{children:["No ",r.toLowerCase()," QR code yet"]}),e.jsx("p",{children:"Generate a QR code to let customers easily find you"}),e.jsx(B,{onClick:()=>T(r),disabled:j,children:j?e.jsx(_,{className:"w-5 h-5 animate-spin"}):e.jsxs(e.Fragment,{children:["Generate ",r," QR"]})})]})}),e.jsxs("div",{className:"qr-tips",children:[e.jsx("h4",{children:"Tips:"}),e.jsxs("ul",{children:[e.jsx("li",{children:"Print and display your Shop QR at your establishment"}),e.jsx("li",{children:"Share Payment QR for quick payments from customers"}),e.jsx("li",{children:"Create Product QRs for specific items"})]})]})]}),e.jsx("style",{children:`
        .my-qr-modal {
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.8);
          z-index: 1000;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }

        .my-qr-container {
          background: white;
          border-radius: 20px;
          width: 100%;
          max-width: 400px;
          max-height: 90vh;
          overflow-y: auto;
        }

        .qr-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px 20px;
          border-bottom: 1px solid #e5e7eb;
        }

        .qr-header h2 {
          font-size: 1.25rem;
          font-weight: 600;
          color: #111827;
        }

        .close-btn {
          background: none;
          border: none;
          cursor: pointer;
          color: #6b7280;
        }

        .qr-type-tabs {
          display: flex;
          border-bottom: 1px solid #e5e7eb;
        }

        .type-tab {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 12px;
          background: none;
          border: none;
          border-bottom: 2px solid transparent;
          color: #6b7280;
          cursor: pointer;
          transition: all 0.2s;
        }

        .type-tab.active {
          color: #3b82f6;
          border-bottom-color: #3b82f6;
        }

        .qr-display {
          padding: 24px;
        }

        .qr-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 12px;
          padding: 40px;
          color: #6b7280;
        }

        .qr-card {
          text-align: center;
        }

        .qr-name {
          font-size: 1.25rem;
          font-weight: 600;
          color: #111827;
          margin-bottom: 16px;
        }

        .qr-image {
          width: 200px;
          height: 200px;
          margin: 0 auto;
          border: 4px solid #111827;
          border-radius: 12px;
        }

        .scan-hint {
          margin-top: 12px;
          color: #6b7280;
          font-size: 0.875rem;
        }

        .qr-stats {
          display: flex;
          justify-content: center;
          margin: 20px 0;
        }

        .stat {
          text-align: center;
        }

        .stat-value {
          display: block;
          font-size: 1.5rem;
          font-weight: 700;
          color: #111827;
        }

        .stat-label {
          font-size: 0.75rem;
          color: #6b7280;
        }

        .qr-actions {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 8px;
        }

        .action-btn {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          padding: 12px 8px;
          background: #f3f4f6;
          border: none;
          border-radius: 8px;
          color: #374151;
          cursor: pointer;
          font-size: 0.75rem;
          transition: background 0.2s;
        }

        .action-btn:hover {
          background: #e5e7eb;
        }

        .no-qr {
          text-align: center;
          padding: 40px 20px;
        }

        .no-qr h3 {
          font-weight: 600;
          color: #111827;
          margin: 16px 0 8px;
        }

        .no-qr p {
          color: #6b7280;
          margin-bottom: 20px;
        }

        .qr-tips {
          padding: 16px 20px;
          background: #f9fafb;
          border-top: 1px solid #e5e7eb;
        }

        .qr-tips h4 {
          font-size: 0.875rem;
          font-weight: 600;
          color: #374151;
          margin-bottom: 8px;
        }

        .qr-tips ul {
          list-style: disc;
          padding-left: 20px;
          color: #6b7280;
          font-size: 0.75rem;
        }

        .qr-tips li {
          margin-bottom: 4px;
        }

        @media print {
          .my-qr-modal {
            position: static;
            background: white;
          }
          .qr-header, .qr-type-tabs, .qr-actions, .qr-tips {
            display: none;
          }
          .qr-image {
            width: 300px;
            height: 300px;
          }
        }
      `})]})},Z=[{id:"DRIVER",icon:e.jsx(se,{className:"w-6 h-6"}),label:"Driver",description:"Bus, Auto, Taxi, or Vehicle Owner",color:"#BE5103",colorAlpha:"rgba(190, 81, 3, 0.1)",requiredDocs:["Driving License","Vehicle RC","Aadhar Card"]},{id:"FARMER",icon:e.jsx(ce,{className:"w-6 h-6"}),label:"Farmer (Kisan)",description:"Sell your produce directly",color:"#069494",colorAlpha:"rgba(6, 148, 148, 0.1)",requiredDocs:["Aadhar Card","Land Papers (optional)"]},{id:"VENDOR",icon:e.jsx(G,{className:"w-6 h-6"}),label:"Vendor / Wholesaler",description:"Trade goods in bulk",color:"#b7410E",colorAlpha:"rgba(183, 65, 14, 0.1)",requiredDocs:["GST Certificate","Business License","Aadhar Card"]},{id:"RETAILER",icon:e.jsx(de,{className:"w-6 h-6"}),label:"Retailer",description:"Buy from farmers/vendors for retail",color:"#FFCE1B",colorAlpha:"rgba(255, 206, 27, 0.1)",requiredDocs:["Shop License","Aadhar Card"]},{id:"MESS_OWNER",icon:e.jsx(xe,{className:"w-6 h-6"}),label:"Mess / Hotel / Dhaba Owner",description:"Food establishment owner",color:"#BE5103",colorAlpha:"rgba(190, 81, 3, 0.1)",requiredDocs:["FSSAI License","Business License","Aadhar Card"]},{id:"SHOPKEEPER",icon:e.jsx(G,{className:"w-6 h-6"}),label:"Shopkeeper",description:"General store or retail shop",color:"#FFCE1B",colorAlpha:"rgba(255, 206, 27, 0.1)",requiredDocs:["Shop License","Aadhar Card"]},{id:"LOGISTICS",icon:e.jsx(me,{className:"w-6 h-6"}),label:"Logistics Partner",description:"Delivery and cargo transport",color:"#069494",colorAlpha:"rgba(6, 148, 148, 0.1)",requiredDocs:["Aadhar Card","Vehicle Docs"]},{id:"VILLAGE_MANAGER",icon:e.jsx(Oe,{className:"w-6 h-6"}),label:"Village Manager (ग्राम प्रबंधक)",description:"Help villagers access digital services",color:"#FFCE1B",colorAlpha:"rgba(255, 206, 27, 0.1)",requiredDocs:["Aadhar Card","Gram Panchayat Authorization"]}],Ye=({role:a,isSelected:m,onClick:n})=>{const r=O.useRef(null);return O.useEffect(()=>{r.current&&(r.current.style.setProperty("--role-color",a.color),r.current.style.setProperty("--role-color-alpha",a.colorAlpha||a.color+"22"))},[a]),e.jsxs("button",{ref:r,className:`role-card ${m?"selected":""}`,onClick:n,children:[e.jsx("div",{className:"role-icon",children:a.icon}),e.jsxs("div",{className:"role-info",children:[e.jsx("h3",{children:a.label}),e.jsx("p",{children:a.description})]}),m&&e.jsx("div",{className:"check-badge",children:e.jsx(L,{className:"w-4 h-4"})})]})},We=({label:a,color:m})=>{const n=O.useRef(null);return O.useEffect(()=>{n.current&&(n.current.style.background=m)},[m]),e.jsx("span",{ref:n,className:"role-tag",children:a})},Je=({user:a,onComplete:m,onCancel:n})=>{const[r,l]=i.useState("select"),[d,x]=i.useState([]),[b,w]=i.useState({}),[j,k]=i.useState(""),[v,q]=i.useState(""),[E,T]=i.useState(!1),[z,R]=i.useState(null),D=t=>{d.includes(t)?x(d.filter(o=>o!==t)):x([...d,t])},I=()=>{const t=new Set;return d.forEach(o=>{Z.find(f=>f.id===o)?.requiredDocs.forEach(f=>t.add(f))}),Array.from(t)},A=(t,o)=>{w({...b,[t]:o})},u=async()=>{T(!0),R(null);try{const t=localStorage.getItem("villagelink_token"),o=[];for(const[g,V]of Object.entries(b))if(V){const C=`/uploads/${a.id}/${g.replace(/\s+/g,"_")}_${Date.now()}`;o.push({docType:g,url:C})}const f=await(await fetch(`${S}/api/user/register-roles`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({roles:d.map(g=>({roleType:g,documents:o,businessName:j||void 0,businessAddress:v||void 0}))})})).json();f.success?m(d):R(f.error||"Registration failed")}catch(t){R(t.message||"Something went wrong")}finally{T(!1)}};return e.jsxs("div",{className:"role-selector",children:[e.jsxs("div",{className:"role-selector-container",children:[e.jsxs("div",{className:"selector-header",children:[e.jsx("h1",{children:"Become a Partner"}),e.jsx("p",{children:"Select your service type(s) to get started"})]}),e.jsxs("div",{className:"step-indicator",children:[e.jsxs("div",{className:`step ${r==="select"?"active":"completed"}`,children:[e.jsx("span",{className:"step-num",children:"1"}),e.jsx("span",{className:"step-label",children:"Select Role"})]}),e.jsx("div",{className:"step-line"}),e.jsxs("div",{className:`step ${r==="documents"?"active":r==="review"?"completed":""}`,children:[e.jsx("span",{className:"step-num",children:"2"}),e.jsx("span",{className:"step-label",children:"Documents"})]}),e.jsx("div",{className:"step-line"}),e.jsxs("div",{className:`step ${r==="review"?"active":""}`,children:[e.jsx("span",{className:"step-num",children:"3"}),e.jsx("span",{className:"step-label",children:"Review"})]})]}),r==="select"&&e.jsx("div",{className:"role-grid",children:Z.map(t=>e.jsx(Ye,{role:t,isSelected:d.includes(t.id),onClick:()=>D(t.id)},t.id))}),r==="documents"&&e.jsxs("div",{className:"documents-section",children:[e.jsxs("div",{className:"business-info",children:[e.jsx("h3",{children:"Business Information"}),e.jsx("input",{type:"text",placeholder:"Business Name (optional)",value:j,onChange:t=>k(t.target.value),className:"input-field"}),e.jsx("input",{type:"text",placeholder:"Business Address",value:v,onChange:t=>q(t.target.value),className:"input-field"})]}),e.jsx("h3",{children:"Required Documents"}),e.jsx("p",{className:"hint",children:"Upload clear images of your documents"}),e.jsx("div",{className:"doc-list",children:I().map(t=>e.jsxs("div",{className:"doc-item",children:[e.jsxs("div",{className:"doc-info",children:[e.jsx("span",{className:"doc-name",children:t}),b[t]&&e.jsxs("span",{className:"doc-status",children:[e.jsx(L,{className:"w-4 h-4 text-green-500"}),b[t]?.name]})]}),e.jsxs("div",{className:"doc-actions",children:[e.jsxs("label",{className:"upload-btn",children:[e.jsx(Te,{className:"w-4 h-4"}),"Upload",e.jsx("input",{type:"file",accept:"image/*,.pdf",onChange:o=>A(t,o.target.files?.[0]||null),className:"hidden"})]}),b[t]&&e.jsx("button",{className:"remove-btn","aria-label":"Remove document",onClick:()=>A(t,null),children:e.jsx(Q,{className:"w-4 h-4"})})]})]},t))})]}),r==="review"&&e.jsxs("div",{className:"review-section",children:[e.jsx("h3",{children:"Review Your Application"}),e.jsxs("div",{className:"review-card",children:[e.jsx("h4",{children:"Selected Roles"}),e.jsx("div",{className:"selected-roles",children:d.map(t=>{const o=Z.find(N=>N.id===t);return o?e.jsx(We,{label:o.label,color:o.color},t):null})})]}),e.jsxs("div",{className:"review-card",children:[e.jsx("h4",{children:"Business Details"}),e.jsx("p",{children:j||"N/A"}),e.jsx("p",{className:"address",children:v||"N/A"})]}),e.jsxs("div",{className:"review-card",children:[e.jsx("h4",{children:"Documents Uploaded"}),e.jsxs("p",{children:[Object.keys(b).filter(t=>b[t]).length," / ",I().length," documents"]})]}),e.jsx("div",{className:"terms",children:e.jsx("p",{children:"By submitting, you agree to our Terms of Service and Partner Agreement."})})]}),z&&e.jsx("div",{className:"error-msg",children:z}),e.jsxs("div",{className:"selector-actions",children:[r!=="select"&&e.jsx(B,{variant:"secondary",onClick:()=>l(r==="documents"?"select":"documents"),children:"Back"}),r==="select"&&e.jsxs(e.Fragment,{children:[e.jsx(B,{variant:"secondary",onClick:n,children:"Cancel"}),e.jsxs(B,{onClick:()=>l("documents"),disabled:d.length===0,children:["Continue ",e.jsx(ee,{className:"w-4 h-4 ml-2"})]})]}),r==="documents"&&e.jsxs(B,{onClick:()=>l("review"),children:["Continue ",e.jsx(ee,{className:"w-4 h-4 ml-2"})]}),r==="review"&&e.jsx(B,{onClick:u,disabled:E,children:E?e.jsx(_,{className:"w-5 h-5 animate-spin"}):"Submit Application"})]})]}),e.jsx("style",{children:`
        .role-selector {
          min-height: 100vh;
          background: linear-gradient(135deg, #FFF9F5 0%, #FFF0E5 100%);
          padding: 20px;
        }

        .role-selector-container {
          max-width: 600px;
          margin: 0 auto;
        }

        .selector-header {
          text-align: center;
          margin-bottom: 24px;
        }

        .selector-header h1 {
          font-size: 1.75rem;
          font-weight: 700;
          color: #111827;
          margin-bottom: 8px;
        }

        .selector-header p {
          color: #6b7280;
        }

        .step-indicator {
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 32px;
        }

        .step {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
        }

        .step-num {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: #e5e7eb;
          color: #6b7280;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
        }

        .step.active .step-num {
          background: #BE5103;
          color: white;
        }

        .step.completed .step-num {
          background: #22c55e;
          color: white;
        }

        .step-label {
          font-size: 0.75rem;
          color: #6b7280;
        }

        .step-line {
          width: 40px;
          height: 2px;
          background: #e5e7eb;
          margin: 0 8px;
          margin-bottom: 20px;
        }

        .role-grid {
          display: flex;
          flex-direction: column;
          gap: 12px;
          margin-bottom: 24px;
        }

        .role-card {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 16px;
          background: white;
          border: 2px solid #e5e7eb;
          border-radius: 12px;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
          position: relative;
        }

        .role-card:hover {
          border-color: #9ca3af;
        }

        .role-icon {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          flex-shrink: 0;
        }

        .role-info h3 {
          font-weight: 600;
          color: #111827;
          margin-bottom: 4px;
        }

        .role-info p {
          font-size: 0.875rem;
          color: #6b7280;
        }

        .check-badge {
          position: absolute;
          top: 12px;
          right: 12px;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
        }

        .documents-section {
          background: white;
          border-radius: 12px;
          padding: 20px;
          margin-bottom: 24px;
        }

        .documents-section h3 {
          font-weight: 600;
          color: #111827;
          margin-bottom: 8px;
        }

        .hint {
          font-size: 0.875rem;
          color: #6b7280;
          margin-bottom: 16px;
        }

        .business-info {
          margin-bottom: 24px;
        }

        .input-field {
          width: 100%;
          padding: 12px;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          margin-bottom: 12px;
          font-size: 1rem;
        }

        .doc-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .doc-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px;
          background: #f9fafb;
          border-radius: 8px;
        }

        .doc-name {
          font-weight: 500;
          color: #111827;
        }

        .doc-status {
          display: flex;
          align-items: center;
          gap: 4px;
          font-size: 0.875rem;
          color: #069494;
        }

        .doc-actions {
          display: flex;
          gap: 8px;
        }

        .upload-btn {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 12px;
          background: #BE5103;
          color: white;
          border-radius: 6px;
          cursor: pointer;
          font-size: 0.875rem;
        }

        .remove-btn {
          padding: 8px;
          background: #fee2e2;
          color: #ef4444;
          border: none;
          border-radius: 6px;
          cursor: pointer;
        }

        .review-section {
          margin-bottom: 24px;
        }

        .review-section h3 {
          font-weight: 600;
          color: #111827;
          margin-bottom: 16px;
        }

        .review-card {
          background: white;
          border-radius: 12px;
          padding: 16px;
          margin-bottom: 12px;
        }

        .review-card h4 {
          font-size: 0.875rem;
          color: #6b7280;
          margin-bottom: 8px;
        }

        .selected-roles {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .role-tag {
          padding: 6px 12px;
          border-radius: 20px;
          color: white;
          font-size: 0.875rem;
        }

        .address {
          color: #6b7280;
          font-size: 0.875rem;
        }

        .terms {
          padding: 12px;
          background: #fef3c7;
          border-radius: 8px;
          margin-top: 16px;
        }

        .terms p {
          font-size: 0.875rem;
          color: #92400e;
        }

        .error-msg {
          background: #fee2e2;
          color: #dc2626;
          padding: 12px;
          border-radius: 8px;
          margin-bottom: 16px;
          text-align: center;
        }

        .selector-actions {
          display: flex;
          gap: 12px;
          justify-content: flex-end;
        }
      `})]})},U={DRIVER:{icon:e.jsx(se,{className:"w-4 h-4"}),label:"Driver",color:"#3b82f6"},FARMER:{icon:e.jsx(ce,{className:"w-4 h-4"}),label:"Farmer",color:"#22c55e"},VENDOR:{icon:e.jsx(G,{className:"w-4 h-4"}),label:"Vendor",color:"#f97316"},RETAILER:{icon:e.jsx(de,{className:"w-4 h-4"}),label:"Retailer",color:"#8b5cf6"},MESS_OWNER:{icon:e.jsx(xe,{className:"w-4 h-4"}),label:"Mess Owner",color:"#ef4444"},SHOPKEEPER:{icon:e.jsx(G,{className:"w-4 h-4"}),label:"Shopkeeper",color:"#06b6d4"},LOGISTICS:{icon:e.jsx(me,{className:"w-4 h-4"}),label:"Logistics",color:"#84cc16"}},fs=({user:a,onLogout:m})=>{const[n,r]=i.useState("dashboard"),[l,d]=i.useState("DRIVER"),[x,b]=i.useState([]),[w,j]=i.useState(!1),[k,v]=i.useState(!1),[q,E]=i.useState(!1),[T,z]=i.useState({today:0,week:0,month:0}),[R,D]=i.useState(0),[I,A]=i.useState(!1),u=({icon:c,color:y})=>{const h=O.useRef(null);return O.useEffect(()=>{h.current&&(h.current.style.color=y)},[y]),e.jsx("div",{ref:h,children:c})},t=({value:c,color:y})=>{const h=O.useRef(null);return O.useEffect(()=>{h.current&&(h.current.style.color=y)},[y]),e.jsx("span",{ref:h,className:"text-sm font-extrabold",children:c})};i.useEffect(()=>{if(a){o(),(async()=>{try{(await X.checkPermissions()).location!=="granted"&&await X.requestPermissions(),await X.getCurrentPosition({enableHighAccuracy:!0})}catch{}})();const y=setInterval(()=>{fetch(`${S}/api/health`).then(h=>h.json()).then(h=>{}).catch(h=>{})},5*60*1e3);return()=>clearInterval(y)}},[a]);const o=async()=>{try{const c=localStorage.getItem("villagelink_token"),h=await(await fetch(`${S}/api/user/me`,{headers:{Authorization:`Bearer ${c}`}})).json();if(h.providerRoles&&h.providerRoles.length>0){const F=h.providerRoles.filter(M=>M.status==="VERIFIED").map(M=>M.roleType);b(F),h.activeRole&&F.includes(h.activeRole)?d(h.activeRole):F.length>0&&d(F[0])}else E(!0)}catch{b(["DRIVER"])}},N=async c=>{d(c),j(!1),r("dashboard");try{const y=localStorage.getItem("villagelink_token");await fetch(`${S}/api/user/active-role`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${y}`},body:JSON.stringify({activeRole:c})})}catch{}},f=c=>{b(c),d(c[0]),E(!1)},g=()=>{switch(l){case"DRIVER":return e.jsx(ie,{user:a,lang:"EN"});case"FARMER":return e.jsx(Be,{});case"VENDOR":case"RETAILER":return e.jsx(Ve,{user:a});case"MESS_OWNER":return e.jsx(Fe,{user:a,onBack:()=>{}});case"SHOPKEEPER":return e.jsx(Ue,{user:a});case"LOGISTICS":return e.jsx(Ge,{driverId:a?.id||"",driverName:a?.name||"",onBack:()=>{}});default:return e.jsx(ie,{user:a,lang:"EN"})}},V=()=>{switch(n){case"dashboard":return g();case"orders":return e.jsx(Xe,{role:l,user:a});case"earnings":return e.jsx(Ze,{role:l,user:a});case"reels":return e.jsx(Me,{user:a,isCreator:!0});case"settings":return e.jsx(es,{user:a,onLogout:m});default:return null}};if(!a)return e.jsxs("div",{className:"provider-app-loading",children:[e.jsx(_,{className:"w-8 h-8 animate-spin text-blue-500"}),e.jsx("p",{children:"Loading..."})]});if(q)return e.jsx(Je,{user:a,onComplete:f,onCancel:()=>E(!1)});const C=U[l],$=O.useRef(null);return O.useEffect(()=>{$.current&&($.current.style.borderBottom=`2px solid ${C.color}44`)},[C.color]),e.jsxs("div",{className:"v5-app-shell",children:[e.jsx("div",{className:"v5-mesh-bg fixed inset-0 z-0"}),e.jsx("div",{className:"v5-grain"}),e.jsxs("header",{ref:$,className:"v5-header",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsxs("button",{className:"role-switcher-btn liquid-glass-card px-4 py-2 rounded-xl flex items-center gap-2 border border-white/10 hover:border-white/20 transition-all font-bold",onClick:()=>j(!w),children:[e.jsx(u,{icon:C.icon,color:C.color}),e.jsxs("span",{className:"text-sm",children:[C.label," Mode"]}),e.jsx(qe,{className:"w-4 h-4 opacity-50"})]}),w&&e.jsxs("div",{className:"role-dropdown absolute top-full left-5 mt-2 liquid-glass-card p-2 rounded-2xl border border-white/10 z-[200] animate-fade-in backdrop-blur-3xl bg-black/60 min-w-[200px]",children:[x.map(c=>e.jsxs("button",{className:`role-option flex items-center gap-3 w-full p-3 rounded-xl hover:bg-white/5 transition-colors ${c===l?"text-[var(--accent-primary)]":"text-white"}`,onClick:()=>N(c),children:[e.jsx(u,{icon:U[c].icon,color:c===l?"inherit":U[c].color}),e.jsx("span",{className:"text-sm font-semibold",children:U[c].label}),c===l&&e.jsx(L,{className:"w-4 h-4 ml-auto"})]},c)),e.jsxs("button",{className:"role-option flex items-center gap-3 w-full p-3 rounded-xl hover:bg-white/5 transition-colors border-t border-white/5 mt-1 text-white/50",onClick:()=>E(!0),children:[e.jsx(ze,{className:"w-4 h-4"}),e.jsx("span",{className:"text-sm font-semibold",children:"Add New Role"})]})]})]}),e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx(Qe,{name:a?.name||"Provider",balance:a?.walletBalance||0}),e.jsxs("button",{className:"relative w-10 h-10 bg-[var(--bg-glass)] border border-[var(--border-subtle)] rounded-xl flex items-center justify-center hover:border-[var(--border-glow)] transition-colors",title:"Notifications",children:[e.jsx(De,{size:18,className:"opacity-70"}),R>0&&e.jsx("span",{className:"absolute -top-1 -right-1 w-4 h-4 bg-[var(--accent-hot)] rounded-full text-[8px] font-bold flex items-center justify-center border-2 border-[var(--bg-deep)]",children:R})]})]})]}),e.jsx("div",{className:"grid grid-cols-3 gap-3 px-5 my-4",children:[{label:"Today",value:`₹${T.today}`,icon:e.jsx(re,{size:12}),color:"var(--accent-primary)"},{label:"Weekly",value:`₹${T.week}`,icon:e.jsx(Y,{size:12}),color:"var(--accent-secondary)"},{label:"Pending",value:R,icon:e.jsx(W,{size:12}),color:"var(--accent-warm)"}].map((c,y)=>e.jsxs("div",{className:"v5-card p-3 flex flex-col items-center justify-center bg-white/5",children:[e.jsx(t,{value:c.value,color:c.color}),e.jsx("span",{className:"text-[9px] text-[var(--text-muted)] uppercase tracking-wider mt-0.5 font-bold",children:c.label})]},y))}),e.jsx("main",{className:"v5-scroll-view flex-1 pb-24 relative z-10 px-5",children:V()}),e.jsx("button",{className:"fixed bottom-24 right-5 w-14 h-14 rounded-2xl bg-gradient-to-br from-[var(--accent-warm)] to-[var(--accent-hot)] flex items-center justify-center shadow-lg transform hover:scale-110 active:scale-95 transition-all z-50 text-white",onClick:()=>v(!0),title:"My QR Code",children:e.jsx(oe,{size:24})}),e.jsxs("nav",{className:"v5-bottom-nav",children:[e.jsx(K,{icon:e.jsx(Ie,{size:22}),label:"Dashboard",active:n==="dashboard",onClick:()=>r("dashboard")}),e.jsx(K,{icon:e.jsx(W,{size:22}),label:"Orders",active:n==="orders",onClick:()=>r("orders"),badge:R}),e.jsx(K,{icon:e.jsx(re,{size:22}),label:"Earnings",active:n==="earnings",onClick:()=>r("earnings")}),e.jsx(K,{icon:e.jsx($e,{size:22}),label:"Reels",active:n==="reels",onClick:()=>r("reels")}),e.jsx(K,{icon:e.jsx(ne,{size:22}),label:"Settings",active:n==="settings",onClick:()=>r("settings")})]}),e.jsx(Ke,{user:a,onOpenChat:()=>{r("reels"),A(!0)}}),I&&e.jsx("div",{className:"fixed inset-0 z-[200] bg-[var(--bg-void)]/90 backdrop-blur-xl animate-fade-in h-[100dvh]",children:e.jsxs("div",{className:"flex flex-col h-full max-w-lg mx-auto bg-[var(--bg-surface)] shadow-2xl",children:[e.jsxs("header",{className:"p-4 border-b border-[var(--border-subtle)] flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-full bg-gradient-to-br from-[var(--accent-primary)] to-[var(--accent-secondary)] flex items-center justify-center",children:e.jsx(Y,{size:20,className:"text-black"})}),e.jsxs("div",{className:"flex flex-col",children:[e.jsx("span",{className:"text-sm font-bold",children:"Gram Sahayak Pro"}),e.jsx("span",{className:"text-[10px] text-[var(--accent-primary)] animate-pulse",children:"Business Advisor Active"})]})]}),e.jsx("button",{onClick:()=>A(!1),className:"p-2 rounded-xl bg-white/5",title:"Close AI Assistant",children:e.jsx(Q,{size:20})})]}),e.jsx("div",{className:"flex-1 overflow-hidden",children:e.jsx(Le,{user:a,isAIAssistant:!0})})]})}),k&&e.jsx(He,{user:a,role:l,onClose:()=>v(!1)})]})},Xe=({role:a,user:m})=>e.jsxs("div",{className:"orders-view",children:[e.jsx("h2",{className:"view-title",children:"Orders & Requests"}),e.jsxs("p",{className:"view-empty-text",children:["No pending orders for ",U[a].label]})]}),Ze=({role:a,user:m})=>e.jsxs("div",{className:"earnings-view",children:[e.jsx("h2",{className:"view-title",children:"Earnings Dashboard"}),e.jsxs("p",{className:"view-empty-text",children:["Earnings data for ",U[a].label]})]}),es=({user:a,onLogout:m})=>e.jsxs("div",{className:"settings-view",children:[e.jsx("h2",{className:"view-title",children:"Settings"}),e.jsx(B,{variant:"danger",onClick:m,className:"mt-4",children:"Logout"})]}),K=({icon:a,label:m,active:n,onClick:r,badge:l})=>e.jsxs("button",{className:`v5-nav-item ${n?"active":""}`,onClick:r,children:[e.jsxs("div",{className:"relative",children:[e.jsx("span",{className:`text-xl ${n?"opacity-100":"opacity-40"}`,children:a}),l&&l>0&&e.jsx("span",{className:"absolute -top-1 -right-1 w-4 h-4 bg-[var(--accent-hot)] rounded-full text-[8px] font-bold flex items-center justify-center text-white",children:l>9?"9+":l})]}),e.jsx("span",{className:`text-[10px] font-semibold mt-1 ${n?"text-[var(--accent-primary)]":"text-[var(--text-muted)]"}`,children:m})]});export{fs as default};
