import{j as e,A,B as V}from"../assets/synapse-DJbL7Np4.js";import{r as s}from"../assets/vendor-react-BR5y8XGT.js";import{B as Y,am as W,f as J,aa as T,c as Q,an as K,ao as X,N as Z,e as D,A as ee,ap as H,$ as te,F as se,U as ae,m as re,_ as ne,aq as oe,ar as L,k as ie,ah as le,j as ce,S as de,M as xe}from"../assets/vendor-ui-C2GrFI-5.js";import{FoodLinkHome as me}from"./FoodLinkHome-BCtb-CJK.js";import{LogisticsApp as he}from"./LogisticsApp-Z8h-lm7r.js";import{PassengerView as pe}from"./PassengerView-C5y6awzv.js";import{GramMandiHome as ue}from"./GramMandiHome-Bugv-ecD.js";import{C as be,G as U,R as fe}from"../assets/index-B8VbTDW_.js";import{UserProfile as ge}from"./UserProfile-DiQsBBn2.js";import"../assets/vendor-socket-TjCxX7sJ.js";import"../assets/blockchainService-B4N5Ogdy.js";import"../assets/constants-CSAIR7Rh.js";import"../assets/mlService-Bs6DwhV3.js";import"../assets/LocationSelector-Jcc1jE6F.js";import"../assets/Modal-DXxO_P8Y.js";import"../assets/advancedFeatures-CV2JTQEo.js";import"../assets/marketingService-B16yCu59.js";const _=({icon:r,label:p,active:h,onClick:d})=>e.jsxs("button",{className:"flex-shrink-0 flex flex-col items-center justify-center min-w-[75px] h-full transition-all duration-300 relative group",onClick:d,children:[e.jsx("div",{className:`w-14 h-11 rounded-xl flex items-center justify-center transition-all duration-500 ${h?"nav-active-pill text-[#BE5103]":"text-white/60"}`,children:e.jsx("div",{className:`${h?"scale-110":"scale-100"} transition-transform duration-300`,children:r})}),e.jsx("span",{className:`text-[9px] font-[900] mt-1.5 uppercase tracking-wider transition-all duration-300 ${h?"text-white opacity-100":"text-white/50"}`,children:p})]}),je=({activeTab:r,onTabChange:p})=>e.jsx("nav",{className:"v5-bottom-nav fixed bottom-0 left-0 right-0 px-4 py-2 pb-6 h-22 flex items-center justify-center z-[100]",children:e.jsxs("div",{className:"flex items-center justify-around w-full max-w-lg",children:[e.jsx(_,{icon:e.jsx(Y,{size:22}),label:"Rides",active:r==="rides",onClick:()=>p("rides")}),e.jsx(_,{icon:e.jsx(W,{size:22}),label:"Mandi",active:r==="haat",onClick:()=>p("haat")}),e.jsx(_,{icon:e.jsx(J,{size:22}),label:"Food",active:r==="food",onClick:()=>p("food")})]})}),$={SHOP:{icon:e.jsx(D,{}),color:"#22c55e",label:"Shop"},PAYMENT:{icon:e.jsx(H,{}),color:"#3b82f6",label:"Payment"},TICKET:{icon:e.jsx(ne,{}),color:"#8b5cf6",label:"Ticket"},PARCEL:{icon:e.jsx(re,{}),color:"#f97316",label:"Parcel"},USER:{icon:e.jsx(ae,{}),color:"#06b6d4",label:"Profile"},PRODUCT:{icon:e.jsx(se,{}),color:"#ec4899",label:"Product"}},ve=({user:r,onClose:p,onResult:h})=>{const[d,w]=s.useState(!0),[u,x]=s.useState(!1),[N,c]=s.useState(null),[j,k]=s.useState(!1),[n,o]=s.useState([]),[a,b]=s.useState(null),[v,f]=s.useState(!1),[g,S]=s.useState(""),R=s.useRef(null),B=s.useRef(null),C=s.useRef(null),E=s.useRef(null);s.useEffect(()=>(F(),M(),()=>z()),[]);const F=async()=>{try{const t=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"}});R.current&&(R.current.srcObject=t,C.current=t),requestAnimationFrame(I)}catch{c("Camera access denied. Please enable camera permissions.")}},z=()=>{C.current&&C.current.getTracks().forEach(t=>t.stop())},I=()=>{if(!d||u)return;const t=R.current,i=B.current;if(t&&i&&t.readyState===t.HAVE_ENOUGH_DATA){const l=i.getContext("2d");i.width=t.videoWidth,i.height=t.videoHeight,l?.drawImage(t,0,0),l?.getImageData(0,0,i.width,i.height)}d&&requestAnimationFrame(I)},M=async()=>{try{const t=localStorage.getItem("villagelink_token"),l=await(await fetch(`${A}/api/qr/scan-history`,{headers:{Authorization:`Bearer ${t}`}})).json();l.success&&o(l.history.slice(0,5))}catch{}},P=async t=>{x(!0),c(null);try{let i;try{i=JSON.parse(t)}catch{const l=t.match(/QR-[\w]+/i);if(l)i={id:l[0]};else throw new Error("Invalid QR code format")}if(i.app==="villagelink"||i.id?.startsWith("QR-")){const l=i.id||t,y=localStorage.getItem("villagelink_token"),q=await(await fetch(`${A}/api/qr/${l}/scan`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${y}`},body:JSON.stringify({action:"VIEW"})})).json();if(q.success)b(q),w(!1),q.qrType==="PAYMENT"&&f(!0);else throw new Error(q.error||"QR scan failed")}else c("This is not a VillageLink QR code")}catch(i){c(i.message||"Failed to process QR code")}finally{x(!1)}},O=()=>{a&&h(a)},m=async()=>{if(!(!g||parseFloat(g)<=0)){x(!0);try{const t=localStorage.getItem("villagelink_token"),l=await(await fetch(`${A}/api/payments/quick-pay`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({recipientId:a?.payload?.id,amount:parseFloat(g)})})).json();l.success?h({...a,success:!0}):c(l.error||"Payment failed")}catch(t){c(t.message)}finally{x(!1)}}};return e.jsxs("div",{className:"qr-scanner-modal",children:[e.jsxs("div",{className:"qr-scanner-container",children:[e.jsxs("div",{className:"scanner-header",children:[e.jsx("h2",{children:"Scan QR Code"}),e.jsx("button",{className:"close-btn","aria-label":"Close scanner",onClick:p,children:e.jsx(T,{className:"w-6 h-6"})})]}),d&&!a&&e.jsxs("div",{className:"camera-view",children:[e.jsx("video",{ref:R,autoPlay:!0,playsInline:!0,muted:!0}),e.jsx("canvas",{ref:B,className:"hidden"}),e.jsxs("div",{className:"scan-frame",children:[e.jsx("div",{className:"corner tl"}),e.jsx("div",{className:"corner tr"}),e.jsx("div",{className:"corner bl"}),e.jsx("div",{className:"corner br"})]}),u&&e.jsxs("div",{className:"processing-overlay",children:[e.jsx(Q,{className:"w-8 h-8 animate-spin text-white"}),e.jsx("p",{children:"Processing..."})]}),e.jsxs("div",{className:"camera-controls",children:[e.jsx("button",{className:`control-btn ${j?"active":""}`,"aria-label":"Toggle flashlight",onClick:()=>k(!j),children:e.jsx(K,{className:"w-5 h-5"})}),e.jsx("button",{className:"control-btn","aria-label":"Select from gallery",children:e.jsx(X,{className:"w-5 h-5"})})]})]}),N&&e.jsxs("div",{className:"error-message",children:[e.jsx(Z,{className:"w-5 h-5"}),e.jsx("span",{children:N}),e.jsx("button",{onClick:()=>{c(null),w(!0)},children:"Try Again"})]}),a&&!v&&e.jsxs("div",{className:"scan-result",children:[e.jsx("div",{ref:E,className:"result-icon result-icon-dynamic",children:$[a.qrType]?.icon||e.jsx(D,{})}),e.jsx("h3",{children:a.payload?.data?.name||"VillageLink QR"}),e.jsx("p",{className:"result-type",children:$[a.qrType]?.label||a.qrType}),e.jsxs(V,{onClick:O,className:"action-btn",children:[a.qrType==="SHOP"&&"View Shop",a.qrType==="PRODUCT"&&"View Product",a.qrType==="USER"&&"View Profile",a.qrType==="TICKET"&&"View Ticket",a.qrType==="PARCEL"&&"Track Parcel",e.jsx(ee,{className:"w-4 h-4 ml-2"})]}),e.jsx("button",{className:"scan-again-btn",onClick:()=>{b(null),w(!0)},children:"Scan Another QR"})]}),v&&a&&e.jsxs("div",{className:"payment-modal",children:[e.jsxs("div",{className:"payment-header",children:[e.jsx(H,{className:"w-8 h-8 text-blue-500"}),e.jsx("h3",{children:"Send Payment"}),e.jsxs("p",{children:["to ",a.payload?.data?.name||"User"]})]}),e.jsxs("div",{className:"amount-input-wrapper",children:[e.jsx("span",{className:"currency",children:"₹"}),e.jsx("input",{type:"number",value:g,onChange:t=>S(t.target.value),placeholder:"0",autoFocus:!0})]}),e.jsx("div",{className:"quick-amounts",children:[50,100,200,500].map(t=>e.jsxs("button",{onClick:()=>S(t.toString()),className:g===t.toString()?"active":"",children:["₹",t]},t))}),e.jsx(V,{onClick:m,disabled:!g||u,className:"pay-btn",children:u?e.jsx(Q,{className:"w-5 h-5 animate-spin"}):"Pay Now"}),e.jsx("button",{className:"cancel-btn",onClick:()=>{f(!1),b(null),w(!0)},children:"Cancel"})]}),d&&n.length>0&&e.jsxs("div",{className:"recent-scans",children:[e.jsxs("h4",{children:[e.jsx(te,{className:"w-4 h-4"})," Recent Scans"]}),e.jsx("div",{className:"history-list",children:n.map(t=>e.jsxs("button",{className:"history-item",children:[$[t.qrType]?.icon,e.jsx("span",{children:t.name})]},t.id))})]}),d&&e.jsx("div",{className:"demo-buttons",children:e.jsxs("div",{className:"flex gap-2 flex-wrap",children:[e.jsx("button",{onClick:()=>P(JSON.stringify({app:"villagelink",v:1,type:"SHOP",id:"QR-SHOP123",data:{name:"Sharma Dhaba"}})),className:"px-3 py-1.5 rounded-md bg-green-500 text-white border-none text-[0.75rem]",children:"Shop QR"}),e.jsx("button",{onClick:()=>P(JSON.stringify({app:"villagelink",v:1,type:"PAYMENT",id:"QR-PAY456",data:{name:"Ramesh Kumar"}})),className:"px-3 py-1.5 rounded-md bg-blue-500 text-white border-none text-[0.75rem]",children:"Payment QR"}),e.jsx("button",{onClick:()=>P(JSON.stringify({app:"villagelink",v:1,type:"PRODUCT",id:"QR-PROD789",data:{name:"Fresh Tomatoes"}})),className:"px-3 py-1.5 rounded-md bg-pink-500 text-white border-none text-[0.75rem]",children:"Product QR"})]})})]}),e.jsx("style",{children:`
        .qr-scanner-modal {
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.9);
          z-index: 1000;
          display: flex;
          flex-direction: column;
        }

        .qr-scanner-container {
          flex: 1;
          display: flex;
          flex-direction: column;
        }

        .scanner-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px;
          color: white;
        }

        .scanner-header h2 {
          font-size: 1.25rem;
          font-weight: 600;
        }

        .close-btn {
          background: rgba(255,255,255,0.2);
          border: none;
          border-radius: 50%;
          padding: 8px;
          color: white;
          cursor: pointer;
        }

        .camera-view {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .camera-view video {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .scan-frame {
          position: absolute;
          width: 250px;
          height: 250px;
          border: 2px solid rgba(255,255,255,0.5);
        }

        .corner {
          position: absolute;
          width: 30px;
          height: 30px;
          border: 3px solid white;
        }

        .corner.tl { top: -2px; left: -2px; border-right: none; border-bottom: none; }
        .corner.tr { top: -2px; right: -2px; border-left: none; border-bottom: none; }
        .corner.bl { bottom: -2px; left: -2px; border-right: none; border-top: none; }
        .corner.br { bottom: -2px; right: -2px; border-left: none; border-top: none; }

        .processing-overlay {
          position: absolute;
          inset: 0;
          background: rgba(0,0,0,0.7);
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          color: white;
          gap: 12px;
        }

        .camera-controls {
          position: absolute;
          bottom: 20px;
          display: flex;
          gap: 16px;
        }

        .control-btn {
          background: rgba(255,255,255,0.2);
          border: none;
          border-radius: 50%;
          padding: 12px;
          color: white;
          cursor: pointer;
        }

        .control-btn.active {
          background: #fbbf24;
          color: #111827;
        }

        .error-message {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 12px;
          padding: 24px;
          color: #ef4444;
        }

        .error-message button {
          background: #ef4444;
          color: white;
          border: none;
          padding: 8px 16px;
          border-radius: 8px;
          cursor: pointer;
        }

        .scan-result {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 24px;
          color: white;
        }

        .result-icon {
          width: 64px;
          height: 64px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 16px;
        }

        .result-icon svg {
          width: 32px;
          height: 32px;
          color: white;
        }

        .scan-result h3 {
          font-size: 1.5rem;
          font-weight: 600;
          margin-bottom: 8px;
        }

        .result-type {
          color: #9ca3af;
          margin-bottom: 24px;
        }

        .action-btn {
          display: flex;
          align-items: center;
          margin-bottom: 16px;
        }

        .scan-again-btn {
          background: none;
          border: none;
          color: #9ca3af;
          cursor: pointer;
          text-decoration: underline;
        }

        .payment-modal {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 24px;
          color: white;
        }

        .payment-header {
          text-align: center;
          margin-bottom: 32px;
        }

        .payment-header h3 {
          font-size: 1.5rem;
          margin-top: 12px;
        }

        .payment-header p {
          color: #9ca3af;
        }

        .amount-input-wrapper {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 24px;
        }

        .currency {
          font-size: 2rem;
          color: #9ca3af;
        }

        .amount-input-wrapper input {
          font-size: 3rem;
          width: 150px;
          background: none;
          border: none;
          color: white;
          text-align: center;
          outline: none;
        }

        .quick-amounts {
          display: flex;
          gap: 12px;
          margin-bottom: 32px;
        }

        .quick-amounts button {
          padding: 8px 16px;
          border-radius: 8px;
          background: rgba(255,255,255,0.1);
          border: 1px solid rgba(255,255,255,0.2);
          color: white;
          cursor: pointer;
        }

        .quick-amounts button.active {
          background: #3b82f6;
          border-color: #3b82f6;
        }

        .pay-btn {
          width: 100%;
          max-width: 300px;
          margin-bottom: 16px;
        }

        .cancel-btn {
          background: none;
          border: none;
          color: #9ca3af;
          cursor: pointer;
        }

        .recent-scans {
          padding: 16px;
          background: rgba(255,255,255,0.05);
        }

        .recent-scans h4 {
          display: flex;
          align-items: center;
          gap: 8px;
          color: #9ca3af;
          font-size: 0.875rem;
          margin-bottom: 12px;
        }

        .history-list {
          display: flex;
          gap: 8px;
          overflow-x: auto;
        }

        .history-item {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 12px;
          background: rgba(255,255,255,0.1);
          border: none;
          border-radius: 8px;
          color: white;
          white-space: nowrap;
          cursor: pointer;
        }

        .demo-buttons {
          padding: 16px;
          text-align: center;
        }
      `})]})},we=({onClose:r,onClaim:p})=>{const[h,d]=s.useState(!1),[w,u]=s.useState(0),x=s.useRef(null),[N,c]=s.useState(!1),j="₹50 Wallet Credit";s.useEffect(()=>{const n=x.current;if(!n)return;const o=n.getContext("2d");if(o){o.fillStyle="#475569",o.fillRect(0,0,n.width,n.height),o.fillStyle="#94a3b8",o.font="bold 16px sans-serif",o.textAlign="center",o.fillText("SCRATCH HERE",n.width/2,n.height/2+5),o.strokeStyle="#64748b",o.lineWidth=2;for(let a=0;a<20;a++)o.beginPath(),o.moveTo(Math.random()*n.width,Math.random()*n.height),o.lineTo(Math.random()*n.width,Math.random()*n.height),o.stroke()}},[]);const k=n=>{if(!N||h)return;const o=x.current;if(!o)return;const a=o.getContext("2d");if(!a)return;const b=o.getBoundingClientRect();let v,f;"touches"in n?(v=n.touches[0].clientX-b.left,f=n.touches[0].clientY-b.top):(v=n.clientX-b.left,f=n.clientY-b.top),a.globalCompositeOperation="destination-out",a.beginPath(),a.arc(v,f,20,0,Math.PI*2),a.fill(),u(g=>{const S=g+1;return S>40&&d(!0),S})};return e.jsx("div",{className:"fixed inset-0 z-[300] bg-black/80 backdrop-blur-md flex items-center justify-center p-6 animate-fade-in",children:e.jsxs("div",{className:"w-full max-w-sm bg-slate-900 border border-white/10 rounded-[40px] p-8 relative overflow-hidden shadow-2xl",children:[e.jsx("button",{onClick:r,className:"absolute top-6 right-6 text-slate-500 hover:text-white transition-colors",title:"Close Mystery Reward",children:e.jsx(T,{size:24})}),e.jsxs("div",{className:"text-center mb-8",children:[e.jsx("div",{className:"w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-500",children:e.jsx(oe,{size:32})}),e.jsx("h2",{className:"text-2xl font-black text-white uppercase tracking-tight",children:"Mystery Reward"}),e.jsx("p",{className:"text-sm text-slate-500 font-medium",children:"Daily dopamine boost for our loyal villagers"})]}),e.jsxs("div",{className:"relative aspect-video bg-indigo-950/30 rounded-3xl border-2 border-dashed border-indigo-500/30 flex flex-col items-center justify-center overflow-hidden group",children:[e.jsxs("div",{className:"text-center animate-bounce",children:[e.jsx(L,{className:"text-amber-400 mx-auto mb-2",size:32}),e.jsx("h3",{className:"text-3xl font-black text-white",children:j})]}),!h&&e.jsx("canvas",{ref:x,width:340,height:190,className:"absolute inset-0 cursor-crosshair touch-none",onMouseDown:()=>c(!0),onMouseUp:()=>c(!1),onMouseMove:k,onTouchStart:()=>c(!0),onTouchEnd:()=>c(!1),onTouchMove:k})]}),e.jsxs("div",{className:"mt-8",children:[e.jsx("button",{onClick:()=>p(j),disabled:!h,className:`w-full py-4 rounded-2xl font-black uppercase tracking-[0.2em] transition-all shadow-glow-md ${h?"bg-indigo-600 text-white cursor-pointer hover:bg-indigo-500":"bg-slate-800 text-slate-600 cursor-not-allowed"}`,children:h?"Claim Reward":"Scratch to Reveal"}),e.jsx("p",{className:"text-[10px] text-center text-slate-500 font-bold uppercase tracking-widest mt-4",children:"Safe & Verified by VillageLink Infrastructure"})]})]})})},Ue=({user:r,onLogout:p,lang:h="EN",darkMode:d,toggleTheme:w})=>{const[u,x]=s.useState("rides"),[N,c]=s.useState(!1),[j,k]=s.useState(0),[n,o]=s.useState(!1),[a,b]=s.useState(null),[v,f]=s.useState(!1),[g,S]=s.useState(!1),[R,B]=s.useState(!1),[C,E]=s.useState(!1),[F,z]=s.useState(!1);s.useEffect(()=>{const m=new AbortController;if(r){I(m.signal),(async()=>{try{(await U.checkPermissions()).location!=="granted"&&await U.requestPermissions();try{await U.getCurrentPosition({enableHighAccuracy:!0})}catch{}}catch{}})();const l=setInterval(()=>{fetch(`${A}/api/health`).then(y=>y.json()).then(y=>{}).catch(y=>{})},5*60*1e3);return()=>{m.abort(),clearInterval(l)}}const t=[{icon:"⛈️",text:"Rain predicted tonight. Book your commute for tomorrow early?"},{icon:"🥛",text:"Fresh milk from Nasirganj Hub is selling out fast!"},{icon:"🎁",text:"Mystery Scratch Card available! Claim your daily reward."},{icon:"🌾",text:"New organic tomatoes harvested at Dehri Village."}];return b(t[Math.floor(Math.random()*t.length)]),()=>m.abort()},[r]);const I=async m=>{try{const t=localStorage.getItem("villagelink_token"),l=await(await fetch(`${A}/api/chat/unread-count`,{headers:{Authorization:`Bearer ${t}`},signal:m})).json();l.success&&k(l.unreadCount)}catch(t){if(t.name==="AbortError")return}},[M,P]=s.useState(!1);s.useEffect(()=>{const m=()=>{const i=document.querySelector(".v5-main-content");i&&i.scrollTop>10?P(!0):P(!1)},t=document.querySelector(".v5-main-content");if(t)return t.addEventListener("scroll",m),()=>t.removeEventListener("scroll",m)},[u]);const O=()=>{switch(u){case"rides":return e.jsx(pe,{user:r,lang:h,isScrolled:M,onLogout:p});case"reels":return e.jsx(fe,{user:r});case"haat":return e.jsx(ue,{user:r,onBack:()=>x("rides")});case"food":return e.jsx(me,{user:r,onBack:()=>x("rides")});case"cargo":return e.jsx(he,{});case"profile":return e.jsx(ge,{user:r,onBack:()=>x("rides"),onLogout:p});default:return null}};return r?e.jsxs("div",{className:"v5-app-shell",children:[e.jsxs("div",{className:`v5-mesh-bg fixed inset-0 z-0 transition-all duration-1000 ${d?"bg-[#0A0705]":"bg-[#FFF9F5]"}`,children:[e.jsx("div",{className:`absolute top-[-10%] left-[-10%] w-[45%] h-[45%] blur-[120px] rounded-full animate-pulse ${d?"bg-[#BE5103]/20":"bg-[#BE5103]/10"}`}),e.jsx("div",{className:`absolute bottom-[-10%] right-[-10%] w-[45%] h-[45%] blur-[120px] rounded-full animate-pulse ${d?"bg-[#FFCE1B]/15":"bg-[#FFCE1B]/10"}`,style:{animationDelay:"1s"}}),e.jsx("div",{className:`absolute top-[40%] right-[-5%] w-[30%] h-[30%] blur-[100px] rounded-full animate-pulse ${d?"bg-[#069494]/15":"bg-[#069494]/10"}`,style:{animationDelay:"2s"}})]}),e.jsxs("header",{className:`v5-header glass-panel px-6 py-4 flex items-center justify-between z-50 transition-all duration-500 max-w-md mx-auto ${M?"![border-radius:0_0_50%_50%/0_0_24px_24px] !shadow-lg border-b-border-subtle backdrop-blur-2xl":"![border-radius:32px_32px_0_0] !border-b-transparent !shadow-none"}`,children:[e.jsx("div",{className:"flex items-center gap-3 animate-[pulseGlow_3s_ease-in-out_infinite] rounded-full transition-all duration-500",children:u==="profile"?e.jsx("button",{onClick:()=>x("rides"),className:"p-2 rounded-full bg-white/50 dark:bg-slate-800/50 hover:bg-white dark:hover:bg-slate-700 transition-colors shadow-sm","aria-label":"Go Back",children:e.jsx(ie,{size:20,className:"text-slate-900 dark:text-white"})}):e.jsxs("div",{className:"v5-logo-holographic",children:[e.jsx("span",{className:"v5-logo-sparkle"}),e.jsx("span",{className:"v5-logo-sparkle"}),e.jsx("span",{className:"v5-logo-sparkle"}),e.jsx("span",{children:"V"})]})}),e.jsxs("div",{className:"v5-living-header",children:[e.jsxs("div",{className:"v5-avatar-ecosystem",onClick:()=>{u==="profile"?z(!0):x("profile")},children:[e.jsx("div",{className:"v5-breathing-ring"}),e.jsx("div",{className:"v5-avatar-core",children:r?.name?.charAt(0)?.toUpperCase()||"U"})]}),e.jsxs("div",{className:"v5-user-info",children:[e.jsx("span",{className:"v5-user-name",children:r?.name?.split(" ")[0]||"User"}),e.jsxs("div",{className:"v5-wallet-section",children:[e.jsxs("span",{className:"v5-wallet-amount",children:["₹",(r?.balance||2440).toLocaleString()]}),e.jsx("div",{className:"v5-wallet-health",children:e.jsx("div",{className:"v5-wallet-health-fill",style:{width:"75%"}})})]})]}),e.jsx("div",{className:"v5-header-divider"}),e.jsxs("div",{className:"relative",children:[e.jsxs("button",{className:"v5-notification-orb","aria-label":"Notifications",onClick:()=>E(!C),children:[e.jsx(le,{size:16}),j>0&&e.jsx("span",{className:"v5-notification-badge",children:j})]}),C&&e.jsxs("div",{className:"absolute right-0 top-full mt-2 w-72 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-800 z-[100] animate-fade-in overflow-hidden",children:[e.jsxs("div",{className:"p-3 border-b flex justify-between items-center dark:border-slate-800",children:[e.jsx("h3",{className:"font-bold text-sm",children:"Notifications"}),e.jsx("button",{onClick:()=>E(!1),children:e.jsx(T,{size:14})})]}),e.jsxs("div",{className:"max-h-64 overflow-y-auto",children:[a?e.jsxs("div",{className:"p-3 border-b dark:border-slate-800 text-xs flex gap-2 items-start bg-blue-50/50 dark:bg-blue-900/20",children:[e.jsx("span",{className:"text-xl",children:a.icon}),e.jsxs("div",{children:[e.jsx("p",{className:"font-medium",children:"System Alert"}),e.jsx("p",{className:"text-slate-500 dark:text-slate-400 mt-0.5",children:a.text})]})]}):null,e.jsxs("div",{className:"p-3 border-b dark:border-slate-800 text-xs flex gap-2 items-start",children:[e.jsx("div",{className:"w-8 h-8 rounded-full bg-brand-500/10 text-brand-500 flex items-center justify-center",children:e.jsx(L,{size:14})}),e.jsxs("div",{children:[e.jsx("p",{className:"font-medium",children:"Welcome to VillageLink v5"}),e.jsx("p",{className:"text-slate-500 dark:text-slate-400 mt-0.5",children:"Explore the new unified Super App!"})]})]})]}),e.jsx("div",{className:"p-2 text-center border-t dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50",children:e.jsx("button",{className:"text-[10px] uppercase font-bold text-slate-500 tracking-wider",children:"Mark all as read"})})]})]}),u==="profile"?e.jsx("button",{onClick:p,className:"bg-red-500 text-white p-2 rounded-full shadow-lg shadow-red-500/20 active:scale-95 transition-transform flex items-center justify-center shrink-0","aria-label":"Sign Out",children:e.jsx(ce,{size:16,strokeWidth:3,className:"text-white"})}):e.jsxs("button",{className:`v5-eclipse-toggle ${d?"dark":"light"}`,onClick:w,"aria-label":"Toggle theme",children:[e.jsx(de,{size:16,className:"v5-sun-icon text-amber-400"}),e.jsx(xe,{size:16,className:"v5-moon-icon text-indigo-400"})]})]})]}),e.jsx("main",{className:"v5-scroll-view v5-main-content pb-24 overflow-y-auto h-screen",style:{scrollBehavior:"smooth"},children:O()}),e.jsx(je,{activeTab:u,onTabChange:m=>{m==="scan"?c(!0):x(m)}}),n&&e.jsx("div",{className:"fixed inset-0 z-[200] bg-[var(--bg-void)]/90 backdrop-blur-xl animate-fade-in h-[100dvh]",children:e.jsxs("div",{className:"flex flex-col h-full max-w-lg mx-auto bg-[var(--bg-surface)] shadow-2xl",children:[e.jsxs("header",{className:"p-4 border-b border-[var(--border-subtle)] flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-full bg-gradient-to-br from-[var(--accent-primary)] to-[var(--accent-secondary)] flex items-center justify-center",children:e.jsx(L,{size:20,className:"text-black"})}),e.jsxs("div",{className:"flex flex-col",children:[e.jsx("span",{className:"text-sm font-black",children:"Gram Sahayak Pro"}),e.jsx("span",{className:"text-[10px] text-[var(--accent-primary)] animate-pulse font-bold tracking-tighter uppercase",children:"V5 Business Engine Active"})]})]}),e.jsx("button",{onClick:()=>o(!1),className:"p-2 rounded-xl bg-white/5",title:"Close AI Assistant",children:e.jsx(T,{size:20})})]}),e.jsx("div",{className:"flex-1 overflow-hidden",children:e.jsx(be,{user:r})})]})}),N&&e.jsx(ve,{user:r,onClose:()=>c(!1),onResult:()=>c(!1)}),v&&e.jsx(we,{onClose:()=>f(!1),onClaim:m=>{alert(`Success! ${m} added to your VillageLink Wallet.`),f(!1)}}),F&&e.jsx("div",{className:"fixed inset-0 z-[300] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in",children:e.jsxs("div",{className:"bg-white dark:bg-slate-900 w-full max-w-sm rounded-[32px] overflow-hidden shadow-2xl border border-slate-100 dark:border-slate-800",children:[e.jsxs("div",{className:"bg-gradient-to-br from-[#BE5103] to-[#FFCE1B] p-6 text-white text-center relative",children:[e.jsx("button",{onClick:()=>z(!1),className:"absolute top-4 right-4 p-2 bg-black/10 hover:bg-black/20 rounded-full transition-colors",children:e.jsx(T,{size:20})}),e.jsx("div",{className:"w-20 h-20 mx-auto bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-4xl font-bold border-4 border-white overflow-hidden shadow-xl mb-3",children:r?.name?.charAt(0)?.toUpperCase()}),e.jsx("h2",{className:"text-2xl font-bold",children:r?.name}),e.jsx("p",{className:"opacity-90 text-sm",children:r?.role})]}),e.jsxs("div",{className:"p-6 space-y-4",children:[e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700",children:[e.jsx("p",{className:"text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1",children:"User ID"}),e.jsx("p",{className:"font-mono text-slate-800 dark:text-white font-medium",children:r?.id})]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700",children:[e.jsx("p",{className:"text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1",children:"Phone Number"}),e.jsx("p",{className:"font-medium text-slate-800 dark:text-white",children:r?.phone||"Not provided"})]}),e.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700",children:[e.jsx("p",{className:"text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1",children:"Gender"}),e.jsx("p",{className:"font-medium text-slate-800 dark:text-white capitalize",children:r?.gender?.toLowerCase()||"Not specified"})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3 pt-2",children:[e.jsx("button",{className:"py-2.5 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors",children:"Update Photo"}),e.jsx("button",{className:"py-2.5 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors",children:"Change Password"})]})]})]})}),e.jsx("style",{children:`
                .v5-loading-screen {
                    height: 100vh;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    background: var(--bg-deep);
                    gap: 1rem;
                    color: var(--text-primary);
                }
                .animate-fade-in {
                    animation: v5FadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1);
                }
                @keyframes v5FadeIn {
                    from { opacity: 0; transform: translateY(15px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `})]}):e.jsxs("div",{className:"v5-loading-screen",children:[e.jsx(Q,{className:"w-8 h-8 animate-spin text-[var(--accent-primary)]"}),e.jsx("p",{className:"text-xs uppercase tracking-widest text-[var(--text-muted)]",children:"Loading VillageLink..."})]})};export{Ue as default};
