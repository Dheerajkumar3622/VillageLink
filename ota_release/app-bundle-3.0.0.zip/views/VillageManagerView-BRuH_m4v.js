import{A as N,j as e}from"../assets/synapse-DJbL7Np4.js";import{r}from"../assets/vendor-react-BR5y8XGT.js";import{z as E,q as C,Z as I,_ as y,$ as P,I as V,x as D,m as S,l as T,s as O,U as L,a0 as $,P as _,A as q,u as z,a1 as F}from"../assets/vendor-ui-C2GrFI-5.js";import"../assets/vendor-socket-TjCxX7sJ.js";const w=()=>({"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("villagelink_token")}`}),X=({user:p})=>{const[d,n]=r.useState("dashboard"),[t,c]=r.useState(null),[x,i]=r.useState([]),[o,h]=r.useState([]),[g,m]=r.useState(!0),[a,u]=r.useState(""),[v,k]=r.useState(!1),b=r.useCallback(async()=>{m(!0);try{const[s,B,l]=await Promise.all([fetch(`${N}/api/village-manager/stats`,{headers:w()}),fetch(`${N}/api/village-manager/beneficiaries`,{headers:w()}),fetch(`${N}/api/village-manager/transactions?limit=20`,{headers:w()})]),j=await s.json(),A=await B.json(),R=await l.json();j.success&&c(j.stats),A.success&&i(A.beneficiaries),R.success&&h(R.transactions)}catch{}finally{m(!1)}},[]);r.useEffect(()=>{b()},[b]);const f=x.filter(s=>s.name.toLowerCase().includes(a.toLowerCase())||s.village?.toLowerCase().includes(a.toLowerCase())||s.phone?.includes(a));return g?e.jsx("div",{className:"flex items-center justify-center min-h-[400px]",children:e.jsx(E,{className:"w-8 h-8 animate-spin text-emerald-600"})}):e.jsxs("div",{className:"village-manager-view",children:[e.jsxs("div",{className:"vm-header",children:[e.jsxs("div",{className:"vm-header-info",children:[e.jsx("h1",{children:"ग्राम प्रबंधक"}),e.jsx("p",{children:"Village Manager Dashboard"})]}),e.jsxs("div",{className:"vm-header-badge",children:[e.jsx(C,{className:"w-5 h-5"}),e.jsxs("span",{children:[t?.activeBeneficiaries||0," Villagers"]})]})]}),e.jsx("div",{className:"vm-tabs",children:[{id:"dashboard",label:"Dashboard",icon:e.jsx(I,{className:"w-4 h-4"})},{id:"beneficiaries",label:"Villagers",icon:e.jsx(C,{className:"w-4 h-4"})},{id:"book",label:"Book Service",icon:e.jsx(y,{className:"w-4 h-4"})},{id:"history",label:"History",icon:e.jsx(P,{className:"w-4 h-4"})}].map(s=>e.jsxs("button",{className:`vm-tab ${d===s.id?"active":""}`,onClick:()=>n(s.id),children:[s.icon,e.jsx("span",{children:s.label})]},s.id))}),d==="dashboard"&&e.jsxs("div",{className:"vm-dashboard",children:[e.jsxs("div",{className:"vm-stats-grid",children:[e.jsxs("div",{className:"vm-stat-card",children:[e.jsx(C,{className:"w-6 h-6 text-emerald-600"}),e.jsxs("div",{className:"vm-stat-info",children:[e.jsx("span",{className:"vm-stat-value",children:t?.activeBeneficiaries||0}),e.jsx("span",{className:"vm-stat-label",children:"Active Villagers"})]})]}),e.jsxs("div",{className:"vm-stat-card",children:[e.jsx(y,{className:"w-6 h-6 text-blue-600"}),e.jsxs("div",{className:"vm-stat-info",children:[e.jsx("span",{className:"vm-stat-value",children:t?.todaysTransactions||0}),e.jsx("span",{className:"vm-stat-label",children:"Today's Bookings"})]})]}),e.jsxs("div",{className:"vm-stat-card",children:[e.jsx(V,{className:"w-6 h-6 text-amber-600"}),e.jsxs("div",{className:"vm-stat-info",children:[e.jsxs("span",{className:"vm-stat-value",children:["₹",t?.totalRevenue||0]}),e.jsx("span",{className:"vm-stat-label",children:"Total Revenue"})]})]}),e.jsxs("div",{className:"vm-stat-card",children:[e.jsx(P,{className:"w-6 h-6 text-purple-600"}),e.jsxs("div",{className:"vm-stat-info",children:[e.jsx("span",{className:"vm-stat-value",children:t?.totalTransactions||0}),e.jsx("span",{className:"vm-stat-label",children:"All Transactions"})]})]})]}),e.jsxs("div",{className:"vm-quick-actions",children:[e.jsx("h3",{children:"Quick Actions"}),e.jsxs("div",{className:"vm-action-grid",children:[e.jsxs("button",{className:"vm-action-btn",onClick:()=>{k(!0),n("beneficiaries")},children:[e.jsx(D,{className:"w-6 h-6"}),e.jsx("span",{children:"Add Villager"})]}),e.jsxs("button",{className:"vm-action-btn",onClick:()=>n("book"),children:[e.jsx(y,{className:"w-6 h-6"}),e.jsx("span",{children:"Book Ticket"})]}),e.jsxs("button",{className:"vm-action-btn",onClick:()=>n("book"),children:[e.jsx(S,{className:"w-6 h-6"}),e.jsx("span",{children:"Send Parcel"})]}),e.jsxs("button",{className:"vm-action-btn",onClick:()=>n("book"),children:[e.jsx(T,{className:"w-6 h-6"}),e.jsx("span",{children:"Book Food"})]})]})]}),e.jsxs("div",{className:"vm-recent",children:[e.jsx("h3",{children:"Recent Transactions"}),o.slice(0,5).map(s=>e.jsxs("div",{className:"vm-txn-item",children:[e.jsxs("div",{className:"vm-txn-icon",children:[s.transactionType==="TICKET_BOOKING"&&e.jsx(y,{className:"w-5 h-5"}),s.transactionType==="PARCEL_BOOKING"&&e.jsx(S,{className:"w-5 h-5"}),s.transactionType==="MESS_BOOKING"&&e.jsx(T,{className:"w-5 h-5"})]}),e.jsxs("div",{className:"vm-txn-info",children:[e.jsx("span",{className:"vm-txn-name",children:s.beneficiaryName}),e.jsx("span",{className:"vm-txn-type",children:s.transactionType.replace("_"," ")})]}),e.jsxs("div",{className:"vm-txn-amount",children:[e.jsxs("span",{children:["₹",s.amount]}),e.jsx("span",{className:`vm-txn-status ${s.status.toLowerCase()}`,children:s.status})]})]},s.id))]})]}),d==="beneficiaries"&&e.jsx(M,{beneficiaries:f,searchQuery:a,setSearchQuery:u,showAddForm:v,setShowAddForm:k,onRefresh:b}),d==="book"&&e.jsx(U,{beneficiaries:x,onRefresh:b}),d==="history"&&e.jsx(H,{transactions:o}),e.jsx("style",{children:`
        .village-manager-view {
          padding-bottom: 80px;
        }

        .vm-header {
          background: linear-gradient(135deg, #059669, #10b981);
          border-radius: 16px;
          padding: 24px;
          color: white;
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }

        .vm-header h1 {
          font-size: 1.75rem;
          font-weight: 700;
          margin-bottom: 4px;
        }

        .vm-header p {
          opacity: 0.9;
          font-size: 0.875rem;
        }

        .vm-header-badge {
          display: flex;
          align-items: center;
          gap: 8px;
          background: rgba(255,255,255,0.2);
          padding: 8px 16px;
          border-radius: 20px;
          font-weight: 600;
        }

        .vm-tabs {
          display: flex;
          gap: 8px;
          margin-bottom: 20px;
          overflow-x: auto;
          padding-bottom: 4px;
        }

        .vm-tab {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 10px 16px;
          border-radius: 10px;
          border: none;
          background: #f1f5f9;
          color: #64748b;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          white-space: nowrap;
        }

        .vm-tab.active {
          background: #059669;
          color: white;
        }

        .vm-stats-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
          margin-bottom: 24px;
        }

        .vm-stat-card {
          background: white;
          border-radius: 12px;
          padding: 16px;
          display: flex;
          align-items: center;
          gap: 12px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }

        .vm-stat-info {
          display: flex;
          flex-direction: column;
        }

        .vm-stat-value {
          font-size: 1.5rem;
          font-weight: 700;
          color: #111827;
        }

        .vm-stat-label {
          font-size: 0.75rem;
          color: #6b7280;
        }

        .vm-quick-actions {
          margin-bottom: 24px;
        }

        .vm-quick-actions h3,
        .vm-recent h3 {
          font-weight: 600;
          color: #111827;
          margin-bottom: 12px;
        }

        .vm-action-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }

        .vm-action-btn {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          padding: 20px;
          background: white;
          border: 2px solid #e5e7eb;
          border-radius: 12px;
          cursor: pointer;
          transition: all 0.2s;
          color: #374151;
        }

        .vm-action-btn:hover {
          border-color: #059669;
          color: #059669;
        }

        .vm-txn-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px;
          background: white;
          border-radius: 10px;
          margin-bottom: 8px;
          box-shadow: 0 1px 4px rgba(0,0,0,0.05);
        }

        .vm-txn-icon {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: #f0fdf4;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #059669;
        }

        .vm-txn-info {
          flex: 1;
          display: flex;
          flex-direction: column;
        }

        .vm-txn-name {
          font-weight: 600;
          color: #111827;
        }

        .vm-txn-type {
          font-size: 0.75rem;
          color: #6b7280;
          text-transform: capitalize;
        }

        .vm-txn-amount {
          text-align: right;
          display: flex;
          flex-direction: column;
        }

        .vm-txn-amount span:first-child {
          font-weight: 600;
          color: #111827;
        }

        .vm-txn-status {
          font-size: 0.7rem;
          padding: 2px 8px;
          border-radius: 10px;
          font-weight: 500;
        }

        .vm-txn-status.completed { background: #d1fae5; color: #059669; }
        .vm-txn-status.pending { background: #fef3c7; color: #d97706; }
        .vm-txn-status.cancelled { background: #fee2e2; color: #dc2626; }

        .dark .vm-stat-card,
        .dark .vm-action-btn,
        .dark .vm-txn-item {
          background: #1e293b;
        }

        .dark .vm-stat-value,
        .dark .vm-txn-name,
        .dark .vm-quick-actions h3,
        .dark .vm-recent h3 {
          color: #f1f5f9;
        }

        .dark .vm-tab {
          background: #334155;
          color: #94a3b8;
        }

        .dark .vm-action-btn {
          border-color: #475569;
          color: #cbd5e1;
        }
      `})]})},M=({beneficiaries:p,searchQuery:d,setSearchQuery:n,showAddForm:t,setShowAddForm:c,onRefresh:x})=>{const[i,o]=r.useState({name:"",phone:"",aadharNumber:"",address:"",village:"",panchayat:"",district:""}),[h,g]=r.useState(!1),m=async a=>{if(a.preventDefault(),!i.name||!i.village){alert("Name and Village are required");return}g(!0);try{const v=await(await fetch(`${N}/api/village-manager/beneficiaries`,{method:"POST",headers:w(),body:JSON.stringify(i)})).json();v.success?(o({name:"",phone:"",aadharNumber:"",address:"",village:"",panchayat:"",district:""}),c(!1),x()):alert(v.error||"Failed to add")}catch{alert("Error adding beneficiary")}finally{g(!1)}};return e.jsxs("div",{className:"vm-beneficiaries",children:[e.jsxs("div",{className:"vm-search-bar",children:[e.jsxs("div",{className:"vm-search-input",children:[e.jsx(O,{className:"w-5 h-5 text-gray-400"}),e.jsx("input",{type:"text",placeholder:"Search villagers...",value:d,onChange:a=>n(a.target.value)})]}),e.jsx("button",{className:"vm-add-btn",onClick:()=>c(!t),"aria-label":"Add Villager",title:"Add Villager",children:e.jsx(D,{className:"w-5 h-5"})})]}),t&&e.jsxs("form",{className:"vm-add-form",onSubmit:m,children:[e.jsx("h4",{children:"Register New Villager"}),e.jsx("input",{type:"text",placeholder:"Name *",value:i.name,onChange:a=>o({...i,name:a.target.value}),required:!0}),e.jsx("input",{type:"tel",placeholder:"Phone (optional)",value:i.phone,onChange:a=>o({...i,phone:a.target.value})}),e.jsx("input",{type:"text",placeholder:"Aadhar Number (optional)",value:i.aadharNumber,onChange:a=>o({...i,aadharNumber:a.target.value})}),e.jsx("input",{type:"text",placeholder:"Address",value:i.address,onChange:a=>o({...i,address:a.target.value})}),e.jsxs("div",{className:"vm-form-row",children:[e.jsx("input",{type:"text",placeholder:"Village *",value:i.village,onChange:a=>o({...i,village:a.target.value}),required:!0}),e.jsx("input",{type:"text",placeholder:"Panchayat",value:i.panchayat,onChange:a=>o({...i,panchayat:a.target.value})})]}),e.jsx("input",{type:"text",placeholder:"District",value:i.district,onChange:a=>o({...i,district:a.target.value})}),e.jsxs("div",{className:"vm-form-actions",children:[e.jsx("button",{type:"button",onClick:()=>c(!1),children:"Cancel"}),e.jsx("button",{type:"submit",className:"primary",disabled:h,children:h?"Saving...":"Register Villager"})]})]}),e.jsx("div",{className:"vm-list",children:p.length===0?e.jsxs("div",{className:"vm-empty",children:[e.jsx(C,{className:"w-12 h-12 text-gray-300"}),e.jsx("p",{children:"No villagers registered yet"}),e.jsx("button",{onClick:()=>c(!0),children:"Register First Villager"})]}):p.map(a=>e.jsxs("div",{className:"vm-beneficiary-card",children:[e.jsx("div",{className:"vm-ben-avatar",children:e.jsx(L,{className:"w-6 h-6"})}),e.jsxs("div",{className:"vm-ben-info",children:[e.jsx("span",{className:"vm-ben-name",children:a.name}),e.jsxs("span",{className:"vm-ben-village",children:[e.jsx($,{className:"w-3 h-3"})," ",a.village]}),a.phone&&e.jsxs("span",{className:"vm-ben-phone",children:[e.jsx(_,{className:"w-3 h-3"})," ",a.phone]})]}),e.jsxs("button",{className:"vm-book-for-btn",children:["Book ",e.jsx(q,{className:"w-4 h-4"})]})]},a.id))}),e.jsx("style",{children:`
        .vm-search-bar {
          display: flex;
          gap: 12px;
          margin-bottom: 16px;
        }

        .vm-search-input {
          flex: 1;
          display: flex;
          align-items: center;
          gap: 8px;
          background: white;
          border-radius: 10px;
          padding: 10px 14px;
          border: 1px solid #e5e7eb;
        }

        .vm-search-input input {
          flex: 1;
          border: none;
          outline: none;
          background: transparent;
        }

        .vm-add-btn {
          width: 44px;
          height: 44px;
          border-radius: 10px;
          background: #059669;
          color: white;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }

        .vm-add-form {
          background: white;
          border-radius: 12px;
          padding: 20px;
          margin-bottom: 16px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .vm-add-form h4 {
          font-weight: 600;
          margin-bottom: 16px;
          color: #111827;
        }

        .vm-add-form input {
          width: 100%;
          padding: 12px;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          margin-bottom: 12px;
          font-size: 1rem;
        }

        .vm-form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }

        .vm-form-actions {
          display: flex;
          gap: 12px;
          margin-top: 8px;
        }

        .vm-form-actions button {
          flex: 1;
          padding: 12px;
          border-radius: 8px;
          font-weight: 500;
          cursor: pointer;
          border: 1px solid #e5e7eb;
          background: white;
        }

        .vm-form-actions button.primary {
          background: #059669;
          color: white;
          border: none;
        }

        .vm-empty {
          text-align: center;
          padding: 40px 20px;
          color: #6b7280;
        }

        .vm-empty button {
          margin-top: 16px;
          padding: 10px 20px;
          background: #059669;
          color: white;
          border: none;
          border-radius: 8px;
          cursor: pointer;
        }

        .vm-beneficiary-card {
          display: flex;
          align-items: center;
          gap: 12px;
          background: white;
          padding: 14px;
          border-radius: 12px;
          margin-bottom: 10px;
          box-shadow: 0 1px 4px rgba(0,0,0,0.05);
        }

        .vm-ben-avatar {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          background: #f0fdf4;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #059669;
        }

        .vm-ben-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .vm-ben-name {
          font-weight: 600;
          color: #111827;
        }

        .vm-ben-village,
        .vm-ben-phone {
          font-size: 0.75rem;
          color: #6b7280;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .vm-book-for-btn {
          display: flex;
          align-items: center;
          gap: 4px;
          padding: 8px 12px;
          background: #ecfdf5;
          color: #059669;
          border: none;
          border-radius: 8px;
          font-weight: 500;
          cursor: pointer;
        }

        .dark .vm-search-input,
        .dark .vm-add-form,
        .dark .vm-beneficiary-card {
          background: #1e293b;
          border-color: #334155;
        }

        .dark .vm-add-form h4,
        .dark .vm-ben-name {
          color: #f1f5f9;
        }
      `})]})},U=({beneficiaries:p,onRefresh:d})=>{const[n,t]=r.useState(""),[c,x]=r.useState("ticket"),[i,o]=r.useState(""),[h,g]=r.useState(""),[m,a]=r.useState(1),[u,v]=r.useState("CASH"),[k,b]=r.useState(!1),[f,s]=r.useState(null),B=async()=>{if(!n||!i||!h){alert("Please fill all required fields");return}b(!0),s(null);try{const j=await(await fetch(`${N}/api/village-manager/proxy/ticket`,{method:"POST",headers:w(),body:JSON.stringify({beneficiaryId:n,from:i,to:h,passengerCount:m,paymentMethod:u})})).json();j.success?(s({success:!0,message:j.message||"Ticket booked successfully!"}),o(""),g(""),a(1),d()):s({success:!1,message:j.error||"Booking failed"})}catch{s({success:!1,message:"Network error"})}finally{b(!1)}};return e.jsxs("div",{className:"vm-booking",children:[e.jsxs("div",{className:"vm-booking-section",children:[e.jsx("label",{htmlFor:"villager-select",children:"Select Villager"}),e.jsxs("select",{id:"villager-select",value:n,onChange:l=>t(l.target.value),children:[e.jsx("option",{value:"",children:"-- Choose Villager --"}),p.map(l=>e.jsxs("option",{value:l.id,children:[l.name," - ",l.village]},l.id))]})]}),e.jsxs("div",{className:"vm-booking-types",children:[e.jsxs("button",{className:c==="ticket"?"active":"",onClick:()=>x("ticket"),title:"Book a ticket",children:[e.jsx(y,{className:"w-5 h-5"}),e.jsx("span",{children:"Ticket"})]}),e.jsxs("button",{className:c==="parcel"?"active":"",onClick:()=>x("parcel"),title:"Book a parcel delivery",children:[e.jsx(S,{className:"w-5 h-5"}),e.jsx("span",{children:"Parcel"})]}),e.jsxs("button",{className:c==="food"?"active":"",onClick:()=>x("food"),title:"Order food",children:[e.jsx(T,{className:"w-5 h-5"}),e.jsx("span",{children:"Food"})]})]}),c==="ticket"&&e.jsxs("div",{className:"vm-ticket-form",children:[e.jsxs("div",{className:"vm-booking-section",children:[e.jsx("label",{htmlFor:"from-input",children:"From"}),e.jsx("input",{id:"from-input",type:"text",placeholder:"Enter origin village/city",value:i,onChange:l=>o(l.target.value)})]}),e.jsxs("div",{className:"vm-booking-section",children:[e.jsx("label",{htmlFor:"to-input",children:"To"}),e.jsx("input",{id:"to-input",type:"text",placeholder:"Enter destination",value:h,onChange:l=>g(l.target.value)})]}),e.jsxs("div",{className:"vm-booking-section",children:[e.jsx("label",{children:"Passengers"}),e.jsxs("div",{className:"vm-counter",children:[e.jsx("button",{onClick:()=>a(Math.max(1,m-1)),title:"Decrease passenger count",children:"-"}),e.jsx("span",{children:m}),e.jsx("button",{onClick:()=>a(m+1),title:"Increase passenger count",children:"+"})]})]}),e.jsxs("div",{className:"vm-booking-section",children:[e.jsx("label",{children:"Payment Method"}),e.jsxs("div",{className:"vm-payment-options",children:[e.jsxs("button",{className:u==="CASH"?"active":"",onClick:()=>v("CASH"),title:"Select Cash as payment method",children:[e.jsx(V,{className:"w-4 h-4"})," Cash"]}),e.jsxs("button",{className:u==="UPI"?"active":"",onClick:()=>v("UPI"),title:"Select UPI as payment method",children:[e.jsx(z,{className:"w-4 h-4"})," UPI"]})]})]}),e.jsx("button",{className:"vm-book-btn",onClick:B,disabled:k||!n,children:k?"Booking...":"Book Ticket"})]}),f&&e.jsxs("div",{className:`vm-result ${f.success?"success":"error"}`,children:[f.success?e.jsx(z,{className:"w-5 h-5"}):e.jsx(F,{className:"w-5 h-5"}),e.jsx("span",{children:f.message})]}),e.jsx("style",{children:`
        .vm-booking-section {
          margin-bottom: 16px;
        }

        .vm-booking-section label {
          display: block;
          font-weight: 500;
          color: #374151;
          margin-bottom: 8px;
        }

        .vm-booking-section select,
        .vm-booking-section input {
          width: 100%;
          padding: 12px;
          border: 1px solid #e5e7eb;
          border-radius: 10px;
          font-size: 1rem;
          background: white;
        }

        .vm-booking-types {
          display: flex;
          gap: 8px;
          margin-bottom: 20px;
        }

        .vm-booking-types button {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          padding: 14px;
          border: 2px solid #e5e7eb;
          border-radius: 10px;
          background: white;
          cursor: pointer;
          color: #6b7280;
        }

        .vm-booking-types button.active {
          border-color: #059669;
          background: #ecfdf5;
          color: #059669;
        }

        .vm-counter {
          display: flex;
          align-items: center;
          gap: 16px;
          background: white;
          border: 1px solid #e5e7eb;
          border-radius: 10px;
          padding: 8px 16px;
          width: fit-content;
        }

        .vm-counter button {
          width: 32px;
          height: 32px;
          border: none;
          background: #f3f4f6;
          border-radius: 8px;
          font-size: 1.25rem;
          cursor: pointer;
        }

        .vm-counter span {
          font-size: 1.25rem;
          font-weight: 600;
          min-width: 30px;
          text-align: center;
        }

        .vm-payment-options {
          display: flex;
          gap: 12px;
        }

        .vm-payment-options button {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 12px;
          border: 2px solid #e5e7eb;
          border-radius: 10px;
          background: white;
          cursor: pointer;
        }

        .vm-payment-options button.active {
          border-color: #059669;
          background: #ecfdf5;
          color: #059669;
        }

        .vm-book-btn {
          width: 100%;
          padding: 16px;
          background: #059669;
          color: white;
          border: none;
          border-radius: 12px;
          font-size: 1.1rem;
          font-weight: 600;
          cursor: pointer;
          margin-top: 16px;
        }

        .vm-book-btn:disabled {
          background: #9ca3af;
          cursor: not-allowed;
        }

        .vm-result {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 14px;
          border-radius: 10px;
          margin-top: 16px;
        }

        .vm-result.success {
          background: #d1fae5;
          color: #059669;
        }

        .vm-result.error {
          background: #fee2e2;
          color: #dc2626;
        }

        .dark .vm-booking-section label { color: #e2e8f0; }
        .dark .vm-booking-section select,
        .dark .vm-booking-section input,
        .dark .vm-counter,
        .dark .vm-payment-options button,
        .dark .vm-booking-types button {
          background: #1e293b;
          border-color: #475569;
          color: #e2e8f0;
        }
      `})]})},H=({transactions:p})=>{const d=t=>new Date(t).toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}),n=t=>{switch(t){case"TICKET":return e.jsx(y,{className:"w-5 h-5"});case"PARCEL":return e.jsx(S,{className:"w-5 h-5"});case"MESS_BOOKING":return e.jsx(T,{className:"w-5 h-5"});default:return e.jsx(I,{className:"w-5 h-5"})}};return e.jsxs("div",{className:"vm-history",children:[p.length===0?e.jsxs("div",{className:"vm-empty",children:[e.jsx(P,{className:"w-12 h-12 text-gray-300"}),e.jsx("p",{children:"No transactions yet"})]}):p.map(t=>e.jsxs("div",{className:"vm-history-item",children:[e.jsx("div",{className:"vm-history-icon",children:n(t.transactionType)}),e.jsxs("div",{className:"vm-history-info",children:[e.jsx("span",{className:"vm-history-name",children:t.beneficiaryName}),e.jsxs("span",{className:"vm-history-type",children:[t.transactionType.replace(/_/g," ")," • ",d(t.timestamp)]})]}),e.jsxs("div",{className:"vm-history-right",children:[e.jsxs("span",{className:"vm-history-amount",children:["₹",t.amount]}),e.jsx("span",{className:`vm-history-status ${t.status.toLowerCase()}`,children:t.status})]})]},t.id)),e.jsx("style",{children:`
        .vm-history-item {
          display: flex;
          align-items: center;
          gap: 12px;
          background: white;
          padding: 14px;
          border-radius: 12px;
          margin-bottom: 10px;
          box-shadow: 0 1px 4px rgba(0,0,0,0.05);
        }

        .vm-history-icon {
          width: 44px;
          height: 44px;
          border-radius: 10px;
          background: #f0fdf4;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #059669;
        }

        .vm-history-info {
          flex: 1;
          display: flex;
          flex-direction: column;
        }

        .vm-history-name {
          font-weight: 600;
          color: #111827;
        }

        .vm-history-type {
          font-size: 0.75rem;
          color: #6b7280;
          text-transform: capitalize;
        }

        .vm-history-right {
          text-align: right;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .vm-history-amount {
          font-weight: 600;
          color: #111827;
        }

        .vm-history-status {
          font-size: 0.7rem;
          padding: 2px 8px;
          border-radius: 10px;
          font-weight: 500;
        }

        .vm-history-status.completed { background: #d1fae5; color: #059669; }
        .vm-history-status.pending { background: #fef3c7; color: #d97706; }
        .vm-history-status.cancelled { background: #fee2e2; color: #dc2626; }

        .dark .vm-history-item {
          background: #1e293b;
        }

        .dark .vm-history-name,
        .dark .vm-history-amount {
          color: #f1f5f9;
        }
      `})]})};export{X as default};
